/*
 * Copyright (c) 1997 Rapha�l Goulais <velephys@hol.fr>
 * Copyright (c) 1997 Guylhem Aznar <guylhem@danmark.linux.eu.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>

int i;
int k;
int l;
extern int errno;
int count;
char *as_tmp;
char *as_dir;
FILE *start_menu;
FILE *as_source;
struct dirent **list;


		/*
		 *            Here we scan directories, searching for
		 *              menu entries and directorie to scan ...
		 */

void analyse(char *repertoire, char *parent)
{
	struct dirent **an_list;
	char *an_char;
	char an_rep[254];
	FILE *an_file;
	FILE *an_tmp;
	FILE *an_source;
	int an_count;
	int an_i;
	int jeton;

	/*
	 *            Opening files ...
	 */

	if ((an_char = (char *) malloc(sizeof(char) * (strlen(parent) + strlen(repertoire) + 300))) == NULL)
		 perror("Bad Malloc");
	sprintf(an_char, "%s/tmp/__tmp%3d", as_dir, count);
	if ((an_file = fopen(an_char, "w")) == NULL)
		perror(an_char);
	sprintf(an_char, "%s/tmp/__dir%3d", as_dir, count);
	if ((an_tmp = fopen(an_char, "w")) == NULL)
		perror(an_char);

	/*
	 *            Writing menu himself.
	 */

	fprintf(an_file, "Popup \"%s\"\n", repertoire);
	fprintf(an_file, " Title \"%s\"\n", repertoire);
	sprintf(an_char, "%s%s", parent, repertoire);

	/*
	 *            Scanning directory, if file,
	 *              then add entry to menu ...
	 *              ... else, store directory name
	 *              in a temporary file, for later
	 *              treatment.
	 */

	if ((an_i = scandir(an_char, &an_list, 0, alphasort)) == -1)
		perror(an_char);
	jeton = 0;
	for (i = 0; i < an_i; i++)
		if (an_list[i]->d_name != strchr(an_list[i]->d_name, '.')) {
			sprintf(an_char, "%s%s/%s", parent, repertoire, an_list[i]->d_name);
			if (chdir(an_char) != 0) {
				if ((an_source = fopen(an_char, "r")) == NULL)
					perror(an_char);
				fgets(an_char, 254, an_source);
				fclose(an_source);
				fprintf(an_file, " Exec \"%s\" exec %s", an_list[i]->d_name, an_char);
			} else {
				fprintf(an_file, " Popup \"%s\" %s\n", an_list[i]->d_name, an_list[i]->d_name);
				fprintf(an_tmp, "%s\n", an_list[i]->d_name);
				jeton++;
			}
		}
	fprintf(an_file, "EndPopup\n\n.\n");
	fclose(an_file);
	fprintf(an_tmp, ".\n");
	fclose(an_tmp);

	/*
	 *            Now, we reopen temp file,
	 *              and analyse each directory
	 *              stored ...
	 */

	an_i = 0;
	an_count = count;
	while (jeton != 0) {
		sprintf(an_char, "%s/tmp/__dir%3d", as_dir, an_count);
		if ((an_tmp = fopen(an_char, "r")) == NULL)
			perror(an_char);
		fseek(an_tmp, an_i, SEEK_SET);
		fgets(an_rep, 254, an_tmp);
		an_i = strlen(an_rep) + an_i;
		strcpy(strpbrk(an_rep, "\n"), "\0");
		fclose(an_tmp);
		sprintf(an_char, "%s%s/", parent, repertoire);
		count--;
		analyse(an_rep, an_char);
		jeton--;
	}

	/*
	 *            Remove temp file ...
	 */

	sprintf(an_char, "%s/tmp/__dir%3d", as_dir, an_count);
	if ((remove(an_char)) != 0)
		perror(an_char);

	/*
	 *            Bye ...
	 */

	return;
}

		/*
		 * We should clean-up tmp dir before
		 * 
		 * 
		 */



int main(int argc, char *argv[], char *env[])
{
	if ((as_dir = (char *) malloc(sizeof(char) * (strlen(getenv("HOME")) + 36))) == NULL)
		 perror("Bad Malloc : ");
	if ((as_tmp = (char *) malloc(sizeof(char) * 4000)) == NULL)
		 perror("Bad Malloc : ");

	/* 
	 *    Here we test the existence of various
	 *      directories used for the generation.
	 */

/* Set ASDIR */

	sprintf(as_dir, "%s/gnustep/Library/AfterStep", getenv("HOME"));
	if (chdir(as_dir) != 0) {
		perror(as_dir);
		exit(errno);
	}

/* 3 special directory out of start, but browsed too */

	sprintf(as_tmp, "%s/desktop/backgrounds", as_dir);
	if (chdir(as_tmp) != 0) {
		perror(as_tmp);
		exit(errno);
	}
	sprintf(as_tmp, "%s/desktop/colors", as_dir);
	if (chdir(as_tmp) != 0) {
		perror(as_tmp);
		exit(errno);
	}
	sprintf(as_tmp, "%s/desktop/looks", as_dir);
	if (chdir(as_tmp) != 0) {
		perror(as_tmp);
		exit(errno);
	}
	sprintf(as_tmp, "%s/start", as_dir);
	if (chdir(as_tmp) != 0) {
		perror(as_tmp);
		exit(errno);
	}
	sprintf(as_tmp, "%s/tmp", as_dir);
	if (chdir(as_tmp) != 0) {
		perror(as_tmp);
		exit(errno);
	}
	/*
	 *    Opening startmenu,
	 *      overwriting the old version.
	 */

	sprintf(as_tmp, "%s/startmenu", as_dir);
	if ((start_menu = fopen(as_tmp, "w")) == NULL) {
		perror(as_tmp);
		exit(errno);
	}
	/*
	 *    Popup menu Quit
	 */

	fprintf(start_menu, "Popup \"quit\"\n Title \"Quit ...\"\n");
	fprintf(start_menu, " Quit \"Close this session\"\n Nop \"No, don't quit\"\n");
	fprintf(start_menu, " Restart \"Restart this session\" afterstep\n");
	fprintf(start_menu, "EndPopup\n\n");

	/*
	 *    Definition of pictures menu.
	 *      We scan backgrounds
	 *      for files and assume they're
	 *      pictures.
	 */

	fprintf(start_menu, "Popup \"Pictures\"\n Title \"Pictures\"\n");
	sprintf(as_tmp, "%s/desktop/backgrounds", as_dir);
	k = scandir(as_tmp, &list, 0, alphasort);
	for (i = 0; i < k; i++) {
		if (list[i]->d_name != strchr(list[i]->d_name, '.')) {
			fprintf(start_menu, " Exec \"%s\" exec sh -c \'xli -onroot ", list[i]->d_name);
			fprintf(start_menu, "%s/%s ; rm %s/background.color ; echo %s/%s > ", as_tmp, list[i]->d_name, as_dir, as_tmp, list[i]->d_name);
			fprintf(start_menu, "%s/background.picture\' &\n", as_dir);
		}
	}
	fprintf(start_menu, "EndPopup\n\n");

	/*
	 *    Here we start the generation of Look
	 *      menu. We scan looks for available
	 *      looks and place them in the menu. It also
	 *      updates steprc ...
	 */

	fprintf(start_menu, "Popup \"Look\"\n Title \"Look\"\n");
	sprintf(as_tmp, "%s/desktop/looks", as_dir);
	k = scandir(as_tmp, &list, 0, alphasort);
	for (i = 0; i < k; i++) {
		if (list[i]->d_name != strchr(list[i]->d_name, '.')) {
			fprintf(start_menu, " Exec \"%s\" exec sh -c", list[i]->d_name);
			fprintf(start_menu, " \'ln -sf %s/desktop/looks/%s ", as_dir, list[i]->d_name);
			fprintf(start_menu, "%s/look ; %s/make-startmenu\' &\n", as_dir, as_dir);
		}
	}
	fprintf(start_menu, "EndPopup\n\n");

	/*
	 *    The color directory is quite
	 *      easy to maintain :
	 *      touch colorname in the directory to add
	 *      this color to the menu ... It's worth a
	 *      front-end I think ;-)
	 */

	fprintf(start_menu, "Popup \"Colors\"\n Title \"Colors\"\n");
	sprintf(as_tmp, "%s/desktop/colors", as_dir);
	k = scandir(as_tmp, &list, 0, alphasort);
	for (i = 0; i < k; i++) {
		if (list[i]->d_name != strchr(list[i]->d_name, '.')) {
			fprintf(start_menu, " Exec \"%s\" exec sh -c \'xsetroot -solid ", list[i]->d_name);
			fprintf(start_menu, "%s ; rm %s/background.picture ; echo %s >", list[i]->d_name, as_dir, list[i]->d_name);
			fprintf(start_menu, " %s/background.color\' &\n", as_dir);
		}
	}
	fprintf(start_menu, "EndPopup\n\n");

	/*
	 *    Backgrounds menu, nothing to say,
	 *      quite simple ...
	 */

	fprintf(start_menu, "Popup \"Backgrounds\"\n Title \"Backgrounds\"\n");
	fprintf(start_menu, " Popup \"Colors\" Colors\n");
	fprintf(start_menu, " Popup \"Pictures\" Pictures\n");
	fprintf(start_menu, " Exec \"No Background Color\" exec sh -c \'xsetroot ; rm %s/background.color\' &\n", as_dir);
	fprintf(start_menu, " Exec \"No Background Picture\" exec sh -c \'xsetroot -solid");
	fprintf(start_menu, " `cat %s/background.color` ; rm %s/background.picture\' &\n", as_dir, as_dir);
	fprintf(start_menu, "EndPopup\n\n");

	/*
	 *    Desktop menu, same comment as above.
	 */

	fprintf(start_menu, "Popup \"Desktop\"\n Title \"Desktop\"\n");
	fprintf(start_menu, " Popup \"Backgrounds\" Backgrounds\n");
	fprintf(start_menu, " Popup \"Look\" Look\n");
	fprintf(start_menu, " Exec \"Update start menu\"   exec %s/make-startmenu &\n", as_dir);
	fprintf(start_menu, "EndPopup\n\n");

	/*
	 *            scanning start directory,
	 *              I call analyse for each directory
	 *              found.
	 */

	count = 250;
	sprintf(as_tmp, "%s/start", as_dir);
	k = scandir(as_tmp, &list, 0, alphasort);
	for (l = 0; l < k; l++)
		if (list[l]->d_name != strchr(list[l]->d_name, '.')) {
			sprintf(as_tmp, "%s/start/%s", as_dir, list[l]->d_name);
			if (chdir(as_tmp) == 0) {
				if (strcmp(list[l]->d_name, "Desktop") == 0)
					printf("No directory \"Desktop\" in start directory allowed ...\n");
				else if (strcmp(list[l]->d_name, "quit") == 0)
					printf("No directory \"quit\" in start directory allowed ...\n");
				else if (strcmp(list[l]->d_name, "Modules") == 0)
					printf("Melting processor ... done\n");
				else {
					count = count - 1;
					sprintf(as_tmp, "%s/start/", as_dir);
					analyse(list[l]->d_name, as_tmp);
				}
			}
		}
	/*
	 *            Merging temp files resulting
	 *              form the scanning of start
	 *              directory.
	 */

	while (count < 250) {
		sprintf(as_tmp, "%s/tmp/__tmp%3d", as_dir, count);
		if ((as_source = fopen(as_tmp, "r")) == NULL)
			perror(as_tmp);
		while (strcmp(fgets(as_tmp, 3998, as_source), ".\n") != 0)
			fprintf(start_menu, "%s", as_tmp);
		fclose(as_source);
		sprintf(as_tmp, "%s/tmp/__tmp%3d", as_dir, count);
		if ((remove(as_tmp)) != 0)
			perror(as_tmp);
		count++;
	}

	/*
	 *            Here we scan start/Modules directory ...
	 *              Later we should directly scan the file
	 *              afterstep.modules ...
	 */

	sprintf(as_tmp, "%s/start/Modules", as_dir);
	if ((k = scandir(as_tmp, &list, 0, alphasort)) != -1) {
		fprintf(start_menu, "Popup \"modules\"\n");
		fprintf(start_menu, " Title \"Modules\"\n");
		for (i = 0; i < k; i++)
			if (list[i]->d_name != strchr(list[i]->d_name, '.')) {
				sprintf(as_tmp, "%s/start/Modules/%s", as_dir, list[i]->d_name);
				if (chdir(as_tmp) != 0) {
					if ((as_source = fopen(as_tmp, "r")) == NULL)
						perror(as_tmp);
					fgets(as_tmp, 254, as_source);
					fclose(as_source);
					fprintf(start_menu, " Module \"%s\"  %s\n", list[i]->d_name, as_tmp);
				}
			}
		fprintf(start_menu, "EndPopup\n\n");
	} else
		perror(as_tmp);

	/*
	 *            Here's the start menu himself,
	 *              we're at the end ... ;-)
	 */

	fprintf(start_menu, "Popup \"start\"\n");
	fprintf(start_menu, " Title \"Start ...\"\n");
	fprintf(start_menu, " Popup \"Desktop\" Desktop\n");
	sprintf(as_tmp, "%s/start", as_dir);
	k = scandir(as_tmp, &list, 0, alphasort);
	for (i = 0; i < k; i++)
		if (list[i]->d_name != strchr(list[i]->d_name, '.')) {
			sprintf(as_tmp, "%s/start/%s", as_dir, list[i]->d_name);
			if (chdir(as_tmp) == 0) {
				if (strcmp(list[i]->d_name, "Desktop") == 0)
					printf("");
				else if (strcmp(list[i]->d_name, "quit") == 0)
					printf("");
				else if (strcmp(list[i]->d_name, "Modules") == 0)
					printf("");
				else
					fprintf(start_menu, " Popup \"%s\" %s\n", list[i]->d_name, list[i]->d_name);
			}
		}
	fprintf(start_menu, " Popup \"Modules\" modules\n");
	fprintf(start_menu, " Popup \"Quit ...\" quit\n");
	sprintf(as_tmp, "%s/start", as_dir);
	k = scandir(as_tmp, &list, 0, alphasort);
	for (i = 0; i < k; i++)
		if (list[i]->d_name != strchr(list[i]->d_name, '.')) {
			sprintf(as_tmp, "%s/start/%s", as_dir, list[i]->d_name);
			if (chdir(as_tmp) != 0) {
				if ((as_source = fopen(as_tmp, "r")) == NULL)
					perror(as_tmp);
				fgets(as_tmp, 254, as_source);
				fclose(as_source);
				fprintf(start_menu, " Exec \"%s\" exec %s", list[i]->d_name, as_tmp);
			}
		}
	fprintf(start_menu, "EndPopup\n\n");
	fclose(start_menu);
	return 0;
}
