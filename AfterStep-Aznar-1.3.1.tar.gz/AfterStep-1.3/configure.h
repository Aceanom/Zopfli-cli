/* Please don't touch ! */

#define VERSION "1.2"

/* Directories where afterstep lives */

#define AFTER_DIR	"~/gnustep/Library/AfterStep"
#define AFTER_SHAREDIR	"/usr/local/share/afterstep/"
#define AFTER_MODULEDIR	"/usr/X11R6/bin"
#define AFTER_ICONDIR	"/usr/X11R6/include/X11/bitmaps:/usr/X11R6/include/X11/pixmaps"

/*#define TARGET_DIR BINDIR=AFTERDIR*/
/*#define AFTER_BIN_DIR BINDIR=/usr/local/bin*/

/* Want background behind iconifyied windows ? */
/* #define NO_ICON_BACKGROUND */

/***************************************************************************
 *#define XPM
 *  if you want color icons, specify #define XPM, and get libXpm
 *   For monochrome, Xpm icons still work, but they're only better than regular
 *   bitmaps because they're shaped (if you specify #define SHAPE).
 ***************************************************************************/
#define XPM
#define XPMLIBRARY -L/usr/X11R6/lib -lXpm

/***************************************************************************
 * If you don't want the Shaped window extensions, #define NO_SHAPE
 *   Shaped window extensions seem to increase the window managers RSS
 *   by about 60 Kbytes. They provide for leaving a title-bar on the window
 *   without a border.
 *   If you dont use shaped window extension, you can either make your shaped
 *   windows undecorated, or live with a border and backdrop around all
 *   your shaped windows (oclock, xeyes)
 *   If you normally use a shaped window (xeyes or oclock), you might as
 *   well compile this extension in, since the memory cost is  minimal in
 *   this case (The shaped window shared libs will be loaded anyway. If you
 *   don't normally use a shaped window, you have to decide for yourself
 ***************************************************************************/
/*#define NO_SHAPE*/                     
 
/* If you don't want start menu to be rebuilt every time you start afterstep */
/*#define NO_MAKESTARTMENU*/

/***************************************************************************
 *#define NO_PAGER 
 *   Omits the code for the built-in pager. The pager module xpmPager is now
 *   recommended & the included pager will surely be deleted soon !
 ***************************************************************************/
#define NO_PAGER

/***************************************************************************
 * If you don't like gradients, comment this
 ***************************************************************************/
/*#define N0_TEXTURE*/

/***************************************************************************
 * If you do not want shade to be animated, comment this
 ***************************************************************************/
/*#define NO_SHADE*/

/***************************************************************************
 * If you do not want borders around titlebar icons; define this
 ***************************************************************************/ 
#define NO_BUTTONS_BORDERS

/***************************************************************************
 *#define NO_VIRTUAL
 *   Omits the virtual desktop - requires NO_PAGER
 ***************************************************************************/
/*#define NO_VIRTUAL*/

/***************************************************************************
 *#define NO_SAVEUNDERS 
 *   tells thw WM not to request save unders for pop-up
 *   menus. A quick test using monochrome X11 shows that save
 *   unders cost about 4Kbytes RAM, but saves a lot of
 *   window redraws if you have windows that take a while
 *   to refresh. For xcolor, I assume the cost is more like
 *   4Kbytesx8 = 32kbytes (256 color).
 ***************************************************************************/
/*#define NO_SAVEUNDERS*/

/***************************************************************************
 *#define NO_WINDOWLIST 
 *   causes built-in window-list to be omitted.
 *   The window-list module WinList can be used instead 
 ***************************************************************************/
/*#define NO_WINDOWLIST*/

/* Please translate the strings into the language which you use for your
 * pop-up menus */
/* Some decisions about where a function is prohibited (based on
 * mwm-function-hints) is based on a string comparison between the
 * menu item and the strings below */
#define MOVE_STRING      "move"
#define RESIZE_STRING1   "size"
#define RESIZE_STRING2   "resize"
#define MINIMIZE_STRING  "minimize"
#define MINIMIZE_STRING2 "iconify"
#define MAXIMIZE_STRING  "maximize"
#define CLOSE_STRING1    "close"
#define CLOSE_STRING2    "delete"
#define CLOSE_STRING3    "destroy"
#define CLOSE_STRING4    "quit"

#include "os-dependant.h"
