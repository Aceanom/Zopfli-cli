/* Compiler over-ride for Imakefiles */
/* Leave it as shown to get your default compiler */
#define COMPILER CC=cc 

/***************************************************************************
 *
 * In theory, this stuff can be replaced with GNU Autoconf
 *
 **************************************************************************/

#if defined _POSIX_SOURCE || defined SYSV || defined __sun__
#define HAVE_WAITPID  1
#define HAVE_GETITIMER 1
#define HAVE_SETITIMER 1
#define HAVE_SYSCONF 1
#define HAVE_UNAME 1
#undef HAVE_GETHOSTNAME
#else

/* Really, no one but me should need this */
#if defined __sun__ && !defined SYSV
#define BROKEN_SUN_HEADERS
#endif

/* Define if you have waitpid. */
#define HAVE_WAITPID  1

/* Define if you have getitimer/setitimer, else this will break auto-raise */
#define HAVE_GETITIMER 1
#define HAVE_SETITIMER 1

/* Define if you have uname. Otherwise, define gethostname */
#define HAVE_UNAME 1
/*#define HAVE_GETHOSTNAME 1*/

/* Define if you have sysconf */
#define HAVE_SYSCONF 1

#endif /* End of do-it-yourself OS support section */

/* Some checks */
#ifdef __alpha
#define NEEDS_ALPHA_HEADER
#undef BROKEN_SUN_HEADERS
#endif /* (__alpha) */

/* Allows gcc users to use inline, doesn't cause problems for others. */
#ifndef __GNUC__
#define  AFTER_INLINE  /* nothing */
#else
#if defined(__GNUC__) && !defined(inline)
#define AFTER_INLINE __inline__
#else
#define AFTER_INLINE inline
#endif /* __GNUC__ && !(inline) */
#endif /* !(__GNUC__) */
