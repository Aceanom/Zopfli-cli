/* config.h 
 * gideon le grange, 1994
 * 1994-11-22 : done 
 * misnomer may be. this is the header file to interface the 
 * scanner produced by f(lex) with the rest of the program */

extern int yylex(void);
extern FILE* yyin;
