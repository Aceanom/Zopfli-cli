/*****************************************************************************/
/*	astuner - AfterStep Tuner for RadioTrack and RadioReveal cards.      */
/*	Version 3.0						             */
/*	By David Muench.						     */		
/*	cc@spork.neonexus.com						     */
/*	http://www.neonexus.com/cc/					     */
/*									     */
/*	This is an 'AfterStep Look & Feel' Wharf style applet that can be    */
/*	used to control one of the before mentioned radio tuner cards.       */
/*									     */
/*   Based on ascd by Rob Malda and radiotrack-1.1 by Gideon J. le Grange.   */
/*****************************************************************************/

#ifndef _ASTUNER_H
#define _ASTUNER_H

/********/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include <errno.h>
#include <unistd.h>
#include <pwd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/time.h>

#include <linux/radio.h>

#include "config.h"

/* structs *********** ******************************************************/
typedef struct _XpmIcon {
	Pixmap pixmap;
	Pixmap mask;
	XpmAttributes attributes;
} XpmIcon;

typedef struct stations_t {
	int freq;
	char name[5];
} stations_t;

/* Global stuff **************************************************************/
#define TRUE 1
#define FALSE 0

#define RCFILE "/etc/astunerrc"

#define IPCDIR "/.astuneripc"

#define NUMSTATIONS 20

char	*myname;
stations_t stations[NUMSTATIONS];
extern int used;
char device[128];

#endif