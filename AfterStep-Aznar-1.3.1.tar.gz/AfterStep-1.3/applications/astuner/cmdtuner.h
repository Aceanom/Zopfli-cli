/*****************************************************************************/
/*	astuner - AfterStep Tuner for RadioTrack and RadioReveal cards.      */
/*	cmdtuner - Command Line Interface.                                   */
/*	Version 2.0						             */
/*	By David Muench.						     */		
/*	cc@spork.neonexus.com						     */
/*	http://www.neonexus.com/cc/					     */
/*									     */
/*	This is an 'AfterStep Look & Feel' Wharf style applet that can be    */
/*	used to control one of the before mentioned radio tuner cards.       */
/*									     */
/*   Based on ascd by Rob Malda and radiotrack-1.1 by Gideon J. le Grange.   */
/*****************************************************************************/

#ifndef _CMDTUNER_H
#define _CMDTUNER_H

/********/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <errno.h>
#include <unistd.h>
#include <pwd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>

/* Global stuff **************************************************************/
#define TRUE 1
#define FALSE 0

#define IPCDIR "/.astuneripc"

#define STATION_HI 107900
#define STATION_LOW 87900

#endif