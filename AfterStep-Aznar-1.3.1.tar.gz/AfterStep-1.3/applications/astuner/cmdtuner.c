/*****************************************************************************/
/*	astuner - AfterStep Tuner for RadioTrack and RadioReveal cards.      */
/*	cmdtuner - Command line interface.                                   */
/*	Version 2.0						             */
/*	By David Muench.						     */		
/*	cc@spork.neonexus.com						     */
/*	http://www.neonexus.com/cc/					     */
/*									     */
/*	This is an 'AfterStep Look & Feel' Wharf style applet that can be    */
/*	used to control one of the before mentioned radio tuner cards.       */
/*									     */
/*   Based on ascd by Rob Malda and radiotrack-1.1 by Gideon J. le Grange.   */
/*****************************************************************************/

/********/

#include "cmdtuner.h"

/* Functions *****************************************************************/
void    Help(void);
void    ParseCmdLine(int argc, char *argv[]);
void ipctouch(char *name);

/* Globals *******************************************************************/
int     err = 0;

uid_t	uid = 65535;
char	*ipcdir = 0;

/*****************************************************************************/
int main(int argc,char *argv[])
{
	int ret = 0;
	struct passwd *pw;

	uid = getuid();
	pw = getpwuid(uid); 
	ipcdir = malloc(strlen(pw->pw_dir) + strlen(IPCDIR) + 1); 
	strcpy(ipcdir, pw->pw_dir); 
	strcat(ipcdir, IPCDIR);

	if((mkdir(ipcdir, 0700) != 0) && (errno != EEXIST))
	{
		printf("%s : Error creating directory %s", argv[0], ipcdir);
	}

	ParseCmdLine(argc, argv); 
	
	free(ipcdir);
	return 0;
}

/*****************************************************************************/
void Help()
{       
	fprintf(stderr,"cmdtuner - Version 2.0\n");
	fprintf(stderr,"Written by David Muench - cc@spork.neonexus.com\n");
	fprintf(stderr,"http://www.neonexus.com/cc/\n");
	fprintf(stderr,"usage:  cmdtuner [options ...] \n");
	fprintf(stderr,"options:\n");
	fprintf(stderr,"\n");       
	fprintf(stderr,"  Command         What\n");
	fprintf(stderr,"h Help            Duh.\n");
	fprintf(stderr,"on                Turns the radio on.\n");
	fprintf(stderr,"off               Turns the radio off.\n");
	fprintf(stderr,"volup             Turns the volume up a notch.\n");
	fprintf(stderr,"voldown           Turns the volume down a notch.\n");
	fprintf(stderr,"tune <station>    Tunes to <station>, can be in decimal format (90.5, 90.500)\n");
	fprintf(stderr,"                  or as in the config file (90500, 105300)\n");
	fprintf(stderr,"\n");
	exit(1); 
}

/****************************************************************************/
void ParseCmdLine(int argc, char *argv[])
{

	char *Argument;
	int i;
	char tune[15];
	
	if(argc == 1)
	{
		Help();
		return;
	}
	
	for(i = 1; i < argc; i++) 
	{
		Argument = argv[i];
		
		if (Argument[0] == '-') 
		{
			switch(Argument[1]) 
			{
			case 'h':  /* Help */
				if(++i >= argc) Help();
				continue;
			
			 default:
				Help();
			}
		}
		else if(strcasecmp(Argument, "on") == 0)
		{
			ipctouch("on");
			break;
		}
		else if(strcasecmp(Argument, "off") == 0)
		{
			ipctouch("off");
			break;
		}
		else if(strcasecmp(Argument, "volup") == 0)
		{
			ipctouch("volup");
			break;
		}
		else if(strcasecmp(Argument, "voldown") == 0)
		{
			ipctouch("voldown");
			break;
		}
		else if(strcasecmp(Argument, "tune") == 0)
		{
			Argument = argv[i + 1];
			sprintf(tune, "tune.%s", Argument);
			ipctouch(tune);
			break;
		}
		else
			Help();
	}

}

/****************************************************************************/
void ipctouch(char *name)
{
	int fd = 0;
	char temp[501];
	
	sprintf(temp, "%s/ast-%d-%s", ipcdir, getpid(), name);
	
	fd = open(temp, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
	close(fd);
}