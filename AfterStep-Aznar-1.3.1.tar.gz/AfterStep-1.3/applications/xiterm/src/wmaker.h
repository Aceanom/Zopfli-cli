/*
 *  WindowMaker window manager interface
 *
 *  Copyright (c) 1997 Alfredo K. Kojima
 *  Freely usable under the terms of GNU GPL version 2
 */


#ifndef WMAKER_H_
#define WMAKER_H_

#include <X11/Xproto.h>

#define GNUSTEP_WM_ATTR_NAME  "_GNUSTEP_WM_ATTR"

/* window stacking level */
enum {
  NSNormalWindowLevel   = 0,
  NSFloatingWindowLevel  = 3,
  NSDockWindowLevel   = 5,
  NSSubmenuWindowLevel  = 10,
  NSMainMenuWindowLevel  = 20
};

/* window attributes */
enum {
  NSBorderlessWindowMask = 0,
  NSTitledWindowMask = 1,
  NSClosableWindowMask = 2,
  NSMiniaturizableWindowMask = 4,
  NSResizableWindowMask = 8
};


/* GNUstep protocols atom names */
#define GNUSTEP_WM_MINIATURIZE_WINDOW "_GNUSTEP_WM_MINIATURIZE_WINDOW"
#define GNUSTEP_WM_RESIZEBAR "_GNUSTEP_WM_RESIZEBAR"

typedef struct {
    CARD32 flags;
    CARD32 window_style;
    CARD32 window_level;
    CARD32 reserved;
    Pixmap miniaturize_pixmap;       /* pixmap for miniaturize button */
    Pixmap close_pixmap;             /* pixmap for close button */
    Pixmap miniaturize_mask;         /* miniaturize pixmap mask */
    Pixmap close_mask;               /* close pixmap mask */
    CARD32 extra_flags;
} GNUstepWMAttributes;

#define GSWindowStyleAttr     (1<<0)
#define GSWindowLevelAttr     (1<<1)
#define GSMiniaturizePixmapAttr       (1<<3)
#define GSClosePixmapAttr     (1<<4)
#define GSMiniaturizeMaskAttr (1<<5)
#define GSCloseMaskAttr               (1<<6)
#define GSExtraFlagsAttr              (1<<7)
#define GSClientResizeFlag    (1<<0)
#define GSFullKeyboardEventsFlag (1<<1)
#define GSMenuWindowFlag      (1<<2)
#define GSIconWindowFlag      (1<<3)
#define GSDarkGrayTitlebarFlag        (1<<8)

#define GNUSTEP_WM_FUNCTION "_GNUSTEP_WM_FUNCTION"

#define GSFHideOtherApplications      10
#define GSFHideApplication            12
#define GSFFocusWindow                        20

#endif
