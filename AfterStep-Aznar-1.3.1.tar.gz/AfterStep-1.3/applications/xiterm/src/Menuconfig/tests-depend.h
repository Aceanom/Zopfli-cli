/*
 *--------------------------------*-C-*---------------------------------
 * File:        tests-depend.h
 *
 * Copyright (c) 1997 Guylhem Aznar <guylhem@danmark.linux.eu.org>
 *
 * You can do what you like with this source code as long as you don't try
 * to make money out of it and you include an unaltered copy of this
 * message (including the copyright).
 *
 * As usual, the author accepts no responsibility for anything, nor does
 * he guarantee anything whatsoever.
 *----------------------------------------------------------------------
 */

/* Later, it'd be configurable in menu config ! */

#define CUTCHARS "\t \"&'()*,;<=>?@[\\]^`{|}~"

/* Consistent defines - please report on the necessity */

/* favoured settings for these systems */
#if defined (__sun__) || defined (__svr4__)
#define NO_DELETE_KEY
#endif
/*
 * @ Unixware: defines (__svr4__)
 */
#if defined (SVR4) && !defined (__svr4__)
#define __svr4__
#endif
#if defined (sun) && !defined (__sun__)
#define __sun__
#endif
/*
 * sun <sys/ioctl.h> isn't properly protected?
 * anyway, it causes problems when <termios.h> is also included
 */
#if defined (__sun__)
#undef HAVE_SYS_IOCTL_H
#endif

/* Fonts */

#ifndef KANJI
#undef GREEK_SUPPORT		/* Kanji/Greek together is too weird */
#undef XTERM_FONT_CHANGE	/* can't ensure font sizes will match */
#endif

/* Xpm library (-lXpm) */

#ifndef HAVE_LIBXPM
#undef XPM_BACKGROUND
#endif
#ifdef XPM_BUFFERING
#ifndef XPM_SCALING
#define XPM_SCALING
#endif
#endif
#ifndef XPM_BACKGROUND
#undef XPM_BUFFERING
#undef XPM_SCALING
#undef XTERM_PIXMAP_CHANGE
#endif

/* COLORTERM, TERM environment variables */

#define COLORTERMENV	"xiterm"
#ifdef KANJI
#define TERMENV	"kterm"
#else
#define TERMENV	"xterm"
#endif

/* X ressources */

#define APL_CLASS       "XTerm"	/* class name */
#define APL_SUBCLASS    "XIterm"	/* also check resources under this name */
#define APL_NAME        "Xiterm"	/* normal name */
#ifndef XAPPLOADDIR
#define XAPPLOADDIR     "/usr/X11R6/lib/X11/app-defaults"
#endif
#if defined (NO_RESOURCES) || defined (USE_XGETDEFAULT)
#undef KEYSYM_RESOURCE
#endif
#ifdef NO_RESOURCES
#undef USE_XGETDEFAULT
#endif

/*----------------------- end-of-file (C header) -----------------------*/
