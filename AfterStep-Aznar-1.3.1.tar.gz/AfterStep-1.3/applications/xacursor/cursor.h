extern int cursorLoad ();

extern void cursorSet ();

extern void cursorLoop ();

extern void cursorDemo ();

