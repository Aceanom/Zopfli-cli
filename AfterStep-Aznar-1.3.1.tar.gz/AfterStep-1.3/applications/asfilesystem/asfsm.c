#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>
#include "surreal.xpm"
#include "purplestoneswirl.xpm"
#include "cd.xpm"
#include "zip.xpm"
#include "harddisk.xpm"
#include "floppy.xpm"
#include "nfs.xpm"
#include "dos.xpm"

struct XpmIcon {
	Pixmap		pixmap;
	Pixmap		mask;
	XpmAttributes	xpmattributes;
};

XtAppContext	application;
Widget	mainwidget;
Display	*display;
int	screen, screenwidth, screenheight;
Window	root, mainwindow, filewindow, mountwindow, mounterwin[24], iconwin[24];
Pixel	bgpixel, fgpixel, borderpixel, zeropixel, popupfgpixel, 
		popupbgpixel, popupborderpixel, redpixel, greenpixel, 
		yellowpixel;
GC	mainwindowgc, zerogc, flipgc, thingc, flipthingc, popupgc;
GC	translucentgc;
XGCValues	gcv;
unsigned	long	gcm;
int	interval, poppedup1=0, poppedup2=0;
char	bgcolor[100], fgcolor[100], bordercolor[100], zerocolor[100];
char	popupbgcolor[100], popupfgcolor[100], popupbordercolor[100];
char	bgpix[100], popupbgpix[100];
Pixmap	bgpixmap, canvas;
struct	XpmIcon	bgtexture, popupbgpixmap, mounter[24];
XFontStruct	*popupfont1, *popupfont2;
int	fscounter, fstabcounter;

struct	fsrecord {
			char	mountdir[11];
			char	filesystem[21];
			char	blocks[11];
			char	used[11];
			char	free[11];
			char	percent[4];
			int	x1, y1, x2, y2;
			int	mounted;
			int	user;
			char	type[12];
		};

struct	fsrecord	fs[24], fstab[24];

Pixel getcolor(char *colorname) {

	XColor	color;
	XWindowAttributes	attributes;
	
	XGetWindowAttributes(display, mainwindow, &attributes);
	color.pixel=0;

	XParseColor(display, attributes.colormap, colorname, &color);
	XAllocColor(display, attributes.colormap, &color);

	return color.pixel;
}

void	defaults1() {
	strcpy(bgcolor, "DarkSlateGray\0");
	strcpy(fgcolor, "LightSlateGray\0");
	strcpy(zerocolor, "IndianRed\0");
	strcpy(popupbgcolor, "DarkSlateGray\0");
	strcpy(popupfgcolor, "#20B2AA\0");
	strcpy(popupbordercolor, "LightGray\0");
	strcpy(bgpix, "default\0");
	strcpy(popupbgpix, "default\0");
	interval=3;
}

void	defaults2() {

	if (strcmp(bgpix,"None")) {
		bgtexture.xpmattributes.valuemask |= (XpmReturnPixels | 
							XpmReturnExtensions);
		if (!strcmp(bgpix,"default")) {
			XpmCreatePixmapFromData(display, mainwindow, 
					surreal_xpm,
					&bgtexture.pixmap, 
					&bgtexture.mask, 
					&bgtexture.xpmattributes);
		} else {
			XpmReadFileToPixmap(display, mainwindow, bgpix, 
					&bgtexture.pixmap, 
					&bgtexture.mask, 
					&bgtexture.xpmattributes);
		}
	}

	if (strcmp(popupbgpix,"None")) {
		popupbgpixmap.xpmattributes.valuemask |= (XpmReturnPixels | 
							XpmReturnExtensions);
		if (!strcmp(popupbgpix,"default")) {
			XpmCreatePixmapFromData(display, mainwindow, 
					purplestoneswirl_xpm,
					&popupbgpixmap.pixmap, 
					&popupbgpixmap.mask, 
					&popupbgpixmap.xpmattributes);
		} else {
			if (!strcmp(popupbgpix,"Transparent") ||
				!strcmp(popupbgpix,"Translucent")) {
				popupbgpixmap.pixmap=NULL;
			} else {
				XpmReadFileToPixmap(display, mainwindow, 
					popupbgpix, 
					&popupbgpixmap.pixmap, 
					&popupbgpixmap.mask, 
					&popupbgpixmap.xpmattributes);
			}
		}
	}
}

void	parsecmdline(int argc, char *argv[]) {

	char	*argument;
	int	i;

	for (i=1; i<argc; i++) {
		argument=argv[i];
		if (argument[0]=='-') {
			if (!strncmp(argument,"-bg",3)) {
				strcpy(bgcolor, argv[++i]);
			}
			if (!strncmp(argument,"-bp",3)) {
				strcpy(bgpix, argv[++i]);
			}
			if (!strncmp(argument,"-fg",3)) {
				strcpy(fgcolor, argv[++i]);
			}
			if (!strncmp(argument,"-bd",3)) {
				strcpy(bordercolor, argv[++i]);
			}
			if (!strncmp(argument,"-pbg",4)) {
				strcpy(popupbgcolor, argv[++i]);
			}
			if (!strncmp(argument,"-pbp",4)) {
				strcpy(popupbgpix, argv[++i]);
			}
			if (!strncmp(argument,"-pfg",4)) {
				strcpy(popupfgcolor, argv[++i]);
			}
			if (!strncmp(argument,"-pbd",4)) {
				strcpy(popupbordercolor, argv[++i]);
			}
			if (!strncmp(argument,"-z",2)) {
				strcpy(zerocolor, argv[++i]);
			}
			if (!strncmp(argument,"-i",2)) {
				interval=atoi(argv[++i]);
			}
		}
	}
}

void	setuppixmaps() {

	if (strcmp(bgpix,"None")) {
		bgpixmap=bgtexture.pixmap;
	} else {
		bgpixmap=XCreatePixmap(display, mainwindow, 55, 57, 
				DefaultDepth(display, screen));
		XFillRectangle(display, bgpixmap, flipgc, 0, 0, 55, 57);
	}

	XDrawLine(display, bgpixmap, thingc, 0, 0, 56, 0);
	XDrawLine(display, bgpixmap, thingc, 1, 1, 55, 1);
	XDrawLine(display, bgpixmap, thingc, 2, 2, 54, 2);
	XDrawLine(display, bgpixmap, thingc, 0, 0, 0, 57);
	XDrawLine(display, bgpixmap, thingc, 1, 1, 1, 56);
	XDrawLine(display, bgpixmap, thingc, 2, 2, 2, 55);


	XDrawLine(display, bgpixmap, flipthingc, 54, 0, 54, 57);
	XDrawLine(display, bgpixmap, flipthingc, 53, 1, 53, 56);
	XDrawLine(display, bgpixmap, flipthingc, 52, 2, 52, 55);
	XDrawLine(display, bgpixmap, flipthingc, 0, 56, 54, 56);
	XDrawLine(display, bgpixmap, flipthingc, 1, 55, 53, 55);
	XDrawLine(display, bgpixmap, flipthingc, 2, 54, 52, 54);

	canvas=XCreatePixmap(display, mainwindow, 55, 57, 
				DefaultDepth(display, screen));

}

void	setupfonts() {

	popupfont1=XLoadQueryFont(display, 
			"-*-helvetica-*-*-*-*-10-240-*-*-*-*-*-*");
	popupfont2=XLoadQueryFont(display, 
			"-*-helvetica-medium-r-*-*-10-240-*-*-*-*-*-*");
}

void	readstatfile() {
	FILE	*tempfile;
	int	counter;
	char	dummy[21];

	tempfile=fopen("/usr/tmp/statfs", "r");
        if (tempfile!=NULL) {
		/* clear header */
		fscanf(tempfile,"%s%s%s%s%s%s%s",
				dummy, dummy, dummy, dummy, 
				dummy, dummy, dummy);
		/* read list */
		counter=0;
		while (1) {
			strcpy(fs[counter].mountdir,"");
#ifdef SCO
			fscanf(tempfile,"%s%s%s%s%s%s",
				fs[counter].mountdir,
				fs[counter].filesystem,
				fs[counter].blocks,
				fs[counter].used,
				fs[counter].free,
				fs[counter].percent);
#endif
#ifdef SUN 
			fscanf(tempfile,"%s%s%s%s%s%s",
				fs[counter].filesystem,
				fs[counter].blocks,
				fs[counter].used,
				fs[counter].free,
				fs[counter].percent,
				fs[counter].mountdir);
#endif
#ifdef LINUX
			fscanf(tempfile,"%s%s%s%s%s%s",
				fs[counter].filesystem,
				fs[counter].blocks,
				fs[counter].used,
				fs[counter].free,
				fs[counter].percent,
				fs[counter].mountdir);
#endif
			if (strlen(fs[counter].mountdir)>0 && counter<23) {	
				counter++;
			} else {
				break;
			}
		}
		fclose(tempfile);
	
		fscounter=counter;
	}
}

int	calclineheight(int num) {

	return (50-num)/num;
}

int	calclinewidth(struct fsrecord *fs, int y, int lineheight) {

	float	blocks, used, linewidth;

	blocks=(float)atoi(fs->blocks);
	if (blocks==0.0) {
		linewidth=48;
	} else {
		used=(float)atoi(fs->used);
		linewidth=(int)((used/blocks)*48.0);
	}

	/* set up fsrecord x,y's */
	fs->x1=0;
	fs->y1=y-(lineheight/2);
	fs->x2=linewidth;
	fs->y2=y+(lineheight/2);

	return linewidth;
}

void	checkusagecb(XtPointer XtP, XtIntervalId *XtI);

void	checkusage() {

	int	i, lineheight, y, linewidth;

		/* get a list of filesystems */
#ifdef SCO
		system("df -v > /usr/tmp/statfs");
#endif
#ifdef LINUX
		system("df -a > /usr/tmp/statfs");
#endif
#ifdef SUN
		system("df -a > /usr/tmp/statfs");
#endif

		readstatfile();

		/* restore canvas pixmap */
		XCopyArea(display, bgpixmap, canvas, mainwindowgc, 
				0, 0, 55, 57, 0, 0);

		/* calculate line height */
		lineheight=calclineheight(fscounter);

		XSetLineAttributes(display, mainwindowgc, lineheight, 
					LineSolid, CapButt, JoinRound);
		XSetLineAttributes(display, zerogc, lineheight, 
					LineSolid, CapButt, JoinRound);

		/* draw lines */
		y=1+(lineheight/2);
		for (i=0; i<fscounter; i++) {

			/* calculate line width */
			linewidth=calclinewidth(&fs[i], y, lineheight);

			/* draw new lines */
			if (atoi(fs[i].blocks)>0) {
				XDrawLine(display, canvas, mainwindowgc, 
					3, y+3, linewidth+3, y+3);
			} else {
				XDrawLine(display, canvas, zerogc, 
					3, y+3, linewidth+3, y+3);
			}

			if (lineheight>2 && linewidth>2) {
				if (atoi(fs[i].blocks)>0) {
					/* raised */
					XDrawLine(display, canvas, thingc,
						3, y+lineheight/2+3, 
						linewidth+3, y+lineheight/2+3);
					XDrawLine(display, canvas, flipthingc,
						3, y-lineheight/2+3, 
						linewidth+3, y-lineheight/2+3);
					XDrawLine(display, canvas, flipthingc,
						3, y+lineheight/2+3, 
						3, y-lineheight/2+3);
					XDrawLine(display, canvas, thingc,
						linewidth+3, y+lineheight/2+3, 
						linewidth+3, y-lineheight/2+3);
				} else {
					/* lowered */
					XDrawLine(display, canvas, flipthingc,
						3, y+lineheight/2+3, 
						linewidth+3, y+lineheight/2+3);
					XDrawLine(display, canvas, thingc,
						3, y-lineheight/2+3, 
						linewidth+3, y-lineheight/2+3);
					XDrawLine(display, canvas, thingc,
						3, y+lineheight/2+3, 
						3, y-lineheight/2+3);
					XDrawLine(display, canvas, flipthingc,
						linewidth+3, y+lineheight/2+3, 
						linewidth+3, y-lineheight/2+3);
				}
			}

			y=y+lineheight+1;
		}

		XCopyArea(display, canvas, mainwindow, mainwindowgc, 
				0, 0, 55, 57, 0, 0);

		/* get my stuff drawn, harmlessly */
		XPending(display);

		XtAppAddTimeOut(application, interval*1000, checkusagecb, NULL);
}

void	checkusagecb(XtPointer XtP, XtIntervalId *XtI) {

	checkusage();
}

void	translucent(Window win, int width, int height) {

	int	i;
	static	unsigned char		dotted[2]={ 1, 1 };

	gcm=GCForeground | GCLineStyle | GCCapStyle | 
				GCLineWidth;
	gcv.foreground=bgpixel;
	gcv.line_style=LineOnOffDash;
	gcv.cap_style=CapButt;
	gcv.line_width=1;
	translucentgc=XCreateGC(display, mainwindow, gcm, &gcv);
	XSetDashes(display, translucentgc, 0, dotted, 2);
	for (i=0; i<height; i++) {
		if (i%2==0) {
			XDrawLine(display, win, 
					translucentgc,
					0, i, width, i);
		} else {
			XDrawLine(display, win, 
					translucentgc,
					1, i, width, i);
		}
	}
	XFreeGC(display, translucentgc);
}

void	popdownmountwindow() {

	int i;

	if (poppedup2==1) {
		for (i=0; i<fstabcounter; i++) {
			XFreePixmap(display, mounter[i].pixmap);
			XDestroyWindow(display, iconwin[i]);
			XDestroyWindow(display, mounterwin[i]);
		}
		XDestroyWindow(display, mountwindow);
		poppedup2=0;
	}
}

void	popupfilewindow(struct fsrecord fs, int x, int y) {

	XSetWindowAttributes	setwinattr;
	int			winx, winy;
	unsigned long		pixel;

	if (poppedup1==0) {

		popdownmountwindow();
		
		poppedup1=2;

		if (x>=screenwidth/2) { 
			winx=x-12-177;
		} else {
			winx=x+12;
		}
	
		if (y>=screenheight/2) {
			winy=y-76;
		} else {
			winy=y;
		}
	 
		filewindow=XCreateSimpleWindow(display, root, winx, winy, 
						177, 76, 2, 
						popupborderpixel, popupbgpixel);
	
		setwinattr.override_redirect=True;
		if (strcmp(popupbgpix,"None")) {
			setwinattr.background_pixmap=popupbgpixmap.pixmap;
			XChangeWindowAttributes(display, filewindow, 
					CWOverrideRedirect | CWBackPixmap, 
					&setwinattr);
		} else {
			XChangeWindowAttributes(display, filewindow, 
					CWOverrideRedirect,
					&setwinattr);
		}
	
		XSetFont(display, popupgc, popupfont1->fid);
	
		XMapWindow(display, filewindow);
	
		if (!strcmp(popupbgpix,"Translucent")) {
			translucent(filewindow, 177, 76);
		}
	
		XDrawString(display, filewindow, popupgc, 2, 12, 
				"Mount Dir", 9);
		XDrawString(display, filewindow, popupgc, 2, 27, 
				"File System", 11);
		XDrawString(display, filewindow, popupgc, 2, 42, "Blocks", 6);
		XDrawString(display, filewindow, popupgc, 2, 57, "Free", 4);
		XDrawString(display, filewindow, popupgc, 2, 72, 
				"Percent Used", 12);
	
		XSetFont(display, popupgc, popupfont2->fid);
	
		XDrawString(display, filewindow, popupgc, 77, 12, fs.mountdir, 
				strlen(fs.mountdir));
		XDrawString(display, filewindow, popupgc, 77, 27, 
				fs.filesystem, 
				strlen(fs.filesystem));
		XDrawString(display, filewindow, popupgc, 77, 42, fs.blocks,
				strlen(fs.blocks));
		XDrawString(display, filewindow, popupgc, 77, 57, fs.free,
				strlen(fs.free));
		XDrawString(display, filewindow, popupgc, 77, 72, fs.percent,
				strlen(fs.percent));
	
		/* get my stuff drawn, harmlessly */
		XPending(display);
	
		poppedup1=1;
	}

}

void	readfstabfile() {

	int	i;
	FILE	*fstabfile;
	char	buffer[80];
#ifdef SCO
	char	*filename="/etc/default/filesys";
#else
	char	*filename="/etc/fstab";
#endif

	fstabcounter=0;

	/* initiate buffer to strlen >0 */
	buffer[0]=' ';
	buffer[1]=NULL;
	
	fstabfile=fopen(filename,"r");

	if (fstabfile==NULL) {
		printf("%s\n",filename);
	}

	while (strlen(buffer)>0 && fstabcounter<24) {

		buffer[0]=NULL;
	
#ifdef SCO
		fscanf(fstabfile,"%s",buffer);

		if (!strncmp(buffer,"bdev=",5)) {
			strcpy(fstab[fstabcounter].filesystem, buffer+5);
		}

		if (!strncmp(buffer,"mountdir=",9)) {
			strcpy(fstab[fstabcounter].mountdir, buffer+9);
		}
		
		if (!strncmp(buffer,"mount=yes",9)) {
			fstab[fstabcounter].user=1;
		}
		
		if (!strncmp(buffer,"mount=no",8)) {
			fstab[fstabcounter].user=0;
		}
		
		if (!strncmp(buffer,"fstyp=",6)) {
			strcpy(fstab[fstabcounter].type, buffer+6);
			fstabcounter++;
		}

#else
		i=0;
		buffer[i]=fgetc(fstabfile);
		while(buffer[i]!=10 && buffer[i]!=EOF) {
			i++;
			buffer[i]=fgetc(fstabfile);
		};

		if (buffer[i]!=EOF) {
			if (buffer[0]!='#') {
				buffer[i]=NULL;
				sscanf(buffer,"%s %s %s",
					fstab[fstabcounter].filesystem,
					fstab[fstabcounter].mountdir, 
					fstab[fstabcounter].type);
				if (!strcmp(fstab[fstabcounter].filesystem,
						"none") ||
					!strcmp(fstab[fstabcounter].mountdir,
						"swap") || 
					!strcmp(fstab[fstabcounter].mountdir,
						"/")) {
					fstab[fstabcounter].user=0;
				} else {
					fstab[fstabcounter].user=1;
				}
				fstabcounter++;
			}
		} else {
			buffer[0]=NULL;
		}
#endif

	}

	fclose(fstabfile);
}

int	mountstatus(int number) {

	int j, retval;
	
	for (j=0; j<fscounter; j++) {

		if (!strcmp(fstab[number].filesystem,fs[j].filesystem)) {
			retval=1;
			break;
		} else {
			retval=0;
		}
	}

	return retval;
}

void	mounterborder(int number) {
	if (fstab[number].user==1) {
		if (fstab[number].mounted==0) {
			XSetWindowBorder(display, mounterwin[number], redpixel);
		} else {
			XSetWindowBorder(display, mounterwin[number],
						greenpixel);
		}
	} else {
		XSetWindowBorder(display, mounterwin[number],
						yellowpixel);
	}
}

void	selectxpm(int i) {

	XpmCreatePixmapFromData(display, mainwindow, harddisk_xpm,
					&mounter[i].pixmap, 
					&mounter[i].mask, 
					&mounter[i].xpmattributes);
	if (!strcmp(fstab[i].type,"RCKRDG") || !strcmp(fstab[i].type,"iso9660") 
			|| !strcmp(fstab[i].type,"ISO9660")
			|| !strcmp(fstab[i].type,"hsfs")) {
		XpmCreatePixmapFromData(display, mainwindow, cd_xpm,
					&mounter[i].pixmap, 
					&mounter[i].mask, 
					&mounter[i].xpmattributes);
	} 
	if (strstr(fstab[i].filesystem,"zip")!=NULL) {
		XpmCreatePixmapFromData(display, mainwindow, zip_xpm,
					&mounter[i].pixmap, 
					&mounter[i].mask, 
					&mounter[i].xpmattributes);
	} 
	if (strstr(fstab[i].filesystem,"fd")!=NULL) {
		XpmCreatePixmapFromData(display, mainwindow, floppy_xpm,
					&mounter[i].pixmap, 
					&mounter[i].mask, 
					&mounter[i].xpmattributes);
	}
	if (!strcmp(fstab[i].type,"NFS") || !strcmp(fstab[i].type,"nfs")) {
		XpmCreatePixmapFromData(display, mainwindow, nfs_xpm,
					&mounter[i].pixmap, 
					&mounter[i].mask, 
					&mounter[i].xpmattributes);
	}
	if (!strcmp(fstab[i].type,"DOS") || !strcmp(fstab[i].type,"msdos")) {
		XpmCreatePixmapFromData(display, mainwindow, dos_xpm,
					&mounter[i].pixmap, 
					&mounter[i].mask, 
					&mounter[i].xpmattributes);
	}
}

void	popupmountwindow(int x, int y) {

	XSetWindowAttributes	setwinattr;
	int			winx, winy, i, longest, winwidth, winheight;
	int			posx, posy;
	unsigned long		pixel;
	static	unsigned char		dotted[2]={ 1, 1 };

	if (poppedup2==0) {

		poppedup2=2;

		readfstabfile();

		for (i=0; i<fstabcounter; i++) {
			fstab[i].mounted=mountstatus(i);
		}

		longest=48;

		/* find longest name */
		for (i=0; i<fstabcounter; i++) {
			if (strlen(fstab[i].filesystem)>longest) {
				longest=strlen(fstab[i].filesystem);
			}
			if (strlen(fstab[i].mountdir)>longest) {
				longest=strlen(fstab[i].mountdir);
			}
		}

		winwidth=(((fstabcounter-1)/3)+1)*(48+10);
		winheight=240;

		if (x>=screenwidth/2) { 
			winx=x-12-winwidth;
		} else {
			winx=x+12;
		}
	
		if (y>=screenheight/2) {
			winy=y-winheight;
		} else {
			winy=y;
		}
	 
		mountwindow=XCreateSimpleWindow(display, root, 
						winx, winy, 
						winwidth, winheight, 2,
						popupborderpixel, popupbgpixel);

		XSelectInput(display, mountwindow, ButtonPressMask);

		setwinattr.override_redirect=True;
		if (strcmp(popupbgpix,"None")) {
			setwinattr.background_pixmap=popupbgpixmap.pixmap;
			XChangeWindowAttributes(display, mountwindow, 
					CWOverrideRedirect | CWBackPixmap, 
					&setwinattr);
		} else {
			XChangeWindowAttributes(display, mountwindow, 
					CWOverrideRedirect,
					&setwinattr);
		}

		XMapWindow(display, mountwindow);
	
		if (!strcmp(popupbgpix,"Translucent")) {
			translucent(mountwindow, winwidth, winheight);
		}

		for (i=0; i<fstabcounter; i++) {
	
			XSetFont(display, popupgc, popupfont1->fid);

			posy=((i%3)*80);
			posx=((i/3)*58)+3;
	
			XDrawString(display, mountwindow, popupgc, 
				posx, posy+10, 
				fstab[i].filesystem, 
				strlen(fstab[i].filesystem));
	
			XSetFont(display, popupgc, popupfont2->fid);
	
			XDrawString(display, mountwindow, popupgc, 
				posx, posy+20, 
				fstab[i].mountdir, strlen(fstab[i].mountdir));
	 
			mounterwin[i]=XCreateSimpleWindow(display, mountwindow, 
						posx, posy+22, 
						48, 48, 2, 
						popupborderpixel, popupbgpixel);

			mounterborder(i);
			
			XSetWindowBackgroundPixmap(display, mounterwin[i], 
						NULL);

			XSelectInput(display, mounterwin[i], ButtonPressMask);
	 
			iconwin[i]=XCreateSimpleWindow(display, 
						mounterwin[i], 
						0, 0, 48, 48, 0,
						popupborderpixel, popupbgpixel);

			mounter[i].xpmattributes.valuemask = 
							(XpmReturnPixels | 
							XpmReturnExtensions);

			selectxpm(i);
			
			XSetWindowBackgroundPixmap(display, iconwin[i], 
					mounter[i].pixmap);

			XShapeCombineMask(display, iconwin[i], ShapeBounding,
					0, 0, mounter[i].mask, ShapeSet);

			XMapWindow(display, mounterwin[i]);
			XMapWindow(display, iconwin[i]);
		}
	
		/* get my stuff drawn, harmlessly */
		XPending(display);
	
		poppedup2=1;
	}

}

void	mountunmount(int number) {

	char buf[80];

	if (fstab[number].mounted==1) {

#ifdef SCO
		sprintf(buf, "umnt %s",fstab[number].mountdir);
#else
		sprintf(buf, "umount %s",fstab[number].mountdir);
#endif
		system(buf);
	} else {

#ifdef SCO
		sprintf(buf, "mnt %s",fstab[number].mountdir);
#else
		sprintf(buf, "mount %s",fstab[number].mountdir);
#endif
		system(buf);
	}
	checkusage();
	fstab[number].mounted=mountstatus(number);
	mounterborder(number);
}

void	popdownfilewindow() {

	if (poppedup1==1) {
		XDestroyWindow(display, filewindow);
		poppedup1=0;
	}
}

void	popdownfilewindowcb(Widget w, XtPointer unused, 
			register XButtonPressedEvent *event, 
			Boolean *continue_to_dispatch) {

	popdownfilewindow();
}

void	handleclick() {

	Window	dummy;
	int	rootx, rooty, winx, winy, i;
	unsigned	int	dummyui;
	int	lineheight, y, inaline=0;
	unsigned	int	mask;

	XQueryPointer(display, mainwindow, &dummy, &dummy,
			&rootx, &rooty, &winx, &winy, &mask);

	lineheight=calclineheight(fscounter);
	y=1+(lineheight/2);

	for (i=0; i<fscounter; i++) {

		calclinewidth(&fs[i], y, lineheight);

		if (winx>=fs[i].x1+3 && winx<=fs[i].x2+3 && 	
			winy>=fs[i].y1+3 && winy<=fs[i].y2+3) {

			popupfilewindow(fs[i], rootx, rooty);

			inaline=1;
		}

		y=y+lineheight+1;
	}

	if (inaline==0) {
		if (poppedup2==0) {
			popupmountwindow(rootx, rooty);
		} else {
			popdownmountwindow();
		}
	}
			
}

void	handleclickcb(Widget w, XtPointer unused, 
			register XButtonPressedEvent *event, 
			Boolean *continue_to_dispatch) {

	handleclick();
}

void	exitprogcb(Widget w, XtPointer unused, 
			register XButtonPressedEvent *event, 
			Boolean *continue_to_dispatch) {

	if (event->type==DestroyNotify) {

		XFreePixmap(display, canvas);
		XFreePixmap(display, bgpixmap);
		XFreeGC(display, mainwindowgc);
		XFreeGC(display, flipgc);
		XFreeGC(display, thingc);
		XFreeGC(display, flipthingc);
		XFreeGC(display, popupgc);
		XDestroyWindow(display, mainwindow);
 		XCloseDisplay(display);
		exit(0);
	}
}

main (int argc, char *argv[]) {

	char	*displayname=NULL;
	XEvent	report;
	int	i, exposenum=0, j;
	XTextProperty	name;
	char	*winname="asfsm";

	defaults1();
	parsecmdline(argc, argv);

	mainwidget=XtAppInitialize(&application, "asfsm", NULL, 0, &argc, argv, 
				NULL, NULL, 0);
	XtResizeWidget(mainwidget, 55, 57, 0);
	XtRealizeWidget(mainwidget);

	display=XtDisplay(mainwidget);

	screen=DefaultScreen(display);
	screenwidth=DisplayWidth(display, screen);
	screenheight=DisplayHeight(display, screen);

	root=RootWindow(display, screen);
	mainwindow=XtWindow(mainwidget);
	XtMapWidget(mainwidget);

	defaults2();

	bgpixel=getcolor(bgcolor);
	fgpixel=getcolor(fgcolor);
	zeropixel=getcolor(zerocolor);
	popupbgpixel=getcolor(popupbgcolor);
	popupfgpixel=getcolor(popupfgcolor);
	popupborderpixel=getcolor(popupbordercolor);
	redpixel=getcolor("IndianRed");
	greenpixel=getcolor("Aquamarine3");
	yellowpixel=getcolor("PeachPuff");

	gcm=GCForeground | GCBackground | GCGraphicsExposures;
	gcv.foreground=fgpixel;
	gcv.background=bgpixel;
	gcv.graphics_exposures=True;
	mainwindowgc=XCreateGC(display, mainwindow, gcm, &gcv);
	gcm=GCForeground;
	gcv.foreground=zeropixel;
	zerogc=XCreateGC(display, mainwindow, gcm, &gcv);
	gcm=GCForeground | GCBackground;
	gcv.background=fgpixel;
	gcv.foreground=bgpixel;
	flipgc=XCreateGC(display, mainwindow, gcm, &gcv);
	gcv.foreground=popupfgpixel;
	gcv.background=popupbgpixel;
	popupgc=XCreateGC(display, mainwindow, gcm, &gcv);
	gcm=GCForeground;
	gcv.foreground=getcolor("#535353");
	thingc=XCreateGC(display, mainwindow, gcm, &gcv);
	XSetLineAttributes(display, thingc, 1, 
				LineSolid, CapButt, JoinRound);
	gcv.foreground=getcolor("#dbdbdb");
	flipthingc=XCreateGC(display, mainwindow, gcm, &gcv);
	XSetLineAttributes(display, flipthingc, 1, 
				LineSolid, CapButt, JoinRound);

	setuppixmaps();
	setupfonts();
	checkusage();

	XtAddEventHandler(mainwidget, ButtonPressMask, False, 
				handleclickcb, NULL);

	XtAddEventHandler(mainwidget, ButtonReleaseMask, False, 
				popdownfilewindowcb, NULL);

	XtAddEventHandler(mainwidget, StructureNotifyMask, False, 
				exitprogcb, NULL);

	XPending(display);
	while (1) {
		
		XtAppNextEvent(application, &report);
		XtDispatchEvent(&report);
		if (poppedup2==1) {
			for (j=0; j<fstabcounter; j++) {
				if (report.type==ButtonPress && 
					report.xany.display==display &&
					report.xany.window==mounterwin[j]) {
					mountunmount(j);
				}
			}
		}
	}
}
