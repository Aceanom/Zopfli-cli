#ifndef __asppp_h
#define __asppp_h
#define __asppp_version "0.1.0 BETA"

extern int wharfShape;			/* =0 for non wharf placement */
					/* =1 if in afterstep wharf */

typedef struct _XpmIcon
{
        Pixmap pixmap;
        Pixmap mask;
        XpmAttributes attributes;
	int exec_flag;			/* 0=execute program, 1=exit program */
	char *exec_name;		/* NULL for exec_flag=1 */
        struct XpmIcon *next_xpm;
} XpmIcon;        

extern Pixel GetColor(char *colorname);
extern void XPMInit(void);
extern void ButtonHandler(Widget W, XtPointer P, XEvent *E);
extern void ExposureHandler(Widget W, XtPointer P, XEvent *E);
extern void UpdatePPP(XtPointer P, XtIntervalId *I);
extern void windowRedraw();  
extern int pppcheck(void);

#endif /* __asppp_h */
