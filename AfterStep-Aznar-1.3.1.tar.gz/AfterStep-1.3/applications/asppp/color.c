#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <stdio.h>

extern Display *dpy;

extern Window aspppWindow;

Pixel GetColor(char *colorname)
{
	XColor Color;
	XWindowAttributes Attributes;
	
	XGetWindowAttributes(dpy, aspppWindow, &Attributes);
	Color.pixel = 0;
	
	if (!XParseColor (dpy, Attributes.colormap, colorname, &Color))
		fprintf(stderr,"asmail: can't parse %s\n", colorname);

	return Color.pixel;
}
