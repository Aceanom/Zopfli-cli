#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int pppcheck(void)
{
        char *file, *tmp = malloc(256), *tmp2;
        int fd, cmp, ret;

        file = "/proc/net/route";
        fd = open (file, O_RDONLY);
        if (fd <= 0)
        {
                perror(file);
                return(-2);
        }        
	
	read(fd, tmp, 256);
        tmp2 = strpbrk("ppp", tmp);
        if (tmp2 != NULL)
        {
                cmp = strcmp(tmp2, "ppp");
                if (cmp == 0)
			ret = 1;
        } else {
		ret = 0;
	}

        free(tmp);
        close(fd);
        return(ret);
}
