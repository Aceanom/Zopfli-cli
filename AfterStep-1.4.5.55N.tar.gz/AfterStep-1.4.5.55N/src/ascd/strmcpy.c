#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/param.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include <ctype.h>
#include <sys/stat.h>  

/* Copy into a malloced string. */
void
strmcpy(t, s)
	char	**t, *s;
{
	if (*t != NULL)
		free(*t);

	*t = (char *) malloc(strlen(s) + 1);
	if (*t == NULL)
	{
		perror("strmcpy");
		exit(1);
	}

	(void) strcpy(*t, s);
}

