/*
 *--------------------------------*-C-*---------------------------------
 * File:        misc.h
 *
 * Copyright (c) 1996 Mj Olesen <olesen@me.QueensU.CA>
 *
 * You can do what you like with this source code as long as you don't try
 * to make money out of it and you include an unaltered copy of this
 * message (including the copyright).
 *
 * As usual, the author accepts no responsibility for anything, nor does
 * he guarantee anything whatsoever.
 *----------------------------------------------------------------------
 */

#ifndef _MISC_H
#define _MISC_H

/*{{{ includes */
#include <X11/Xfuncproto.h>

/*{{{ prototypes */
_XFUNCPROTOBEGIN

extern const char *
 my_basename(const char *str);

extern void
 print_error(const char *fmt,...);

extern int
 escaped_string(char *str);

extern void
 Draw_Shadow(Window /* win */ , GC /* topShadow */ , GC /* botShadow */ ,
	     int /* x */ , int /* y */ , int /* w */ , int /* h */ );

extern void
 Draw_Triangle(Window /* win */ , GC /* topShadow */ , GC /* botShadow */ ,
	       int /* x */ , int /* y */ , int /* w */ ,
	       int /* type */ );

_XFUNCPROTOEND
/*}}} */

#endif				/* whole file */
/*----------------------- end-of-file (C header) -----------------------*/
