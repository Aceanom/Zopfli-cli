#ifndef GENERAL_H
#define GENERAL_H

typedef struct ColorPair {
	unsigned long fore;
	unsigned long back;
} ColorPair;

extern char* MyName;
extern Display *dpy;
extern int screen;

#endif /* GENERAL_H */
