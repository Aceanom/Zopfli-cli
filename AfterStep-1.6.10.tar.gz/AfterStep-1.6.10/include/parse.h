/**********************************************************************
 *
 * Codes for afterstep builtins 
 *
 **********************************************************************/

#ifndef _PARSE_
#define _PARSE_

#define F_NOP			0
#define F_BEEP			1
#define F_QUIT			2
#define F_RESTART               3
#define F_REFRESH		4
#define F_TITLE			5
#define F_SCROLL                6	/* scroll the virtual desktop */
#define F_CIRCULATE_UP          7
#define F_CIRCULATE_DOWN        8
#define F_TOGGLE_PAGE           9
#define F_GOTO_PAGE             10
#define F_WINDOWLIST            11
#define F_MOVECURSOR            12
#define F_FUNCTION              13
#define F_WARP_F                14
#define F_WARP_B                15
#define F_MODULE                16
#define F_DESK                  17
#define F_CHANGE_WINDOWS_DESK   18
#define F_EXEC			19	/* string */
#define F_POPUP			20	/* string */
#define F_WAIT                  21
#define F_CLOSE                 22
#define F_QUICKRESTART          23
#define F_CHANGE_BACKGROUND	24	/* string */
#define F_CHANGE_LOOK		25	/* string */
#define F_CHANGE_FEEL		26	/* string */
#define F_UPDATESTARTMENU	27	/* string */
#define F_MINIPIXMAP		28	/* string */
#define F_KILLMODULEBYNAME	29	/* string */

/* Functions which require a target window */
#define F_RESIZE		100
#define F_RAISE			101
#define F_LOWER			102
#define F_DESTROY		103
#define F_DELETE		104
#define F_MOVE			105
#define F_ICONIFY		106
#define F_STICK                 107
#define F_RAISELOWER            108
#define F_MAXIMIZE              109
#define F_FOCUS                 110
#define F_SHADE			111
#define F_PUTONTOP		112
#define F_PUTONBACK		113
#define F_CHANGEWINDOW_UP	114
#define F_CHANGEWINDOW_DOWN	115
#define F_GETHELP		116
#define F_PASTE_SELECTION	117

/* Functions for use by modules only! */
#define F_SEND_WINDOW_LIST     1000

/* Functions for internal  only! */
#define F_RAISE_IT              2000

#endif /* _PARSE_ */
