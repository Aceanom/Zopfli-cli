/*
 * Copyright (c) 1998 Rafal Wierzbicki <rafal@mcss.mcmaster.ca>
 * Copyright (c) 1998 Sasha Vasko <sashav@sprintmail.com>
 * Copyright (c) 1998 Michal Vitecek <fuf@fuf.sh.cvut.cz>
 * Copyright (c) 1998 Nat Makarevitch <nat@linux-france.com>
 * Copyright (c) 1998 Mike Venaccio <venaccio@aero.und.edu>
 * Copyright (c) 1998 Ethan Fischer <allanon@crystaltokyo.com>
 * Copyright (c) 1998 Mike Venaccio <venaccio@aero.und.edu>
 * Copyright (c) 1998 Chris Ridd <c.ridd@isode.com>
 * Copyright (c) 1997 Raphael Goulais <velephys@hol.fr>
 * Copyright (c) 1997 Guylhem Aznar <guylhem@oeil.qc.ca> 
 * Copyright (C) 1996 Frank Fejes
 * Copyright (C) 1995 Bo Yang
 * Copyright (C) 1993 Robert Nation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/****************************************************************************
 * 
 * Configure.c: reads the configuration files, interprets them,
 * and sets up menus, bindings, colors, and fonts as specified
 *
 ***************************************************************************/

#include "../../configure.h"

#include <stdio.h>
#include <signal.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <pwd.h>
#include <dirent.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <X11/Xproto.h>
#include <X11/Xatom.h>

#ifdef I18N
#include <X11/Xlocale.h>
#endif

#ifdef XPM
#include <X11/xpm.h>
#endif

#include "../../include/aftersteplib.h"
#include "../../include/afterstep.h"
#include "../../include/menus.h"
#include "../../include/parse.h"
#include "../../include/misc.h"
#include "../../include/style.h"
#include "../../include/screen.h"
#include "../../include/dirtree.h"
#include "../../include/loadimg.h"
#include "../../include/mystyle_property.h"

MenuRoot* dirtree_make_menu2 (dirtree_t * tree, int recurse, char* buf);
int ParseMenuItem(MenuItem* item, const char* buf);
MenuItem* MenuItemParse(MenuRoot* menu, const char* buf);
char * strip_whitespace (char *str);

char *PixmapPath;
char *CursorPath;

char *global_base_file = NULL;
char *IconPath;
char *ModulePath = AFTER_BIN_DIR;

Bool shall_override_config_file;
char *config_file_to_override;
char *white = "white";
char *black = "black";
char *grey = "SlateGrey";

/*
 * the old-style look variables
 */
char *Stdfont;
char *Windowfont;
char *Iconfont;
char *Menustipple;
char *Stdback;
char *Stdfore;
char *Stickyback;
char *Stickyfore;
char *Hiback;
char *Hifore;
char *Mtitleback;
char *Mtitlefore;
char *Menuback;
char *Menufore;
char *Menuhiback;
char *Menuhifore;
/*#ifndef NO_TEXTURE */
char *TexTypes = NULL;
char *TexMaxcols = NULL;
char *TColor = NULL, *UColor = NULL, *SColor = NULL;
char *IColor = NULL, *MHColor = NULL, *MColor = NULL;
char *TPixmap = NULL, *UPixmap = NULL, *SPixmap = NULL;
char *MTPixmap = NULL, *MPixmap = NULL, *MHPixmap = NULL;
/*#endif */
/*
 * endif
 * end of old-style look variables
 */

int MeltStartMenu ();
void GetColors (void);
MenuRoot *NewMenuRoot (char *name);
void bad_binding (const int num);

int contexts;
int mods, func, func_val_1, func_val_2;

#include "../../include/stepgfx.h"
#ifndef NO_TEXTURE
char *TitleStyle = NULL;
char *TGColor = NULL;
char *MArrowPixmap = NULL;
char hincolor[15];
char hircolor[15];
char hiscolor[15];
char loncolor[15];
char lorcolor[15];
char loscolor[15];

extern void InitTextureData (TextureInfo * info, char *title, char *utitle,
	 char *mtitle, char *item, char *mhilite, char *sticky, char *text);
int IconTexType = TEXTURE_BUILTIN;
char *IconBgColor;
char *IconTexColor;
int IconMaxColors = 16;
char *IconPixmapFile;
int IconTexFlags = 0;
char *FrameN=NULL;
char *FrameS=NULL;
char *FrameE=NULL;
char *FrameW=NULL;
char *FrameNE=NULL;
char *FrameNW=NULL;
char *FrameSE=NULL;
char *FrameSW=NULL; 
#endif

int dummy;

extern XContext MenuContext;	/* context for afterstep menus */
extern Bool DoHandlePageing;

/* value for the rubberband XORing */
unsigned long XORvalue;
int RubberBand = 0;
int have_the_colors = 0;
char *RMGeom = NULL;
int Xzap = 12, Yzap = 12;
int DrawMenuBorders = 1;
int TextureMenuItemsIndividually = 1;
int AutoReverse = 0;
int AutoTabThroughDesks = 0;
int MenuMiniPixmaps = 0;
int StartMenuSortMode = DEFAULTSTARTMENUSORT;
int DecorateFrames = 0;
int ShadeAnimationSteps = 12;
void SetCustomCursor (char *text, FILE * fd, char **arg, int *junk);

void assign_string (char *text, FILE * fd, char **arg, int *);
void assign_path (char *text, FILE * fd, char **arg, int *);
void assign_pixmap (char *text, FILE * fd, char **arg, int *);

/*
 * Order is important here! if one keyword is the same as the first part of
 * another keyword, the shorter one must come first!
 */
struct config main_config[] =
{
  /* currently unused? */
  {"ReadPipeConfig", ReadPipeConfig, NULL, NULL},

  /* base options */
  {"IconPath", assign_path, &IconPath, (int *) 0},
  {"ModulePath", assign_path, &ModulePath, (int *) 0},
  {"PixmapPath", assign_path, &PixmapPath, (int *) 0},
  {"CursorPath", assign_path, &CursorPath, (int *) 0},

  /* database options */
  {"DeskTopScale", SetInts, (char **) &Scr.VScale, &dummy},
  {"DeskTopSize", SetInts, (char **) &Scr.VxMax, &Scr.VyMax},
  {"Style", style_parse, (char **) 0, (int *) 0},

  /* feel options */
  {"StubbornIcons", SetFlag, (char **) StubbornIcons, (int *) 0},
  {"StubbornPlacement", SetFlag, (char **) StubbornPlacement, (int *) 0},
  {"StubbornIconPlacement", SetFlag, (char **) StubbornIconPlacement, (int *) 0},
  {"StickyIcons", SetFlag, (char **) StickyIcons, (int *) 0},
  {"IconTitle", SetFlag, (char **) IconTitle, (int *) 0},
  {"KeepIconWindows", SetFlag, (char **) KeepIconWindows, (int *) 0},
  {"NoPPosition", SetFlag, (char **) NoPPosition, (int *) 0},
  {"CirculateSkipIcons", SetFlag, (char **) CirculateSkipIcons, (int *) 0},
  {"EdgeScroll", SetInts, (char **) &Scr.EdgeScrollX, &Scr.EdgeScrollY},
  {"RandomPlacement", SetFlag, (char **) RandomPlacement, (int *) 0},
  {"SmartPlacement", SetFlag, (char **) SMART_PLACEMENT, (int *) 0},
  {"DontMoveOff", SetFlag, (char **) DontMoveOff, (int *) 0},
  {"DecorateTransients", SetFlag, (char **) DecorateTransients, (int *) 0},
  {"CenterOnCirculate", SetFlag, (char **) CenterOnCirculate, (int *) 0},
  {"AutoRaise", SetInts, (char **) &Scr.AutoRaiseDelay, &dummy},
  {"ClickTime", SetInts, (char **) &Scr.ClickTime, &dummy},
  {"OpaqueMove", SetInts, (char **) &Scr.OpaqueSize, &dummy},
  {"OpaqueResize", SetInts, (char **) &Scr.OpaqueResize, &dummy},
  {"XorValue", SetInts, (char **) &XORvalue, &dummy},
  {"Mouse", ParseMouseEntry, (char **) 1, (int *) 0},
  {"Popup", ParsePopupEntry, (char **) 1, (int *) 0},
  {"Function", ParsePopupEntry, (char **) 1, (int *) 0},
  {"Key", ParseKeyEntry, (char **) 1, (int *) 0},
  {"ClickToFocus", SetFlag, (char **) ClickToFocus, (int *) EatFocusClick},
  {"ClickToRaise", SetButtonList, (char **) &Scr.RaiseButtons, (int *) 0},
  {"MenusHigh", SetFlag, (char **) MenusHigh, (int *) 0},
  {"SloppyFocus", SetFlag, (char **) SloppyFocus, (int *) 0},
  {"Cursor", SetCursor, (char **) 0, (int *) 0},
  {"CustomCursor", SetCustomCursor, (char **) 0, (int *) 0},
  {"PagingDefault", SetInts, (char **) &DoHandlePageing, &dummy},
  {"EdgeResistance", SetInts, (char **) &Scr.ScrollResistance, &Scr.MoveResistance},
  {"BackingStore", SetFlag, (char **) BackingStore, (int *) 0},
  {"AppsBackingStore", SetFlag, (char **) AppsBackingStore, (int *) 0},
  {"SaveUnders", SetFlag, (char **) SaveUnders, (int *) 0},
  {"Xzap", SetInts, (char **) &Xzap, (int *) &dummy},
  {"Yzap", SetInts, (char **) &Yzap, (int *) &dummy},
  {"AutoReverse", SetInts, (char **) &AutoReverse, (int *) &dummy},
  {"AutoTabThroughDesks", SetInts, (char **) &AutoTabThroughDesks, (int *) &dummy},
  {"MWMFunctionHints", SetFlag, (char **) MWMFunctionHints, NULL},
  {"MWMDecorHints", SetFlag, (char **) MWMDecorHints, NULL},
  {"MWMHintOverride", SetFlag, (char **) MWMHintOverride, NULL},
  /* look options */
  {"Font", assign_string, &Stdfont, (int *) 0},
  {"WindowFont", assign_string, &Windowfont, (int *) 0},
  {"MTitleForeColor", assign_string, &Mtitlefore, (int *) 0},
  {"MTitleBackColor", assign_string, &Mtitleback, (int *) 0},
  {"MenuForeColor", assign_string, &Menufore, (int *) 0},
  {"MenuBackColor", assign_string, &Menuback, (int *) 0},
  {"MenuHiForeColor", assign_string, &Menuhifore, (int *) 0},
  {"MenuHiBackColor", assign_string, &Menuhiback, (int *) 0},
  {"MenuStippleColor", assign_string, &Menustipple, (int *) 0},
  {"StdForeColor", assign_string, &Stdfore, (int *) 0},
  {"StdBackColor", assign_string, &Stdback, (int *) 0},
  {"StickyForeColor", assign_string, &Stickyfore, (int *) 0},
  {"StickyBackColor", assign_string, &Stickyback, (int *) 0},
  {"HiForeColor", assign_string, &Hifore, (int *) 0},
  {"HiBackColor", assign_string, &Hiback, (int *) 0},
  {"IconBox", SetBox, (char **) 0, (int *) 0},
  {"IconFont", assign_string, &Iconfont, (int *) 0},
  {"MyStyle", mystyle_parse, &PixmapPath, NULL},

#ifndef NO_TEXTURE
  {"TitleBarStyle", assign_string, &TitleStyle, (int *) 0},
  {"TextureTypes", assign_string, &TexTypes, (int *) 0},
  {"TextureMaxColors", assign_string, &TexMaxcols, (int *) 0},
  {"TitleTextureColor", assign_string, &TColor, (int *) 0},	/* title */
  {"UTitleTextureColor", assign_string, &UColor, (int *) 0},	/* unfoc tit */
  {"STitleTextureColor", assign_string, &SColor, (int *) 0},	/* stic tit */
  {"MTitleTextureColor", assign_string, &MColor, (int *) 0},	/* menu title */
  {"MenuTextureColor", assign_string, &IColor, (int *) 0},	/* menu items */
  {"MenuHiTextureColor", assign_string, &MHColor, (int *) 0},	/* sel items */
  {"MenuPixmap", assign_string, &MPixmap, (int *) 0},	/* menu entry */
  {"MenuHiPixmap", assign_string, &MHPixmap, (int *) 0},	/* hil m entr */
  {"MTitlePixmap", assign_string, &MTPixmap, (int *) 0},	/* menu title */
  {"MArrowPixmap", assign_string, &MArrowPixmap, (int *) 0},	/* menu arrow */
  {"MenuPinOn", assign_pixmap, (char **) &Scr.MenuPinOn, NULL},		/* menu pin */
  {"MenuPinOff", assign_pixmap, (char **) &Scr.MenuPinOff, NULL},
  {"TitlePixmap", assign_string, &TPixmap, (int *) 0},	/* foc tit */
  {"UTitlePixmap", assign_string, &UPixmap, (int *) 0},		/* unfoc tit */
  {"STitlePixmap", assign_string, &SPixmap, (int *) 0},		/* stick tit */
  {"TextGradientColor", assign_string, &TGColor, (int *) 0},	/* title text */
  {"TexturedHandle", SetFlag2, (char **) TexturedHandle, (int *) &Textures.flags},
  {"TitlebarNoPush", SetFlag2, (char **) TitlebarNoPush, (int *) &Textures.flags},
  {"GradientText", SetFlag2, (char **) GradientText, (int *) &Textures.flags},
  {"ButtonTextureType", SetInts, (char **) &IconTexType, &dummy},
  {"ButtonBgColor", assign_string, &IconBgColor, (int *) 0},
  {"ButtonTextureColor", assign_string, &IconTexColor, (int *) 0},
  {"ButtonMaxColors", SetInts, (char **) &IconMaxColors, &dummy},
  {"ButtonPixmap", assign_string, &IconPixmapFile, (int *) 0},
  {"ButtonNoBorder", SetFlag2, (char **) IconNoBorder, (int *) &Textures.flags},
  {"TextureMenuItemsIndividually", SetInts, (char **) &TextureMenuItemsIndividually, (int *) &dummy},
  {"MenuMiniPixmaps", SetInts, (char **) &MenuMiniPixmaps, &dummy},
#endif				/* NO_TEXTURE */
  {"TitleTextAlign", SetInts, (char **) &Scr.TitleTextAlign, &dummy},
  {"TitleButtonSpacing", SetInts, (char **) &Scr.TitleButtonSpacing, (int *) &dummy},
  {"TitleButtonStyle", SetInts, (char **) &Scr.TitleButtonStyle, (int *) &dummy},
  {"TitleButton", SetTitleButton, (char **) 1, (int *) 0},
  {"TitleTextMode", SetTitleText, (char **) 1, (int *) 0},
  {"ResizeMoveGeometry", assign_string, &RMGeom, (int *) 0},
  {"StartMenuSortMode", SetInts, (char **) &StartMenuSortMode, (int *) &dummy},
  {"DrawMenuBorders", SetInts, (char **) &DrawMenuBorders, (int *) &dummy},
  {"ButtonSize", SetInts, (char **) &Scr.ButtonWidth, (int *) &Scr.ButtonHeight},
  {"SeparateButtonTitle", SetFlag2, (char **) SeparateButtonTitle, (int *) &Textures.flags},
  {"RubberBand", SetInts, (char **) &RubberBand, &dummy},
  {"DefaultStyle", mystyle_parse_set_style, (char **) &Scr.MSDefault, NULL},
  {"FWindowStyle", mystyle_parse_set_style, (char **) &Scr.MSFWindow, NULL},
  {"UWindowStyle", mystyle_parse_set_style, (char **) &Scr.MSUWindow, NULL},
  {"SWindowStyle", mystyle_parse_set_style, (char **) &Scr.MSSWindow, NULL},
  {"MenuItemStyle", mystyle_parse_set_style, (char **) &Scr.MSMenuItem, NULL},
  {"MenuTitleStyle", mystyle_parse_set_style, (char **) &Scr.MSMenuTitle, NULL},
  {"MenuHiliteStyle", mystyle_parse_set_style, (char **) &Scr.MSMenuHilite, NULL},
  {"MenuStippleStyle", mystyle_parse_set_style, (char **) &Scr.MSMenuStipple, NULL},
  {"DecorateFrames", SetInts, (char **) &DecorateFrames, (int *) &dummy},
  {"FrameNorth", assign_string, &FrameN, (int *) 0},
  {"FrameSouth", assign_string, &FrameS, (int *) 0},
  {"FrameEast", assign_string, &FrameE, (int *) 0},
  {"FrameWest", assign_string, &FrameW, (int *) 0},
  {"FrameNW", assign_string, &FrameNW, (int *) 0},
  {"FrameNE", assign_string, &FrameNE, (int *) 0},
  {"FrameSW", assign_string, &FrameSW, (int *) 0},
  {"FrameSE", assign_string, &FrameSE, (int *) 0},
  {"ShadeAnimationSteps", SetInts, (char **) &ShadeAnimationSteps, (int *) &dummy},
  {"", 0, (char **) 0, (int *) 0}
};

struct config func_config[] =
{
  {"Nop", set_func, (char **) F_NOP},
  {"Title", set_func, (char **) F_TITLE},
  {"Beep", set_func, (char **) F_BEEP},
  {"Quit", set_func, (char **) F_QUIT},
  {"Refresh", set_func, (char **) F_REFRESH},
  {"Move", set_func, (char **) F_MOVE},
  {"Iconify", set_func, (char **) F_ICONIFY},
  {"Maximize", set_func, (char **) F_MAXIMIZE},
  {"Shade", set_func, (char **) F_SHADE},
  {"Resize", set_func, (char **) F_RESIZE},
  {"RaiseLower", set_func, (char **) F_RAISELOWER},
  {"Raise", set_func, (char **) F_RAISE},
  {"PutOnTop", set_func, (char **) F_PUTONTOP},
  {"PutOnBack", set_func, (char **) F_PUTONBACK},
  {"SetLayer", set_func, (char **) F_SETLAYER},
  {"Lower", set_func, (char **) F_LOWER},
  {"Delete", set_func, (char **) F_DELETE},
  {"Close", set_func, (char **) F_CLOSE},
  {"Destroy", set_func, (char **) F_DESTROY},
  {"PopUp", set_func, (char **) F_POPUP},
  {"Function", set_func, (char **) F_FUNCTION},
  {"CursorMove", set_func, (char **) F_MOVECURSOR},
  {"Stick", set_func, (char **) F_STICK},
  {"CirculateUp", set_func, (char **) F_CIRCULATE_UP},
  {"CirculateDown", set_func, (char **) F_CIRCULATE_DOWN},
  {"ChangeWindowUp", set_func, (char **) F_CHANGEWINDOW_UP},
  {"ChangeWindowDown", set_func, (char **) F_CHANGEWINDOW_DOWN},
  {"GetHelp", set_func, (char **) F_GETHELP},
  {"Wait", set_func, (char **) F_WAIT},
  {"WarpFore", set_func, (char **) F_WARP_F},
  {"WarpBack", set_func, (char **) F_WARP_B},
  {"Desk", set_func, (char **) F_DESK},
  {"WindowsDesk", set_func, (char **) F_CHANGE_WINDOWS_DESK},
  {"Focus", set_func, (char **) F_FOCUS},
  {"Module", set_func, (char **) F_MODULE},
  {"KillModuleByName", set_func, (char **) F_KILLMODULEBYNAME},
  {"QuickRestart", set_func, (char **) F_QUICKRESTART},
  {"Send_WindowList", set_func, (char **) F_SEND_WINDOW_LIST},
  {"PasteSelection", set_func, (char **) F_PASTE_SELECTION},
#ifndef NO_VIRTUAL
  {"Scroll", set_func, (char **) F_SCROLL},
  {"GotoPage", set_func, (char **) F_GOTO_PAGE},
  {"TogglePage", set_func, (char **) F_TOGGLE_PAGE},
#endif
  {"Exec", set_func, (char **) F_EXEC},
  {"Background", set_func, (char **) F_CHANGE_BACKGROUND},
  {"ChangeLook", set_func, (char **) F_CHANGE_LOOK},
  {"ChangeFeel", set_func, (char **) F_CHANGE_FEEL},
  {"Restart", set_func, (char **) F_RESTART},
#ifndef NO_WINDOWLIST
  {"WindowList", set_func, (char **) F_WINDOWLIST},
#endif
  {"SET_MASK", set_func, (char **) F_SET_MASK},
  {"SET_NAME", set_func, (char **) F_SET_NAME},
  {"UNLOCK", set_func, (char **) F_UNLOCK},
  {"SET_FLAGS", set_func, (char **) F_SET_FLAGS},
#ifndef NO_TEXTURE
  {"MiniPixmap", set_func, (char **) F_MINIPIXMAP},
#endif
  {"ToggleLayer", set_func, (char **) F_TOGGLELAYER},
  {"", 0, (char **) 0}
};

struct charstring
  {
    char key;
    int value;
  };


/* The keys must be in lower case! */
struct charstring win_contexts[] =
{
  {'w', C_WINDOW},
  {'t', C_TITLE},
  {'i', C_ICON},
  {'r', C_ROOT},
  {'f', C_FRAME},
  {'s', C_SIDEBAR},
  {'1', C_L1},
  {'2', C_R1},
  {'3', C_L2},
  {'4', C_R2},
  {'5', C_L3},
  {'6', C_R3},
  {'7', C_L4},
  {'8', C_R4},
  {'9', C_L5},
  {'0', C_R5},
  {'a', C_WINDOW | C_TITLE | C_ICON | C_ROOT | C_FRAME | C_SIDEBAR |
   C_L1 | C_L2 | C_L3 | C_L4 | C_L5 | C_R1 | C_R2 | C_R3 | C_R4 | C_R5
  },
  {0, 0}
};

/* The keys musat be in lower case! */
struct charstring key_modifiers[] =
{
  {'s', ShiftMask},
  {'c', ControlMask},
  {'m', Mod1Mask},
  {'1', Mod1Mask},
  {'2', Mod2Mask},
  {'3', Mod3Mask},
  {'4', Mod4Mask},
  {'5', Mod5Mask},
  {'a', AnyModifier},
  {'n', 0},
  {0, 0}
};

void find_context (char *, int *, struct charstring *);
#define PARSE_BUFFER_SIZE 	MAXLINELENGTH 
char *orig_tline = NULL;

extern ASDirs as_dirs;

int MakeASDir( const char* name, mode_t perms )
{
  fprintf (stderr, "Creating %s ... ", name);
  if (mkdir (name, perms))
  {
      fprintf (stderr, "ERROR !\n AfterStep depends on %s directory !\nPlease check permissions or contact your sysadmin !\n", name);
      return (-1);
  }
  fprintf (stderr, "done\n");
  return 0 ;
}

int MakeASFile( const char* name )
{
  FILE* touch ;
  fprintf (stderr, "Creating %s ... ", name);
  if ((touch = fopen (name, "w")) == NULL)
    {
      fprintf (stderr, "ERROR !\n Cannot open file %s for writing!\n"
	    " Please check permissions or contact your sysadmin !\n", name);
      return (-1);
    }
  fclose (touch);
  fprintf (stderr, "done\n");
  return 0 ;
}

int
CheckOrCreate (const char *what)
{
  mode_t perms = 0755;
  int res = 0;
  
  if( *what=='~' && *(what+1)=='/' )
  {
    char *checkdir = PutHome (what);
      if( CheckDir(checkdir)!= 0)  res = MakeASDir( checkdir, perms );
      free( checkdir );
  }
  else if( CheckDir(what)!= 0 )    res = MakeASDir( what, perms );

  return res;
}

int
CheckOrCreateFile (const char *what)
{
  int res = 0;
  
  if( *what=='~' && *(what+1)=='/' )
  {
    char *checkfile = PutHome (what);
      if (CheckFile (checkfile) != 0) res = MakeASFile( checkfile );
      free (checkfile);
  }else if (CheckFile (what) != 0) res = MakeASFile( what );
  
  return res;
}

/* copying file from shared dir to home dir */
int
HomeCreateIfNeeded (const char *filename)
{
  char *from, *to ;
  int res = 0;
  
  to = (char *) make_file_name(as_dirs.after_dir,filename);
  if( CheckFile(to) != 0 )
  {
      from = (char *) make_file_name(as_dirs.after_sharedir,filename);
      res = CopyFile( from, to );
      free( from );
  }
  free( to );
  return res;
}


/***************************************************************
 *
 * get an icon
 * 
 **************************************************************/
Bool
GetIconFromFile (char *file, MyIcon * icon, int max_colors)
{
  char *path = NULL;
  Bool success = False;
  unsigned int dum;
  int dummy;
  Window root;

  (*icon).pix = None;
  (*icon).mask = None;
  (*icon).width = 0;
  (*icon).height = 0;

  if ((path = findIconFile (file, PixmapPath, R_OK)) == NULL)
    return False;

  /* -1 is default for screen depth */
  if (max_colors == -1 && Scr.d_depth <= 8)
    max_colors = 10;

  if ((icon->pix = LoadImageWithMask (dpy, Scr.Root, max_colors, path, &(icon->mask))) != None)
    {
      success = True;
      XGetGeometry (dpy, icon->pix, &root, &dummy, &dummy,
		    &(icon->width), &(icon->height), &dum, &dum);
    }

  free (path);
  return success;
}

/***************************************************************
 * 
 * Read a XPM file
 * 
 **************************************************************/
Pixmap
GetXPMTile (char *file, int max_colors)
{
  MyIcon icon;
  GetIconFromFile (file, &icon, max_colors);
  if (icon.mask != None)
    UnloadMask (icon.mask);
  return icon.pix;
}

/* 
 * initialize the old-style look variables 
 */
void
init_old_look_variables (Bool free_resources)
{
  if (free_resources)
    {
      /* the fonts */
      if (Stdfont != NULL)
	free (Stdfont);
      if (Windowfont != NULL)
	free (Windowfont);
      if (Iconfont != NULL)
	free (Iconfont);

      /* the colors */
      if (Stdback != NULL)
	free (Stdback);
      if (Stdfore != NULL)
	free (Stdfore);
      if (Hiback != NULL)
	free (Hiback);
      if (Hifore != NULL)
	free (Hifore);
      if (Stickyback != NULL)
	free (Stickyback);
      if (Stickyfore != NULL)
	free (Stickyfore);
      if (Mtitlefore != NULL)
	free (Mtitlefore);
      if (Mtitleback != NULL)
	free (Mtitleback);
      if (Menuback != NULL)
	free (Menuback);
      if (Menufore != NULL)
	free (Menufore);
      if (Menuhifore != NULL)
	free (Menuhifore);
      if (Menuhiback != NULL)
	free (Menuhiback);
      if (Menustipple != NULL)
	free (Menustipple);

#ifndef NO_TEXTURE
      /* the gradients */
      if (TGColor != NULL)
	free (TGColor);
      if (UColor != NULL)
	free (UColor);
      if (TColor != NULL)
	free (TColor);
      if (SColor != NULL)
	free (SColor);
      if (MColor != NULL)
	free (MColor);
      if (IColor != NULL)
	free (IColor);
      if (MHColor != NULL)
	free (MHColor);

      /* the pixmaps */
      if (UPixmap != NULL)
	free (UPixmap);
      if (TPixmap != NULL)
	free (TPixmap);
      if (SPixmap != NULL)
	free (SPixmap);
      if (MTPixmap != NULL)
	free (MTPixmap);
      if (MPixmap != NULL)
	free (MPixmap);
      if (MHPixmap != NULL)
	free (MHPixmap);

      /* miscellaneous stuff */
      if (TexTypes != NULL)
	free (TexTypes);
      if (TexMaxcols != NULL)
	free (TexMaxcols);

      /* icons */
      if (MArrowPixmap != NULL)
	free (MArrowPixmap);
#endif
    }

  /* the fonts */
  Stdfont = NULL;
  Windowfont = NULL;
  Iconfont = NULL;

  /* the text type */
  Scr.TitleTextType = 0;

  /* the colors */
  Stdback = NULL;
  Stdfore = NULL;
  Hiback = NULL;
  Hifore = NULL;
  Stickyback = NULL;
  Stickyfore = NULL;
  Mtitlefore = NULL;
  Mtitleback = NULL;
  Menuback = NULL;
  Menufore = NULL;
  Menuhifore = NULL;
  Menuhiback = NULL;
  Menustipple = NULL;

#ifndef NO_TEXTURE
  /* the gradients */
  TGColor = NULL;
  UColor = NULL;
  TColor = NULL;
  SColor = NULL;
  MColor = NULL;
  IColor = NULL;
  MHColor = NULL;

  /* the pixmaps */
  UPixmap = NULL;
  TPixmap = NULL;
  SPixmap = NULL;
  MTPixmap = NULL;
  MPixmap = NULL;
  MHPixmap = NULL;

  /* miscellaneous stuff */
  TexTypes = NULL;
  TexMaxcols = NULL;

  /* icons */
  MArrowPixmap = NULL;
#endif
}


void
merge_old_look_colors (MyStyle * style, int type, int maxcols, char *fore, char *back, char *gradient, char *pixmap)
{
  if ((fore != NULL) && !((*style).user_flags & F_FORECOLOR))
    {
      (*style).colors.fore = GetColor (fore);
      (*style).user_flags |= F_FORECOLOR;
    }
  if ((back != NULL) && !((*style).user_flags & F_BACKCOLOR))
    {
      (*style).colors.back = GetColor (back);
      (*style).relief.fore = GetHilite ((*style).colors.back);
      (*style).relief.back = GetShadow ((*style).colors.back);
      (*style).user_flags |= F_BACKCOLOR;
    }
#ifndef NO_TEXTURE
  if ((maxcols != -1) && !((*style).user_flags & F_MAXCOLORS))
    {
      (*style).max_colors = maxcols;
      (*style).user_flags |= F_MAXCOLORS;
    }
  if (type >= 0)
    {
      switch (type)
        {
          case TEXTURE_GRADIENT:   style->texture_type = TEXTURE_GRADIENT_TL2BR; break;
          case TEXTURE_HGRADIENT:  style->texture_type = TEXTURE_GRADIENT_L2R; break;
          case TEXTURE_HCGRADIENT: style->texture_type = TEXTURE_GRADIENT_L2R; break;
          case TEXTURE_VGRADIENT:  style->texture_type = TEXTURE_GRADIENT_T2B; break;
          case TEXTURE_VCGRADIENT: style->texture_type = TEXTURE_GRADIENT_T2B; break;
          default: style->texture_type = type; break;
        }
    }
  if ((type > 0) && (type < TEXTURE_PIXMAP) && !((*style).user_flags & F_BACKGRADIENT))
    {
      if (gradient != NULL)
	{
	  int len;
	  char *color1 = NULL, *color2 = NULL;
	  gradient_t grad;
	  ReadColorValue(gradient, &color1, &len);
	  ReadColorValue(gradient + len, &color2, &len);
	  if (color1 != NULL && color2 != NULL && 
	      (type = mystyle_parse_old_gradient(type, color1, color2, &grad)) >= 0)
	    {
	      if (style->user_flags & F_BACKGRADIENT)
		{
		  free(style->gradient.color);
		  free(style->gradient.offset);
		}
	        style->gradient = grad;
	        style->texture_type = type;
		style->user_flags |= F_BACKGRADIENT;
	    }
	  else
	    fprintf (stderr, "%s: bad gradient: %s\n", MyName, gradient);
	  if (color1 != NULL) free (color1);
	  if (color2 != NULL) free (color2);
	}
    }
  else if ((type == TEXTURE_PIXMAP) && !((*style).user_flags & F_BACKPIXMAP))
    {
      if (pixmap != NULL)
	{
	  int colors = -1;
	  if ((*style).set_flags & F_MAXCOLORS)
	    colors = (*style).max_colors;
	  if (((*style).back_icon.pix = GetXPMTile (pixmap, colors)) != None)
	    (*style).user_flags |= F_BACKPIXMAP;
	  else
	    afterstep_err ("unable to load pixmap: '%s'", pixmap, NULL, NULL);
	}
    }
#endif
  (*style).set_flags = (*style).user_flags | (*style).inherit_flags;
}

static void
merge_old_look_font(MyStyle* style, MyFont* font)
{
  /* NOTE: these should have inherit_flags set, so the font is only
   *       unloaded once */
  if (style != NULL && !(style->set_flags & F_FONT))
    {
      style->font = *font;
      style->inherit_flags |= F_FONT;
      style->user_flags &= ~F_FONT; /* to prevent confusion */
      style->set_flags = style->user_flags|style->inherit_flags;
    }
}

/*
 * merge the old variables into the new styles
 * the new styles have precedence
 */
void
merge_old_look_variables (void)
{
  MyStyle* button_pixmap = mystyle_find("ButtonPixmap");
  MyStyle* button_title_focus = mystyle_find("ButtonTitleFocus");
  MyStyle* button_title_sticky = mystyle_find("ButtonTitleSticky");
  MyStyle* button_title_unfocus = mystyle_find("ButtonTitleUnfocus");
  /* the fonts */
  if (Stdfont != NULL)
    {
      if (load_font (Stdfont, &Scr.StdFont) == False)
	{
	  fprintf (stderr, "%s: unable to load font %s\n", MyName, Stdfont);
	  exit (1);
	}
      merge_old_look_font(Scr.MSMenuItem, &Scr.StdFont);
      merge_old_look_font(Scr.MSMenuHilite, &Scr.StdFont);
      merge_old_look_font(Scr.MSMenuStipple, &Scr.StdFont);
    }
  if (Windowfont != NULL)
    {
      if (load_font (Windowfont, &Scr.WindowFont) == False)
	{
	  fprintf (stderr, "%s: unable to load font %s\n", MyName, Windowfont);
	  exit (1);
	}
      merge_old_look_font(Scr.MSUWindow, &Scr.WindowFont);
      merge_old_look_font(Scr.MSFWindow, &Scr.WindowFont);
      merge_old_look_font(Scr.MSSWindow, &Scr.WindowFont);
      merge_old_look_font(Scr.MSMenuTitle, &Scr.WindowFont);
    }
  if (Iconfont != NULL)
    {
      if (load_font (Iconfont, &Scr.IconFont) == False)
	{
	  fprintf (stderr, "%s: unable to load font %s\n", MyName, Iconfont);
	  exit (1);
	}
      merge_old_look_font(button_title_focus, &Scr.IconFont);
      merge_old_look_font(button_title_sticky, &Scr.IconFont);
      merge_old_look_font(button_title_unfocus, &Scr.IconFont);
    }
  /* the text type */
  if (Scr.TitleTextType != 0)
    {
      if (((*Scr.MSUWindow).set_flags & F_TEXTSTYLE) == 0)
	{
	  (*Scr.MSUWindow).text_style = Scr.TitleTextType;
	  (*Scr.MSUWindow).user_flags |= F_TEXTSTYLE;
	  (*Scr.MSUWindow).set_flags |= F_TEXTSTYLE;
	}
      if (((*Scr.MSFWindow).set_flags & F_TEXTSTYLE) == 0)
	{
	  (*Scr.MSFWindow).text_style = Scr.TitleTextType;
	  (*Scr.MSFWindow).user_flags |= F_TEXTSTYLE;
	  (*Scr.MSFWindow).set_flags |= F_TEXTSTYLE;
	}
      if (((*Scr.MSSWindow).set_flags & F_TEXTSTYLE) == 0)
	{
	  (*Scr.MSSWindow).text_style = Scr.TitleTextType;
	  (*Scr.MSSWindow).user_flags |= F_TEXTSTYLE;
	  (*Scr.MSSWindow).set_flags |= F_TEXTSTYLE;
	}
    }
  /* the colors */
  /* for black and white - ignore user choices */
  /* for color - accept user choices */
  if (Scr.d_depth > 1)
    {
      int utype, ftype, stype, mttype, mhtype, mitype; /* texture types */
      int umax, fmax, smax, mtmax, mhmax, mimax;       /* max texture colors */

      utype = ftype = stype = mttype = mhtype = mitype = -1;
      umax = fmax = smax = mtmax = mhmax = mimax = -1;
#ifndef NO_TEXTURE
      if (TexTypes != NULL)
	sscanf (TexTypes, "%i %i %i %i %i %i", &ftype, &utype, &stype, &mttype, &mitype, &mhtype);
      if (TexMaxcols != NULL)
	sscanf (TexMaxcols, "%i %i %i %i %i %i", &fmax, &umax, &smax, &mtmax, &mimax, &mhmax);
#endif

      if (IconTexType == TEXTURE_BUILTIN)
        IconTexType = -1;

      /* check for missing 1.4.5.x keywords */
      if (Mtitlefore == NULL && Hifore != NULL)
	Mtitlefore = mystrdup (Hifore);
      if (Mtitleback == NULL && Hiback != NULL)
	Mtitleback = mystrdup (Hiback);
      if (Menuhifore == NULL && Hifore != NULL)
	Menuhifore = mystrdup (Hifore);
      if (Menuhiback == NULL && Menuback != NULL)
	{
	  mhtype = mitype;
	  mhmax = mimax;
	  Menuhiback = mystrdup (Menuback);
	  if ((MHColor == NULL) && (IColor != NULL))
	    MHColor = mystrdup (IColor);
	  if ((MHPixmap == NULL) && (MPixmap != NULL))
	    MHPixmap = mystrdup (MPixmap);
	}
      merge_old_look_colors (Scr.MSUWindow, utype, umax, Stdfore, Stdback, UColor, UPixmap);
      merge_old_look_colors (Scr.MSFWindow, ftype, fmax, Hifore, Hiback, TColor, TPixmap);
      merge_old_look_colors (Scr.MSSWindow, stype, smax, Stickyfore, Stickyback, SColor, SPixmap);
      merge_old_look_colors (Scr.MSMenuTitle, mttype, mtmax, Mtitlefore, Mtitleback, MColor, MTPixmap);
      merge_old_look_colors (Scr.MSMenuItem, mitype, mimax, Menufore, Menuback, IColor, MPixmap);
      merge_old_look_colors (Scr.MSMenuHilite, mhtype, mhmax, Menuhifore, Menuhiback, MHColor, MHPixmap);
      merge_old_look_colors (Scr.MSMenuStipple, mitype, mimax, Menustipple, Menuback, IColor, MPixmap);

      /* icon styles automagically inherit from window title styles */
      if (button_pixmap != NULL)
        {
          mystyle_merge_styles (Scr.MSFWindow, button_pixmap, 0, 0);
          merge_old_look_colors (button_pixmap, IconTexType, IconMaxColors, NULL, IconBgColor, IconTexColor, IconPixmapFile);
        }
      if (button_title_focus != NULL)
        mystyle_merge_styles (Scr.MSFWindow, button_title_focus, 0, 0);
      if (button_title_sticky != NULL)
        mystyle_merge_styles (Scr.MSSWindow, button_title_sticky, 0, 0);
      if (button_title_unfocus != NULL)
        mystyle_merge_styles (Scr.MSUWindow, button_title_unfocus, 0, 0);
    }
}

/*
 * Initialize base.#bpp variables
 */
void
InitBase (Bool free_resources)
{
  if (free_resources)
    {
      if (IconPath != NULL)
	free (IconPath);
      if (ModulePath != NULL)
	free (ModulePath);
      if (PixmapPath != NULL)
	free (PixmapPath);
    }

  IconPath = NULL;
  ModulePath = NULL;
  PixmapPath = NULL;
}

/*
 * Initialize look variables
 */
void
InitLook (Bool free_resources)
{
  int i;

  balloon_init (free_resources);

  if (free_resources)
    {
      /* styles/textures */
      while (mystyle_first != NULL)
	mystyle_delete (mystyle_first);

      /* GCs */
      if (Scr.LineGC != None)
	XFreeGC (dpy, Scr.LineGC);
      if (Scr.DrawGC != None)
	XFreeGC (dpy, Scr.DrawGC);
      if (Scr.NormalGC != None)
	XFreeGC (dpy, Scr.NormalGC);
      if (Scr.StippleGC != None)
	XFreeGC (dpy, Scr.StippleGC);
      if (Scr.ScratchGC1 != None)
	XFreeGC (dpy, Scr.ScratchGC1);
      if (Scr.ScratchGC2 != None)
	XFreeGC (dpy, Scr.ScratchGC2);

      /* fonts */
      unload_font (&Scr.StdFont);
      unload_font (&Scr.WindowFont);
      unload_font (&Scr.IconFont);

#ifndef NO_TEXTURE
      /* icons */
      if (Scr.MenuArrow.pix != None)
	UnloadImage (Scr.MenuArrow.pix);
      if (Scr.MenuPinOn.pix != None)
	UnloadImage (Scr.MenuPinOn.pix);
      if (Scr.MenuPinOff.pix != None)
	UnloadImage (Scr.MenuPinOff.pix);

      /* cached gradients */
      if (Scr.TitleGradient != None)
	XFreePixmap (dpy, Scr.TitleGradient);
#endif /* !NO_TEXTURE */

      /* titlebar buttons */
      for (i = 0; i < 10; i++)
	{
	  if (Scr.button_pixmap[i] != None)
	    UnloadImage (Scr.button_pixmap[i]);
	  if (Scr.dbutton_pixmap[i] != None)
	    UnloadImage (Scr.dbutton_pixmap[i]);
	}

      /* iconized window background */
      if (IconBgColor != NULL)
	free (IconBgColor);
      if (IconTexColor != NULL)
	free (IconTexColor);
      if (IconPixmapFile != NULL)
	free (IconPixmapFile);

      /* resize/move window geometry */
      if (RMGeom != NULL)
	free (RMGeom);
    }
  /* styles/textures */
  mystyle_first = NULL;
  Scr.MSDefault = NULL;
  Scr.MSFWindow = NULL;
  Scr.MSUWindow = NULL;
  Scr.MSSWindow = NULL;
  Scr.MSMenuTitle = NULL;
  Scr.MSMenuItem = NULL;
  Scr.MSMenuHilite = NULL;
  Scr.MSMenuStipple = NULL;

  /* GCs */
  Scr.LineGC = None;
  Scr.DrawGC = None;
  Scr.NormalGC = None;
  Scr.StippleGC = None;
  Scr.ScratchGC1 = None;
  Scr.ScratchGC2 = None;

  /* fonts */
  Scr.StdFont.name = NULL;
  Scr.WindowFont.name = NULL;
  Scr.IconFont.name = NULL;
  Scr.StdFont.font = NULL;
  Scr.WindowFont.font = NULL;
  Scr.IconFont.font = NULL;
#ifdef I18N
  Scr.StdFont.fontset = NULL;
  Scr.WindowFont.fontset = NULL;
  Scr.IconFont.fontset = NULL;
#endif

#ifndef NO_TEXTURE
  /* icons */
  Scr.MenuArrow.pix = Scr.MenuArrow.mask = None;
  Scr.MenuPinOn.pix = Scr.MenuPinOn.mask = None;
  Scr.MenuPinOff.pix = Scr.MenuPinOff.mask = None;

  /* cached gradients */
  Scr.TitleGradient = None;

  /* titlebar text */
  Scr.TitleStyle = TITLE_OLD;
#endif /* !NO_TEXTURE */
  Scr.TitleTextAlign = 0;

  /* titlebar buttons */
  Scr.nr_right_buttons = 0;
  Scr.nr_left_buttons = 0;
  Scr.ButtonType = 0;
  Scr.TitleButtonSpacing = 2;
  Scr.TitleButtonStyle = 0;
  for (i = 0; i < 10; i++)
    {
      Scr.button_style[i] = NO_BUTTON_STYLE;
      Scr.button_width[i] = 0;
      Scr.button_height[i] = 0;
      Scr.button_pixmap[i] = None;
      Scr.button_pixmap_mask[i] = None;
      Scr.dbutton_pixmap[i] = None;
      Scr.dbutton_pixmap_mask[i] = None;
    }

  /* iconized window background */
  IconTexType = TEXTURE_BUILTIN;
  IconBgColor = NULL;
  IconTexColor = NULL;
  IconPixmapFile = NULL;
  Scr.ButtonWidth = 0;
  Scr.ButtonHeight = 0;

  /* resize/move window geometry */
  RMGeom = NULL;

  /* miscellaneous stuff */
  RubberBand = 0;
  DrawMenuBorders = 1;
  TextureMenuItemsIndividually = 1;
  Textures.flags = SeparateButtonTitle;
  MenuMiniPixmaps = 0;
  Scr.NumBoxes = 0;
}

/*
 * Initialize feel variables
 */
void
InitFeel (Bool free_resources)
{
  if (free_resources)
    {
      MouseButton *mb = Scr.MouseButtonRoot;
      FuncKey *fk = Scr.FuncKeyRoot.next;
      while (mb != NULL)
	{
	  MouseButton *next = (*mb).NextButton;
	  if ((*mb).item != NULL)
	    free ((*mb).item);
	  free (mb);
	  mb = next;
	}
      while (fk != NULL)
	{
	  FuncKey *next = (*fk).next;
	  if ((*fk).name != NULL)
	    free ((*fk).name);
	  if ((*fk).action != NULL)
	    free ((*fk).action);
	  free (fk);
	  fk = next;
	}
    }
  StartMenuSortMode = 0;
  AutoReverse = 0;
  AutoTabThroughDesks = 0;
  DoHandlePageing = True;
  Xzap = 12;
  Yzap = 12;
  StartMenuSortMode = DEFAULTSTARTMENUSORT;
  Scr.VScale = 1;
  Scr.EdgeScrollX = Scr.EdgeScrollY = -100000;
  Scr.ScrollResistance = Scr.MoveResistance = 0;
  Scr.OpaqueSize = 5;
  Scr.OpaqueResize = 0;
  Scr.ClickTime = 150;
  Scr.AutoRaiseDelay = 0;
  Scr.RaiseButtons = 0;
  Scr.flags = 0;

  Scr.MouseButtonRoot = NULL;
  Scr.FuncKeyRoot.next = NULL;
}

/*
 * Initialize database variables
 */
void
InitDatabase (Bool free_resources)
{
  if (free_resources)
    {
      while (Scr.TheList != NULL)
	style_delete (Scr.TheList);
      if (Scr.DefaultIcon != NULL)
	free (Scr.DefaultIcon);
    }
  Scr.TheList = NULL;
  Scr.DefaultIcon = NULL;
}

/*
 * Create/destroy window titlebar/buttons as necessary.
 */
void
titlebar_sanity_check (void)
{
  int i;
  ASWindow *t;

  for (i = 4; i >= 0; i--)
    if (Scr.button_style[i * 2 + 1] != NO_BUTTON_STYLE)
      break;
  Scr.nr_left_buttons = i + 1;
  for (i = 4; i >= 0; i--)
    if (Scr.button_style[(i * 2 + 2) % 10] != NO_BUTTON_STYLE)
      break;
  Scr.nr_right_buttons = i + 1;
  /* traverse window list and redo the titlebar/buttons if necessary */
  for (t = Scr.ASRoot.next; t != NULL; t = t->next)
    {
      if (t->flags & TITLE)
	{
	  int width = t->frame_width;
	  int height = t->frame_height;
	  init_titlebutton_windows (t, True);
	  create_titlebutton_windows (t);
	  t->frame_width = t->frame_height = 0;	/* force reconfigure titlebar */
	  SetupFrame (t, t->frame_x, t->frame_y, width, height, 0);
	  XMapSubwindows (dpy, t->frame);
	}
    }
}

void
make_styles (void)
{
/* make sure the globals are defined */
  if (Scr.MSDefault == NULL)
    {
      if ((Scr.MSDefault = mystyle_find ("default")) == NULL)
	Scr.MSDefault = mystyle_new_with_name ("default");
    }
  /* for now, the default style must be named "default" */
  else if (mystrcasecmp ((*Scr.MSDefault).name, "default"))
    {
      free ((*Scr.MSDefault).name);
      (*Scr.MSDefault).name = mystrdup ("default");
    }
  if (Scr.MSFWindow == NULL)
    Scr.MSFWindow = mystyle_new_with_name ("FWindow");
  if (Scr.MSUWindow == NULL)
    Scr.MSUWindow = mystyle_new_with_name ("UWindow");
  if (Scr.MSSWindow == NULL)
    Scr.MSSWindow = mystyle_new_with_name ("SWindow");
  if (Scr.MSMenuTitle == NULL)
    Scr.MSMenuTitle = mystyle_new_with_name ("MenuTitle");
  if (Scr.MSMenuItem == NULL)
    Scr.MSMenuItem = mystyle_new_with_name ("MenuItem");
  if (Scr.MSMenuHilite == NULL)
    Scr.MSMenuHilite = mystyle_new_with_name ("MenuHilite");
  if (Scr.MSMenuStipple == NULL)
    Scr.MSMenuStipple = mystyle_new_with_name ("MenuStipple");
  if (mystyle_find("ButtonPixmap") == NULL)
    mystyle_new_with_name ("ButtonPixmap");
  if (mystyle_find("ButtonTitleFocus") == NULL)
    mystyle_new_with_name ("ButtonTitleFocus");
  if (mystyle_find("ButtonTitleSticky") == NULL)
    mystyle_new_with_name ("ButtonTitleSticky");
  if (mystyle_find("ButtonTitleUnfocus") == NULL)
    mystyle_new_with_name ("ButtonTitleUnfocus");
}

void CheckASTree(int thisdesk, Bool parse_look, Bool parse_feel )
{
  char file[255];

    /* Create missing directories & put there defaults */
    if(CheckDir (as_dirs.afters_noncfdir)!= 0)
    {
      int i ;
        fprintf (stderr, "\n");
	CheckOrCreate (GNUSTEP);
	CheckOrCreate (GNUSTEPLIB);
        CheckOrCreate (as_dirs.after_dir);
        CheckOrCreate (as_dirs.afters_noncfdir);
        CheckOrCreateFile (AFTER_SAVE);
      
	for (i = 0; i < 4; i++)
	{
	    sprintf (file, BACK_FILE, i);
	    HomeCreateIfNeeded (file);
	}
    }
    if( parse_look )
    {
	sprintf (file, LOOK_FILE, thisdesk, Scr.d_depth);
	HomeCreateIfNeeded (file);
    }
    if( parse_feel )
    {
	sprintf (file, FEEL_FILE, thisdesk, Scr.d_depth);
	HomeCreateIfNeeded (file);
    }

}

void ParseConfigFile(const char* file)
{
  char* realfilename ;
  FILE* fp = NULL ;
  register char* ptr ;
  static char* tline ;

    /* memory management for parsing buffer */
    if( file == NULL )
    {
	if( tline ) free(tline);
	tline = NULL ;
	return ;
    }

    realfilename = make_file_name(as_dirs.after_dir,file);  
    if (CheckFile(realfilename)!= 0)
    {
	free (realfilename);
	realfilename = make_file_name(as_dirs.after_sharedir,file);
        if (CheckFile(realfilename)!= 0)
	{
	    free( realfilename );
	    return ;
	}
    }
    /* this should not happen, but still checking */ 
    if((fp = fopen (realfilename, "r"))== (FILE *) NULL)
    {
	afterstep_err ("can't open %s, exiting now.\nIf this file exists, please type the full path.", file, NULL, NULL);
	exit (1);
    }
    free (realfilename);

    if( tline == NULL )	tline = safemalloc( PARSE_BUFFER_SIZE );
    
    while( fgets (tline, PARSE_BUFFER_SIZE - 1, fp))
    {
        /* prventing buffer overflow */
	*(tline+PARSE_BUFFER_SIZE - 1) = '\0' ;
	/* remove comments from the line */
	ptr = stripcomments(tline);
	/* parsing the line */
        orig_tline = ptr;
	if (*ptr != '\0' && *ptr != '#' && *ptr != '*')
	    match_string (main_config, ptr, "error in config:", fp);
    }
    fclose (fp);
}

/*****************************************************************************
 * 
 * This routine is responsible for reading and parsing the config file
 *
 ****************************************************************************/
/* MakeMenus - for those who can't remember LoadASConfig's real name */
void
LoadASConfig (const char *display_name, int thisdesktop, Bool parse_menu,
	      Bool parse_look, Bool parse_feel)
{
  ASWindow *t;
  int parse_base = 1, parse_database = 1;

#ifndef DIFFERENTLOOKNFEELFOREACHDESKTOP
  /* only one look & feel should be used */
  thisdesktop = 0;
#endif /* !DIFFERENTLOOKNFEELFOREACHDESKTOP */

  /* keep client window geometry, and nuke old frame geometry */
  for (t = Scr.ASRoot.next; t != NULL; t = t->next)
    get_client_geometry (t, t->frame_x, t->frame_y, t->frame_width, t->frame_height, &t->frame_x, &t->frame_y, &t->frame_width, &t->frame_height);

  /* kludge: make sure functions get updated */
  if (parse_menu)
    parse_feel = True;

  /* always parse database */
  InitDatabase (True);

  /* base.* variables */
  if (parse_base || shall_override_config_file)
    {
      InitBase (True);
      Scr.VxMax = 1;
      Scr.VyMax = 1;
    }

  if (parse_look || shall_override_config_file)
    {
      InitLook (True);
      frame_init (True);
      init_old_look_variables (True);
    }

  if (parse_feel || shall_override_config_file)
    InitFeel (True);

  XORvalue = (((unsigned long) 1) << Scr.d_depth) - 1;

  /* initialize some lists */
  Scr.DefaultIcon = NULL;

  /* free pixmaps that are no longer in use */
  pixmap_ref_purge();

  fprintf (stderr, "Detected colordepth : %d. Loading configuration ", Scr.d_depth);
  if (!shall_override_config_file)
  {
    char configfile[255];

      CheckASTree(thisdesktop,parse_look,parse_feel);
      if( parse_base )
      {
          sprintf (configfile, "%s.%dbpp", BASE_FILE, Scr.d_depth);
	  ParseConfigFile( configfile );
          /* Save base filename to pass to modules */
	  if (global_base_file != NULL)   free (global_base_file);
	  global_base_file = mystrdup(configfile);
      }
      fprintf (stderr, ".");
      if( parse_look )
      {
          sprintf (configfile, LOOK_FILE, thisdesktop, Scr.d_depth);
	  ParseConfigFile( configfile );
      }
      fprintf (stderr, ".");
      if( parse_menu )
      {
          MeltStartMenu (); 
      }
      fprintf (stderr, ".");
      if( parse_feel )
      {
	  sprintf (configfile, FEEL_FILE, thisdesktop, Scr.d_depth);
	  ParseConfigFile( configfile );
      }
      fprintf (stderr, ".");
      sprintf (configfile, AUTOEXEC_FILE);
      ParseConfigFile( configfile );
      fprintf (stderr, ".");
      sprintf (configfile, DATABASE_FILE);
      ParseConfigFile( configfile );
      fprintf (stderr, ".");
  }else
  {
      /* Yes, override config file */
      ParseConfigFile( config_file_to_override );
      fprintf (stderr, "......");
  }

  /* let's free the memory used for parsing */
  ParseConfigFile(NULL);
  fprintf (stderr, ". Done.\n");

  if (parse_base || shall_override_config_file)
    {
      Scr.VxMax = Scr.VxMax * Scr.MyDisplayWidth - Scr.MyDisplayWidth;
      Scr.VyMax = Scr.VyMax * Scr.MyDisplayHeight - Scr.MyDisplayHeight;
      if (Scr.VxMax < 0)
        Scr.VxMax = 0;
      if (Scr.VyMax < 0)
        Scr.VyMax = 0;

      if (Scr.VxMax == 0)
        Scr.flags &= ~EdgeWrapX;
      if (Scr.VyMax == 0)
        Scr.flags &= ~EdgeWrapY;
    }

  if (parse_look || shall_override_config_file)
    {
      /* make sure all needed styles are created */
      make_styles ();

      /* merge pre-1.5 compatibility keywords */
      merge_old_look_variables ();

      /* fill in remaining members with the default style */
      mystyle_fix_styles ();

      mystyle_set_property(dpy, Scr.Root, _AS_STYLE, XA_INTEGER);

#ifndef NO_TEXTURE
      if (MArrowPixmap != NULL && !GetIconFromFile (MArrowPixmap, &Scr.MenuArrow, -1))
	fprintf (stderr, "couldn't load menu arrow pixmap\n");

      if ((Textures.flags & GradientText) && TGColor != NULL &&
	  ParseColor (TGColor, Textures.TGfrom, Textures.TGto) == True)
	    {
	      XColor color[2];
	      double offset[2];
	      color[0].red = Textures.TGfrom[0];
	      color[0].green = Textures.TGfrom[1];
	      color[0].blue = Textures.TGfrom[2];
	      color[1].red = Textures.TGto[0];
	      color[1].green = Textures.TGto[1];
	      color[1].blue = Textures.TGto[2];
	      offset[0] = 0.0;
	      offset[1] = 1.0;
	      Scr.TitleGradient = XCreatePixmap (dpy, Scr.Root, Scr.MyDisplayWidth - 1,
				 (*Scr.MSFWindow).font.height, Scr.d_depth);
	      draw_gradient(dpy, Scr.TitleGradient, 0, 0, 
			    Scr.MyDisplayWidth - 1, Scr.MSFWindow->font.height,
			    2, color, offset, 0, 2, 6, 40);
	    }
#endif /* ! NO_TEXTURE */

      /* update frame geometries */
      if (DecorateFrames)
        frame_create_gcs ();
    }

  /* update the resize/move window geometry */
  if (parse_look || shall_override_config_file)
    {
      int invalid_RMGeom = 0;
      int x = 0, y = 0;
      int width, height;
      height = (*Scr.MSFWindow).font.height + SIZE_VINDENT * 2;
      Scr.SizeStringWidth = XTextWidth ((*Scr.MSFWindow).font.font, " +8888 x +8888 ", 15);
      XSetWindowBorder (dpy, Scr.SizeWindow, (*Scr.MSFWindow).colors.fore);
      XSetWindowBackground (dpy, Scr.SizeWindow, (*Scr.MSFWindow).colors.back);

      width = Scr.SizeStringWidth + SIZE_HINDENT * 2;

      if ((RMGeom != NULL) && (strlen (RMGeom) == 2))
	{
	  if (RMGeom[0] == '+')
	    x = 0;
	  else if (RMGeom[0] == '-')
	    x = DisplayWidth (dpy, Scr.screen) - width;
	  else
	    invalid_RMGeom = 1;

	  if (RMGeom[1] == '+')
	    y = 0;
	  else if (RMGeom[1] == '-')
	    y = DisplayHeight (dpy, Scr.screen) - height;
	  else
	    invalid_RMGeom = 1;
	}
      else
	invalid_RMGeom = 1;	/* not necessarily invalid--maybe unspecified */

      if (invalid_RMGeom)
	{
	  /* the default case is, of course, to center the R/M window */
	  x = (DisplayWidth (dpy, Scr.screen) - width) / 2;
	  y = (DisplayHeight (dpy, Scr.screen) - height) / 2;
	}
      XMoveResizeWindow (dpy, Scr.SizeWindow, x, y, width, height);
    }

  if (parse_look || shall_override_config_file)
    GetColors ();

  if (parse_feel || shall_override_config_file)
    {
      /* If no edge scroll line is provided in the setup file, use a default */
      if (Scr.EdgeScrollX == -100000)
	Scr.EdgeScrollX = 25;
      if (Scr.EdgeScrollY == -100000)
	Scr.EdgeScrollY = Scr.EdgeScrollX;

      if ((Scr.flags & ClickToRaise) && (Scr.AutoRaiseDelay == 0))
	Scr.AutoRaiseDelay = -1;

      /* if edgescroll >1000 and < 100000m
       * wrap at edges of desktop (a "spherical" desktop) */
      if (Scr.EdgeScrollX >= 1000)
	{
	  Scr.EdgeScrollX /= 1000;
	  Scr.flags |= EdgeWrapX;
	}
      if (Scr.EdgeScrollY >= 1000)
	{
	  Scr.EdgeScrollY /= 1000;
	  Scr.flags |= EdgeWrapY;
	}
      Scr.EdgeScrollX = Scr.EdgeScrollX * Scr.MyDisplayWidth / 100;
      Scr.EdgeScrollY = Scr.EdgeScrollY * Scr.MyDisplayHeight / 100;
    }

  /* update the menus */
  if (parse_look || parse_feel || parse_menu || shall_override_config_file)
    {
      MenuRoot* menu;
      for (menu = Scr.first_menu; menu != NULL; menu = (*menu).next)
        MakeMenu (menu);
    }

  /* reset the window frame geometries */
  for (t = Scr.ASRoot.next; t != NULL; t = t->next)
    {
      name_list nl;

      style_init(&nl);
      style_fill_by_name(&nl, t->name, NULL, t->class.res_name, t->class.res_class);
      if (!(nl.off_flags & STYLE_FOCUS_FLAG) || (t->style_focus = mystyle_find(nl.style_focus)) == NULL)
	t->style_focus = Scr.MSFWindow;
      if (!(nl.off_flags & STYLE_UNFOCUS_FLAG) || (t->style_unfocus = mystyle_find(nl.style_unfocus)) == NULL)
	t->style_unfocus = Scr.MSUWindow;
      if (!(nl.off_flags & STYLE_STICKY_FLAG) || (t->style_sticky = mystyle_find(nl.style_sticky)) == NULL)
	t->style_sticky = Scr.MSSWindow;
      
      set_titlebar_geometry (t);
      frame_set_positions (t);
      get_frame_geometry (t, t->frame_x, t->frame_y, t->frame_width, t->frame_height, &t->frame_x, &t->frame_y, &t->frame_width, &t->frame_height);
    }

  /* setup the titlebar buttons */
  if (parse_look || shall_override_config_file)
    {
      balloon_setup(dpy);
      balloon_set_style(dpy, mystyle_find_or_default("TitleButtonBalloon"));
      titlebar_sanity_check ();
    }

  /* grab the new button/keybindings */
  if (parse_feel || shall_override_config_file)
    {
      ASWindow *win;
      for (win = Scr.ASRoot.next; win != NULL; win = win->next)
	{
	  XUngrabKey (dpy, AnyKey, AnyModifier, win->w);
	  XUngrabButton (dpy, AnyButton, AnyModifier, win->w);
	  GrabKeys (win);
	  GrabButtons (win);
	}
    }

  /* force update of window frames */
  if (!parse_feel || shall_override_config_file)
    {
      ASWindow *win;
      for (win = Scr.ASRoot.next; win != NULL; win = win->next)
	{
#ifndef NO_TEXTURE
	  win->bp_width = -1;	/* force recreate gradients */
#endif
	  SetupFrame (win, win->frame_x, win->frame_y, win->frame_width, win->frame_height, 0);
	  SetBorder (win, Scr.Hilite == win, True, True, None);
	}
    }

  /* redo icons in case IconBox, ButtonSize, SeparateButtonTitle, or one 
   * of the Icon definitions in database changed */
  if (parse_database || parse_look || shall_override_config_file)
    {
      ASWindow *win;
      for (win = Scr.ASRoot.next; win != NULL; win = win->next)
        ChangeIcon (win);
      AutoPlaceStickyIcons ();
    }
}

/*****************************************************************************
 * 
 * Copies a text string from the config file to a specified location
 *
 ****************************************************************************/

void
assign_string (char *text, FILE * fd, char **arg, int *junk)
{
  *arg = stripcpy (text);
}

/*****************************************************************************
 * 
 * Copies a PATH string from the config file to a specified location
 *
 ****************************************************************************/

void
assign_path (char *text, FILE * fd, char **arg, int *junk)
{
  *arg = stripcpy (text);
  replaceEnvVar (arg);
}

/*****************************************************************************
 *
 * Loads a pixmap to the assigned location
 *
 ****************************************************************************/

void
assign_pixmap (char *text, FILE * fd, char **arg, int *junk)
{
  char *tmp = stripcpy (text);
  if (!GetIconFromFile (tmp, (MyIcon *) arg, -1))
    fprintf (stderr, "unable to load icon '%s'\n", tmp);
  free (tmp);
}

/****************************************************************************
 *
 *  Read TitleText Controls
 *
 ****************************************************************************/

void
SetTitleText (char *tline, FILE * fd, char **junk, int *junk2)
{
#ifndef NO_TEXTURE
  int n;
  int ttype, y;
  n = sscanf (tline, "%d %d %s %s %s %s %s %s", &ttype, &y, hircolor,
	      hiscolor, hincolor, lorcolor, loscolor, loncolor);

  if (n != 8)
    {
      fprintf (stderr, "wrong number of parameters given to TitleText\n");
      fprintf (stderr, "t=%i y=%i 1=%s 2=%s 3=%s 4=%s 5=%s 6=%s\n", ttype, y, hircolor,
	       hiscolor, hincolor, lorcolor, loscolor, loncolor);
      return;
    }
  Scr.TitleTextType = ttype;
  Scr.TitleTextY = y;
#endif /* !NO_TEXTURE */
}

/****************************************************************************
 * 
 *  Read Titlebar pixmap button
 *
 ****************************************************************************/

void
SetTitleButton (char *tline, FILE * fd, char **junk, int *junk2)
{
  extern char *PixmapPath;
  char *path = NULL;
  int num;
  char file[256], file2[256];
  int fnamelen = 0, offset = 0, linelen;
  int n;
  unsigned int dum;
  int dummy;
  Window root;
  int width, height;

  if (balloon_parse(tline, fd))
    return;

  linelen = strlen (tline);
  if ((n = sscanf (tline, "%d", &num)) <= 0)
    {
      fprintf (stderr, "wrong number of parameters given with TitleButton\n");
      return;
    }
  if (num < 0 || num > 9)
    {
      fprintf (stderr, "invalid Titlebar button number: %d\n", num);
      return;
    }
  /* going the hard way to prevent buffer overruns */
  while (isspace (*(tline + offset)) && offset < linelen)
    offset++;
  while (isdigit (*(tline + offset)) && offset < linelen)
    offset++;
  while (isspace (*(tline + offset)) && offset < linelen)
    offset++;
  for (; !isspace (*(tline + offset)) && offset < linelen; offset++)
    if (fnamelen < 254)
      file[fnamelen++] = *(tline + offset);

  file[fnamelen] = '\0';
  if (fnamelen)
    {
      while (isspace (*(tline + offset)) && offset < linelen)
	offset++;
      for (fnamelen = 0; !isspace (*(tline + offset)) && offset < linelen; offset++)
	if (fnamelen < 254)
	  file2[fnamelen++] = *(tline + offset);
      file2[fnamelen] = '\0';
    }
  if (fnamelen == 0)
    {
      fprintf (stderr, "wrong number of parameters given with TitleButton\n");
      return;
    }


  path = findIconFile (file, PixmapPath, R_OK);
  if (path == NULL)
    {
      fprintf (stderr, "couldn't find Titlebar button %s\n", file);
      return;
    }
  Scr.button_pixmap[num] = LoadImageWithMask (dpy, Scr.Root, 256, path, &Scr.button_pixmap_mask[num]);
  free (path);
  if (Scr.button_pixmap[num] == None)
    return;

  XGetGeometry (dpy, Scr.button_pixmap[num], &root, &dummy, &dummy,
	   &(Scr.button_width[num]), &(Scr.button_height[num]), &dum, &dum);
  Scr.button_style[num] = XPM_BUTTON_STYLE;

  /* check if the button's height is bigger that the current highest one */
  if ((path = findIconFile (file2, PixmapPath, R_OK)) == NULL)
    {
      fprintf (stderr, "couldn't find Titlebar button %s\n", file2);
      return;
    }
  Scr.ButtonType = 1;

  Scr.dbutton_pixmap[num] = LoadImageWithMask (dpy, Scr.Root, 256, path, &Scr.dbutton_pixmap_mask[num]);
  free (path);
  if (Scr.dbutton_pixmap[num] == None)
    return;

  XGetGeometry (dpy, Scr.dbutton_pixmap[num], &root, &dummy, &dummy,
		&width, &height, &dum, &dum);

  Scr.button_width[num] = max (width, Scr.button_width[num]);
  Scr.button_height[num] = max (height, Scr.button_height[num]);
  Scr.button_style[num] = XPM_BUTTON_STYLE;
}

/*****************************************************************************
 * 
 * Changes a cursor def.
 *
 ****************************************************************************/

void
SetCursor (char *text, FILE * fd, char **arg, int *junk)
{
  int num, cursor_num, cursor_style;

  num = sscanf (text, "%d %d", &cursor_num, &cursor_style);
  if ((num != 2) || (cursor_num >= MAX_CURSORS) || (cursor_num < 0))
    {
      afterstep_err ("Bad Cursor in line %s", orig_tline, NULL, NULL);
      return;
    }
  Scr.ASCursors[cursor_num] = XCreateFontCursor (dpy, cursor_style);
}

void SetCustomCursor (char *text, FILE * fd, char **arg, int *junk)
{ 
  int num, cursor_num;
  char f_cursor[1024], f_mask[1024];
  Pixmap cursor = None, mask = None;
  int width, height, x, y;
  XColor fore, back;
  char *path;

  num = sscanf (text, "%d %s %s", &cursor_num, f_cursor, f_mask);
  if ((num != 3) || (cursor_num >= MAX_CURSORS) || (cursor_num < 0))
    {
      afterstep_err ("Bad Cursor in line %s", orig_tline, NULL, NULL);
      return;
    }

  path = findIconFile (f_mask, CursorPath, R_OK);
  if (path)
  {
    XReadBitmapFile (dpy, Scr.Root, path, &width, &height, &mask, &x, &y);
    free (path);
  }
  else
  {
    afterstep_err ("Cursor mask not found in line %s", orig_tline, NULL, NULL);
    return;
  }

  path = findIconFile (f_cursor, CursorPath, R_OK);
  if (path)
  {
    XReadBitmapFile (dpy, Scr.Root, path, &width, &height, &cursor,
                     &x, &y);
    free (path);
  }
  else
  {
    afterstep_err ("Cursor bitmap not found in line %s",
                   orig_tline, NULL, NULL);
    return;
  }        

  fore.pixel = BlackPixel (dpy, screen);
  back.pixel = WhitePixel (dpy, screen);
  XQueryColor (dpy, DefaultColormap (dpy, screen), &fore);
  XQueryColor (dpy, DefaultColormap (dpy, screen), &back);

  if (cursor == None || mask == None)
  {
    afterstep_err ("Unrecognized format for cursor, line: %s", orig_tline,
                   NULL, NULL);
    return;
  }
  Scr.ASCursors[cursor_num] = XCreatePixmapCursor (dpy, cursor, mask, &fore,
                                                   &back, x, y);
  XFreePixmap (dpy, mask);
  XFreePixmap (dpy, cursor);
}
/*****************************************************************************
 * 
 * Sets a boolean flag to true
 *
 ****************************************************************************/

void
SetFlag (char *text, FILE * fd, char **arg, int *another)
{
  Scr.flags |= (unsigned long) arg;
  if (another)
    {
      long i = strtol (text, NULL, 0);
      if (i)
	Scr.flags |= (unsigned long) another;
    }
}

void
SetFlag2 (char *text, FILE * fd, char **arg, int *var)
{
  unsigned long* flags = (unsigned long*) var;
  char* ptr;
  int val = strtol(text, &ptr, 0);
  if (flags == NULL)
    flags = &Scr.flags;
  if (ptr != text && val == 0)
    *flags &= ~(unsigned long) arg;
  else
    *flags |= (unsigned long) arg;
}

/*****************************************************************************
 * 
 * Reads in one or two integer values
 *
 ****************************************************************************/

void
SetInts (char *text, FILE * fd, char **arg1, int *arg2)
{
  sscanf (text, "%d%*c%d", (int *) arg1, (int *) arg2);
}

/*****************************************************************************
 * 
 * Reads in a list of mouse button numbers
 *
 ****************************************************************************/

void
SetButtonList (char *text, FILE * fd, char **arg1, int *arg2)
{
  int i, b;
  char *next;
  for (i = 0; i < MAX_BUTTONS; i++)
    {
      b = (int) strtol (text, &next, 0);
      if (next == text)
	break;
      text = next;
      if (*text == ',')
	text++;
      if ((b > 0) && (b <= MAX_BUTTONS))
	Scr.RaiseButtons |= 1 << b;
    }
  Scr.flags |= ClickToRaise;
}


/*****************************************************************************
 * 
 * Reads Dimensions for an icon box from the config file
 *
 ****************************************************************************/

void
SetBox (char *text, FILE * fd, char **arg, int *junk)
{
  int x1, y1, x2, y2, num;

  if (Scr.NumBoxes >= MAX_BOXES)
    {
      fprintf (stderr, "too many IconBoxes (max is %d)\n", MAX_BOXES);
      return;
    }

  /* Standard X11 geometry string */
  num = sscanf (text, "%d%d%d%d", &x1, &y1, &x2, &y2);

  /* check for negative locations */
  if (x1 < 0)
    x1 += Scr.MyDisplayWidth;
  if (y1 < 0)
    y1 += Scr.MyDisplayHeight;

  if (x2 < 0)
    x2 += Scr.MyDisplayWidth;
  if (y2 < 0)
    y2 += Scr.MyDisplayHeight;

  if (num < 4 || x1 >= x2 || y1 >= y2 ||
   x1 < 0 || x1 > Scr.MyDisplayWidth || x2 < 0 || x2 > Scr.MyDisplayWidth ||
   y1 < 0 || y1 > Scr.MyDisplayHeight || y2 < 0 || y2 > Scr.MyDisplayHeight)
    fprintf (stderr, "invalid IconBox '%s'\n", text);
  else
    {
      Scr.IconBoxes[Scr.NumBoxes][0] = x1;
      Scr.IconBoxes[Scr.NumBoxes][1] = y1;
      Scr.IconBoxes[Scr.NumBoxes][2] = x2;
      Scr.IconBoxes[Scr.NumBoxes][3] = y2;
      Scr.NumBoxes++;
    }
}

/****************************************************************************
 *
 * These routines put together files from start directory
 *
 ***************************************************************************/

/*
 * only checks first word in name, to allow full command lines with
 * options to be passed
 */
int 
is_executable_in_path (const char *name)
{
  static char* cache=NULL;
  static int cache_result = 0, cache_len = 0, cache_size = 0;
  static char* env_path=NULL;
  static int max_path = 0;
  register int i ;

  if( name == NULL )
  {
      if( cache ) 
      {
          free(cache);
          cache = NULL ;
      }
      cache_size = 0 ;
      cache_len = 0 ;
      if( env_path ) 
      {
          free( env_path );
          env_path = NULL ;
      }
      max_path = 0 ;
      return 0;
  }

  /* cut leading "exec" enclosed in spaces */
  for (; isspace (*name); name++);
  if (!strncmp (name, "exec", 4) && isspace (name[4]))
    name += 4;
  for (; isspace (*name); name++);
  if( *name == '\0') return 0;

  for (i = 0 ; *(name+i) && !isspace (*(name+i)); i++);
  if( i == 0 ) return 0;

  if( cache )
      if( i == cache_len && strncmp(cache, name, i ) == 0 ) 
          return cache_result ;

  if( i > cache_size )
  {
      if(cache) free(cache);
      /* allocating slightly more space then needed to avoid 
         too many reallocations */
      cache = (char*)safemalloc(i+(i>>1)+1);
      cache_size = i+(i>>1) ;      
  }
  strncpy( cache, name, i);
  cache[i] = '\0' ;
  cache_len = i ;      

  if( *cache == '/')   cache_result = (CheckFile(cache)==0)?1:0;
  else
    {
      char *ptr, *path;
      struct stat st ;

      if( env_path == NULL )
      {
	  env_path = mystrdup(getenv ("PATH"));
	  replaceEnvVar (&env_path);
	  for( ptr = env_path ; *ptr ; ptr+=i )
	  {
	      if( *ptr == ':' ) ptr++ ;
	      for( i = 0 ; *(ptr+i) && *(ptr+i)!=':' ; i++ );
	      if( i >max_path ) max_path = i ;
	  }
      } 
      path = safemalloc (max_path + cache_len + 2);
      cache_result = 0 ;
      for( ptr = env_path ; *ptr && cache_result==0; ptr+=i )
      {
          if( *ptr == ':' ) ptr++ ;
          for( i = 0 ; *(ptr+i) && *(ptr+i)!=':' ; i++ )
	      path[i] = *(ptr+i);
	  path[i] = '/';
	  path[i+1] = '\0';
	  strcat(path,cache);
	  if ((stat (path, &st) != -1) && (st.st_mode & S_IXUSR))
	      cache_result = 1;
      }
      free (path);
    }
  return cache_result;
}

/* we assume buf is at least 8192 bytes */
MenuRoot* 
dirtree_make_menu2 (dirtree_t * tree, int recurse, char* buf)
{
/*  extern struct config* func_config; */
  dirtree_t *t;
  MenuRoot* menu;

  /* make self */
  if (tree->flags & DIRTREE_KEEPNAME)
    menu = NewMenuRoot (tree->name);
  else
    {
      sprintf(buf, "%d", tree->flags & DIRTREE_ID);
      menu = NewMenuRoot (buf);
    }

  /* make title */
  sprintf (buf, "Title \"%s\"\n", tree->name);
  MenuItemParse(menu, buf);
  if (MenuMiniPixmaps)
    {
      sprintf (buf, "MiniPixmap \"%s\"\n", tree->icon != NULL ? tree->icon : "mini-menu.xpm");
      MenuItemParse(menu, buf);
    }

  for (t = tree->child ; t != NULL ; t = t->next)
    if (t->flags & DIRTREE_DIR)
      dirtree_make_menu2 (t, recurse, buf);

  for (t = tree->child ; t != NULL ; t = t->next)
    {
      if (t->flags & DIRTREE_DIR)
        {
          if (t->flags & DIRTREE_KEEPNAME)
            sprintf (buf, "PopUp \"%s\" %s\n", t->name, t->name);
          else
            sprintf (buf, "PopUp \"%s\" %d\n", t->name, t->flags & DIRTREE_ID);
          MenuItemParse(menu, buf);

          if (MenuMiniPixmaps)
            {
              if (t->icon != NULL)
                sprintf (buf, "MiniPixmap \"%s\"\n", t->icon);
              else if (t->flags & DIRTREE_DIR)
                sprintf (buf, "MiniPixmap \"mini-folder.xpm\"\n");
              MenuItemParse(menu, buf);
            }
        }
      else if (t->command != NULL && *t->command != '\0')
        {
          sprintf (buf, "%s \"%s\" %s\n", t->command, t->name, t->path);
          MenuItemParse(menu, buf);
          if (MenuMiniPixmaps && t->icon != NULL)
            {
              sprintf (buf, "MiniPixmap \"%s\"\n", t->icon);
              MenuItemParse(menu, buf);
            }
        }
      else
        {
          FILE *fp2 = fopen (t->path, "r");
          /* try to load a command */
          if (fp2 != NULL && fgets (buf, 8192, fp2) != NULL)
            {
              struct config *config = find_config (func_config, buf);
              char *ptr = strip_whitespace (buf);
              if (config != NULL && !isspace (buf[strlen (config->keyword)]))
                config = NULL;
              if (config == NULL && 13 + strlen (t->name) + strlen (ptr) < 8192)
                {
                  memmove (ptr + 13 + strlen (t->name), ptr, strlen (ptr) + 1);
                  sprintf (ptr, "Exec \"%s\" exec", t->name);
                  ptr[strlen (ptr)] = ' ';
                }
              if (config == NULL || !mystrcasecmp (config->keyword, "Exec"))
                {
#ifndef NO_AVAILABILITYCHECK
                  char *tmp;
                  for (tmp = ptr + 4; isspace (*tmp); tmp++);
                  if (*tmp == '"')
                    {
                      for (tmp++; *tmp != '\0' && *tmp != '"'; tmp++);
                      if (*tmp == '"')
                        {
                            if (!is_executable_in_path (tmp+1))
                    	    {
                              if (config != NULL)
                                memcpy (ptr, "Nop ", 4);
                              else
                                sprintf (ptr = buf, "Nop \"%s\"", t->name);
                            }
                        }
                    }
#endif /* NO_AVAILABILITYCHECK */
                }
              MenuItemParse(menu, ptr);
            }
          else
            {
              sprintf (buf, "Exec \"%s\" exec %s\n", t->name, t->name);
              MenuItemParse(menu, buf);
            }
          /* check for a MiniPixmap */
          if (MenuMiniPixmaps)
            {
              if (fp2 != NULL && fgets (buf, 8192, fp2) != NULL)
                {
                  char *ptr = strip_whitespace (buf);
                  if (!mystrncasecmp (ptr, "MiniPixmap", 10))
                     MenuItemParse(menu, ptr);
                }
              if (t->icon != NULL)
                {
                  sprintf (buf, "  MiniPixmap \"%s\"\n", t->icon);
                  MenuItemParse(menu, buf);
                }
            }
          fclose (fp2);
        }
    }
  return menu;
}

int
MeltStartMenu ()
{
  char *as_start = NULL;
  dirtree_t *tree;
  char buf[8193];

  switch (StartMenuSortMode)
    {
    case SORTBYALPHA:
      dirtree_compar_list[0] = dirtree_compar_order;
      dirtree_compar_list[1] = dirtree_compar_type;
      dirtree_compar_list[2] = dirtree_compar_alpha;
      dirtree_compar_list[3] = NULL;
      break;

    case SORTBYDATE:
      dirtree_compar_list[0] = dirtree_compar_order;
      dirtree_compar_list[1] = dirtree_compar_type;
      dirtree_compar_list[2] = dirtree_compar_mtime;
      dirtree_compar_list[3] = NULL;
      break;

    default:
      dirtree_compar_list[0] = NULL;
      break;
    }

  /* 
   *    Here we test the existence of various  
   *    directories used for the generation.
   */

  if( CheckDir (as_dirs.after_dir) == 0 )
  {
      as_start = make_file_name( as_dirs.after_dir, START_DIR );
      if( CheckDir(as_start) != 0 )
      {
          free( as_start );
	  as_start = NULL ;
      }
  }
  if( as_start == NULL )
  {
      printf ("Using system wide defaults from '%s'", as_dirs.after_sharedir);
      as_start = make_file_name( as_dirs.after_sharedir, START_DIR );
      if( CheckDir(as_start) != 0 )
      {
          free( as_start );
          perror ("unable to locate the menu directory");
	  Done (0, NULL);
	  return 0 ;
      }
  }
  tree = dirtree_new_from_dir (as_start);
  free (as_start);

#ifdef FIXED_DIR
  {
    char *as_fixeddir = make_file_name(as_dirs.after_sharedir,FIXED_DIR);
    if( CheckDir(as_fixeddir)==0)
    {
      dirtree_t *fixed_tree = dirtree_new_from_dir (as_fixeddir);
	free (as_fixeddir);
	dirtree_move_children (tree, fixed_tree);
	dirtree_delete (fixed_tree);
    } else perror ("unable to locate the fixed menu directory");
    free( as_fixeddir );
  }
#endif /* FIXED_DIR */

  dirtree_parse_include (tree);
  dirtree_remove_order (tree);
  dirtree_merge (tree);
  dirtree_sort (tree);
  dirtree_set_id (tree, 0);
  /* make sure one copy of the root menu uses the name "0" */
  (*tree).flags &= ~DIRTREE_KEEPNAME;
  dirtree_make_menu2 (tree, 1, &(buf[0]));
  /* to keep backward compatibility, make a copy of the root menu with 
   * the name "start" */
  {
    if ((*tree).name != NULL)
      free ((*tree).name);
    (*tree).name = mystrdup ("start");
    (*tree).flags |= DIRTREE_KEEPNAME;
    dirtree_make_menu2 (tree, 0, &(buf[0]));
  }
  /* cleaning up cache of the searcher*/
  is_executable_in_path(NULL);
 
  dirtree_delete (tree);
  return 0;
}

/****************************************************************************
 *
 * This routine loads all needed colors, and fonts,
 * and creates the GC's
 *
 ***************************************************************************/
MenuRoot* FindPopup( char* name )
{
  MenuRoot *mr = NULL;
    if( name == NULL )      fprintf (stderr, "Empty Popup name specifyed!\n");
    else
    {
	for (mr = Scr.first_menu; mr != NULL; mr = (*mr).next)
    	    if (mystrcasecmp ((*mr).name, name) == 0)   break ;
	if( mr == NULL ) 
	    fprintf (stderr, "Popup '%s' not defined!\n", name);
    }
    return mr ;
}


void
GetColors (void)
{
  if (have_the_colors)
    return;

  have_the_colors = 1;

  /* create graphics contexts */
  CreateGCs ();
  XSync (dpy, 0);
  return;
}

void scanForHotkeys (MenuItem * it, int which);

MenuItem* NewMenuItem(MenuRoot* menu)
{
  MenuItem *item = safemalloc(sizeof(MenuItem));

  item->prev = menu->last;
  item->next = NULL;
  if (menu->first == NULL)
    menu->first = item;
  else
    menu->last->next = item;
  menu->last = item;

  item->item = NULL;
  item->item2 = NULL;
  item->action = NULL;
  item->item_num = menu->items++;
  item->menu = NULL;
  item->x = 0;
  item->x2 = 0;
  item->y_offset = 0;
  item->y_height = 0;
  item->func = 0;
  item->val1 = 0;
  item->val2 = 0;
  item->val1_unit = 0;
  item->val2_unit = 0;
  item->is_hilited = False;
  item->strlen = 0;
  item->strlen2 = 0;
  item->hotkey = 0;
  item->menu = NULL;
  item->icon.pix = None;
  item->icon.mask = None;
  item->icon.width = 0;
  item->icon.height = 0;
  return item;
}

int ParseMenuItem(MenuItem* item, const char* buf)
{
  char* tmp, *action;
  if (item == NULL || buf == NULL)
    return -1;
  for ( ; isspace (*buf) ; buf++);
  if (*buf == '\0' || *buf == '#' || *buf == '*')
    return -1;
  func = -1;
  match_string (func_config, (char*)buf, "bad menu body function:", NULL);
  if (func == -1)
    return -1;
  if (func == F_MINIPIXMAP)
    {
      if (MenuMiniPixmaps)
        {
	  tmp = stripcpy2 (buf, 1);
	  GetIconFromFile (tmp, &item->icon, -1);
	  free (tmp);
	}
      return func;
    }

  if (func == F_EXEC || func == F_POPUP || func == F_RESTART ||
      func == F_FUNCTION || func == F_MODULE || func == F_CHANGE_BACKGROUND)
    action = stripcpy3 (buf, True);
  else
    action = stripcpy3 (buf, False);

  item->val1 = 0;
  item->val2 = 0;
  item->val1_unit = 's';
  item->val2_unit = 's';

  /* default values for Maximize are "100s 100s" */
  if (func == F_MAXIMIZE)
    {
      item->val1 = 100;
      item->val2 = 100;
    }

  if (action != NULL && *action )
    {
      tmp = parse_func_args( action, (char*)&(item->val1_unit), (int*)&(item->val1) );
      tmp = parse_func_args( tmp, (char*)&(item->val2_unit), (int*)&(item->val2) );
    }
  tmp = stripcpy2 (buf, 1);
  if ((tmp != NULL && *tmp != '\0') || func == F_NOP)
    {
	  char* tmp2 = stripcpy2 (buf, 2);
	  item->func = func;
	  item->item = tmp;
	  item->strlen = (tmp != NULL) ? strlen(tmp) : 0;
	  item->item2 = tmp2;
	  item->strlen2 = (tmp2 != NULL) ? strlen(tmp2) : 0;
	  if (func == F_POPUP || func == F_FUNCTION)
	      if((item->menu = FindPopup( action )) == NULL )
		  func = F_NOP;

	  item->action = action;
	  item->val1_unit = (item->val1_unit == 'p' || item->val1_unit == 'P') ? 100 : Scr.MyDisplayWidth;
	  item->val2_unit = (item->val2_unit == 'p' || item->val2_unit == 'P') ? 100 : Scr.MyDisplayHeight;
	  tmp = NULL;
	  action = NULL;

	  item->hotkey = 0;
	  if (item->item != NULL)
	    scanForHotkeys(item, 1);
	  if (item->item2 != NULL)
	    scanForHotkeys(item, -1);
    }
  if (action != NULL)
    free (action);
  if (tmp != NULL)
    free (tmp);
  return func;
}

MenuItem* MenuItemParse(MenuRoot* menu, const char* buf)
{
  MenuItem* item;
  for ( ; isspace (*buf) ; buf++);
  if (*buf == '\0' || *buf == '#' || *buf == '*')
    return NULL;
  item = menu->last;
  if (mystrncasecmp(buf, "MiniPixmap", 10))
    item = NewMenuItem(menu);
  ParseMenuItem(item, buf);
  return item;
}

/****************************************************************************
 * 
 *  Processes a menu body definition
 *
 ****************************************************************************/

MenuRoot *
ParseMenuBody (char *name, FILE * fd)
{
  MenuRoot *mr;
  char newline[MAXLINELENGTH];
  register char *pline;

  pline = fgets (newline, (sizeof newline) - 1, fd);
  orig_tline = pline;
  if (pline == NULL)
    return 0;

  for (mr = Scr.first_menu; mr != NULL; mr = mr->next)
    if (!strcmp (name, (*mr).name))
      {
	DeleteMenuRoot (mr);
	break;
      }
  mr = NewMenuRoot (name);
/* �� GetColors(); */


  while (isspace ((unsigned char) *pline))
    pline++;
  while ((pline != (char *) 0)
	 && (mystrncasecmp ("End", pline, 3) != 0))
    {
      if (*pline != '\0' && *pline != '#' && *pline != '*')
	{
          if (!mystrncasecmp(pline, "MiniPixmap", 10))
	    ParseMenuItem(mr->last, pline);
          else
	    ParseMenuItem(NewMenuItem(mr), pline);
	}
      pline = fgets (newline, (sizeof newline) - 1, fd);
      if (pline == (char *) 0)
	return NULL;

      orig_tline = pline;

      while (isspace ((unsigned char) *pline))
	pline++;
    }
  return mr;
}


/****************************************************************************
 * 
 *  Parses a popup definition 
 *
 ****************************************************************************/

void
ParsePopupEntry (char *tline, FILE * fd, char **junk, int *junk2)
{
  MenuRoot *mr = 0;
  char *tmp;

  tmp = stripcpy2 (tline, 0);
  mr = ParseMenuBody (tmp, fd);
  free (tmp);

  if (strcmp (mr->name, "InitFunction") == 0)
    {
      Scr.InitFunction = mr;
    }
  else if (strcmp (mr->name, "RestartFunction") == 0)
    {
      Scr.RestartFunction = mr;
    }
}

/****************************************************************************
 * 
 *  Parses a mouse binding
 *
 ****************************************************************************/
void
ParseMouseEntry (char *tline, FILE * fd, char **junk, int *junk2)
{
  char *tmp = NULL;
  MenuRoot *mr = 0;
  MenuItem *mi = 0;
  MouseButton *temp;
  int button = 0;
  char unit_1, unit_2;
  
  while( isspace(*tline) )tline++ ;
  while( isdigit( *tline ) )
  {
      button = button*10 + (int)((*tline)-'0');
      tline++ ;
  }
  
  tline = parse_token( tline, &tmp ); 
  if( tmp )
  {
      find_context (tmp, &contexts, win_contexts);
      free( tmp );
  }
  
  tline = parse_token( tline, &tmp ); 
  if( tmp )
  {
      find_context (tmp, &mods, key_modifiers);
      free( tmp );
  }
  
  tline = parse_token( tline, &tmp ); 
  if( tmp )
  {
      func = F_NOP;
      match_string (func_config, tmp, "bad mouse function:", fd);
      free( tmp );
  }

  if ((contexts & C_WINDOW) && (((mods == 0) || mods == AnyModifier)))
    {
      Scr.buttons2grab &= ~(1 << (button - 1));
    }

  if ((func == F_POPUP) || (func == F_FUNCTION))
    {
      tmp = stripcpy2 (tline, 0);
      if((mr = FindPopup(tmp)) == NULL )func = F_NOP;
      if (tmp)	free (tmp);
    }
  else if ((func == F_EXEC) || (func == F_RESTART) ||
	   (func == F_CIRCULATE_UP) || (func == F_CIRCULATE_DOWN) ||
	   (func == F_WARP_F) || (func == F_WARP_B) || (func == F_MODULE) ||
	   (func == F_CHANGE_BACKGROUND))
    {

      mi = (MenuItem *)	safemalloc (sizeof (MenuItem));

      mi->next = (MenuItem *) NULL;
      mi->prev = (MenuItem *) NULL;
      mi->item_num = 0;
      if ((func == F_EXEC) || (func == F_RESTART) || (func == F_MODULE) || (func == F_CHANGE_BACKGROUND))
	{
	  mi->item = stripcpy2 (tline, 0);
	  mi->action = stripcpy3 (tline, True);
	}
      else
	{
	  mi->item = stripcpy2 (tline, 0);
	  mi->action = stripcpy3 (tline, False);
	}
      mi->is_hilited = False;
      mi->func = func;
      mi->strlen = (mi->item != NULL) ? strlen (mi->item) : 0;
      mi->val1 = 0;
      mi->val2 = 0;
      mi->val1_unit = 1;
      mi->val2_unit = 1;
    }else

  unit_1 = 's';
  unit_2 = 's';
  /* default values for Maximize are "100s 100s" */
  if (func == F_MAXIMIZE)
    {
      func_val_1 = 100;
      func_val_2 = 100;
    }
  else
    {
      func_val_1 = 0;
      func_val_2 = 0;
    }

  tline = parse_func_args( tline, &unit_1, &func_val_1 );
  tline = parse_func_args( tline, &unit_2, &func_val_2 );

  temp = Scr.MouseButtonRoot;
  Scr.MouseButtonRoot = (MouseButton *) safemalloc (sizeof (MouseButton));
  Scr.MouseButtonRoot->func = func;
  Scr.MouseButtonRoot->menu = mr;
  Scr.MouseButtonRoot->item = mi;
  Scr.MouseButtonRoot->Button = button;
  Scr.MouseButtonRoot->Context = contexts;
  Scr.MouseButtonRoot->Modifier = mods;
  Scr.MouseButtonRoot->NextButton = temp;
  Scr.MouseButtonRoot->val1 = func_val_1;
  Scr.MouseButtonRoot->val2 = func_val_2;
  if ((unit_1 == 'p') || (unit_1 == 'P'))
    Scr.MouseButtonRoot->val1_unit = 100;
  else
    Scr.MouseButtonRoot->val1_unit = Scr.MyDisplayWidth;
  if ((unit_2 == 'p') || (unit_2 == 'P'))
    Scr.MouseButtonRoot->val2_unit = 100;
  else
    Scr.MouseButtonRoot->val2_unit = Scr.MyDisplayHeight;

  return;
}
/****************************************************************************
 * 
 *  Processes a line with a key binding
 *
 ****************************************************************************/

void
ParseKeyEntry (char *tline, FILE * fd, char **junk, int *junk2)
{
  char *tmp;
  char *name;
  MenuRoot *mr = 0;
  char unit_1, unit_2;

  tline = parse_token( tline, &name ); 
  tline = parse_token( tline, &tmp ); 
  if( tmp )
  {
      find_context (tmp, &contexts, win_contexts);
      free( tmp );
  }
  
  tline = parse_token( tline, &tmp ); 
  if( tmp )
  {
      find_context (tmp, &mods, key_modifiers);
      free( tmp );
  }
  
  tline = parse_token( tline, &tmp ); 
  if( tmp )
  {
      func = F_NOP;
      match_string (func_config, tmp, "bad key function:", fd);
      free( tmp );
  }
  /* Make CirculateUp and CirculateDown take args. by Y.NOMURA */
  tmp = NULL ;
  if ((func == F_CIRCULATE_UP) || (func == F_CIRCULATE_DOWN) ||
      (func == F_WARP_F) || (func == F_WARP_B))
      tmp = stripcpy3 (tline, False);
  
  else if ((func == F_EXEC) || (func == F_RESTART) || 
           (func == F_MODULE) || (func == F_CHANGE_BACKGROUND))
      tmp = stripcpy3 (tline, True);
  
  else if ((func == F_POPUP) || (func == F_FUNCTION))
      if((mr = FindPopup(tmp = stripcpy2 (tline, 0))) == NULL )
          func = F_NOP;

  func_val_1 = 0;
  func_val_2 = 0;
  unit_1 = 's';
  unit_2 = 's';
  tline = parse_func_args( tline, &unit_1, &func_val_1 );
  tline = parse_func_args( tline, &unit_2, &func_val_2 );
  
  AddFuncKey (name, contexts, mods, func, tmp, func_val_1, func_val_2, mr,
	      unit_1, unit_2);
  if (tmp) free (tmp);
  if(name) free( name );
}

/****************************************************************************
 * 
 * Sets menu/keybinding/mousebinding function to specified value
 *
 ****************************************************************************/

void
set_func (char *text, FILE * fd, char **value, int *junk)
{
  func = (unsigned long) value;
}

/* Nat
 *  'ReadPipeConfig' cfg instruction
 *  let's read the stdout of a process (via popen(3)), which contains config
 *  instructions
 */

void
ReadPipeConfig (char *text, FILE * fd, char **value, int *junk)
{
  FILE *pipeFileIn;		/* input channel from the popen'ed process */
  FILE *fileOut;		/* tmp file storing the popen results */
  char errMsg[128], tmpFileName[PATH_MAX];
  int readChar;
  static int semaCounter = 0;

  semaCounter++;		/* counter of ReadPipeConfig embedded calls (probably due to
				   some ReadPipeConfig containing a ReadPipeConfig) */

  sprintf (errMsg, "ReadPipeConfig (%d)", semaCounter);

  if (tmpnam (tmpFileName) == NULL)
    {
      afterstep_err (errMsg, "cannot tmpnam", NULL, NULL);
      semaCounter--;
      return;
    }
  if ((fileOut = fopen (tmpFileName, "w")) == NULL)
    {
      afterstep_err (errMsg, "cannot open the temp file", tmpFileName, NULL);
      semaCounter--;
      return;
    }
  if ((pipeFileIn = popen (text, "r")) == NULL)
    {
      afterstep_err (errMsg, "cannot open the piped process", text, NULL);
      semaCounter--;
      return;
    }
  while ((readChar = fgetc (pipeFileIn)) != EOF)
    {
      if (fputc (readChar, fileOut) == EOF)
	{
	  afterstep_err (errMsg, "cannot write into the temp file", tmpFileName, NULL);
	  pclose (pipeFileIn);
	  fclose (fileOut);
	  unlink (tmpFileName);

	  semaCounter--;
	  return;
	}
    }

  if (fclose (fileOut) != 0)
    {
      afterstep_err (errMsg, "cannot close the temp file", tmpFileName, NULL);
      pclose (pipeFileIn);
      unlink (tmpFileName);
      semaCounter--;
      return;
    }
  if (pclose (pipeFileIn) == -1)
    {
      afterstep_err (errMsg, "cannot pclose", tmpFileName, NULL);
      unlink (tmpFileName);
      semaCounter--;
      return;
    }
  /* Nat: which function may I call here in order to get the
     'tmpFileName'-named file read as a configuration file? */

  unlink (tmpFileName);
  semaCounter--;
}

/****************************************************************************
 * 
 * Turns a  string context of context or modifier values into an array of 
 * true/false values (bits)
 *
 ****************************************************************************/

void
find_context (char *string, int *output, struct charstring *table)
{
  int i = 0, j = 0;
  Bool matched;
  char tmp1;

  *output = 0;
  i = 0;
  while (i < strlen (string))
    {
      j = 0;
      matched = FALSE;
      while ((!matched) && (table[j].key != 0))
	{
	  /* in some BSD implementations, tolower(c) is not defined
	   * unless isupper(c) is true */
	  tmp1 = string[i];
	  if (isupper (tmp1))
	    tmp1 = tolower (tmp1);
	  /* end of ugly BSD patch */

	  if (tmp1 == table[j].key)
	    {
	      *output |= table[j].value;
	      matched = TRUE;
	    }
	  j++;
	}
      if (!matched)
	{
	  fprintf (stderr, "afterstep: bad entry %c in line %s",
		   string[i], orig_tline);
	}
      i++;
    }
  return;
}

/****************************************************************************
 * 
 * Matches text from config to a table of strings, calls routine
 * indicated in table.
 *
 ****************************************************************************/

void
match_string (struct config *table, char *text, char *error_msg, FILE * fd)
{
  table = find_config (table, text);
  if (table != NULL)
  {
    for( text += strlen (table->keyword) ; isspace(*text); text++ );
    table->action(text, fd, table->arg, table->arg2);
  }
  else
    afterstep_err ("%s %s in line %s", error_msg, text, orig_tline);

}


/****************************************************************************
 * 
 * Generates the window for a menu
 *
 ****************************************************************************/
void
MakeMenu (MenuRoot * mr)
{
  MenuItem *cur;
  unsigned long valuemask;
  XSetWindowAttributes attributes;
  int width, y, t;
  XSizeHints hints;
  Bool was_pinned = False;

  /* lets first size the window accordingly */
  mr->width = 0;
  for (cur = mr->first; cur != NULL; cur = cur->next)
    {
      /* calculate item width */
      if (cur->func == F_TITLE)
	{
	  int d = 0;
	  width = (cur->item == NULL) ? 0 : XTextWidth ((*Scr.MSMenuTitle).font.font, cur->item, cur->strlen);

#ifndef NO_TEXTURE
	  if (Scr.MenuPinOn.pix != None)
	    if (d < 5 + Scr.MenuPinOn.width + 1)
	      d = 5 + Scr.MenuPinOn.width + 1;
	  if (Scr.MenuPinOff.pix != None)
	    if (d < 5 + Scr.MenuPinOff.width + 1)
	      d = 5 + Scr.MenuPinOff.width + 1;
#endif /* !NO_TEXTURE */
	  width += d;
	}
      else
	{
	  width = (cur->item == NULL) ? 0 : XTextWidth ((*Scr.MSMenuItem).font.font, cur->item, cur->strlen);
	  t = (cur->item == NULL) ? 0 : XTextWidth ((*Scr.MSMenuHilite).font.font, cur->item, cur->strlen);

	  if (width < t)
	    width = t;
	}

      if ((*cur).icon.pix != None)
	width += (*cur).icon.width + 5;
      if (cur->func == F_POPUP || cur->hotkey)
	width += 15;
      if (width <= 0)
	width = 1;
      if (width > mr->width)
	mr->width = width;

      t = XTextWidth ((*Scr.MSMenuHilite).font.font, cur->item2, cur->strlen2);
      width = XTextWidth ((*Scr.MSMenuItem).font.font,
			  cur->item2, cur->strlen2);


      if (width < t)
	width = t;
      if (width < 0)
	width = 0;
      if (width > mr->width2)
	mr->width2 = width;
      if ((width == 0) && (cur->strlen2 > 0))
	mr->width2 = 1;

      /* calculate item height */
      if (cur->func == F_TITLE)
	{
	  /* Title */
	  cur->y_height = (*Scr.MSMenuTitle).font.height + HEIGHT_EXTRA + 2;
#ifndef NO_TEXTURE
	  if (Scr.MenuPinOn.pix != None)
	    if ((*cur).y_height < Scr.MenuPinOn.height + 3)
	      (*cur).y_height = Scr.MenuPinOn.height + 3;
	  if (Scr.MenuPinOff.pix != None)
	    if ((*cur).y_height < Scr.MenuPinOff.height + 3)
	      (*cur).y_height = Scr.MenuPinOff.height + 3;
#endif /* !NO_TEXTURE */
	}
      else if (cur->func == F_NOP && cur->item != NULL && *cur->item == 0)
	{
	  /* Separator */
	  cur->y_height = HEIGHT_SEPARATOR;
	}
      else
	{
	  /* Normal text entry */
	  cur->y_height = (*Scr.MSMenuItem).font.height + HEIGHT_EXTRA + 2;
	  t = (*Scr.MSMenuHilite).font.height + HEIGHT_EXTRA + 2;
	  if (cur->y_height < t)
	    cur->y_height = t;
	}
      if ((*cur).icon.pix != None)
	if ((*cur).y_height < (*cur).icon.height + 3)
	  (*cur).y_height = (*cur).icon.height + 3;
    }
  mr->width += 15;
  if (mr->width2 > 0)
    mr->width += 5;

  /* now place the items */
  for (y = 0, cur = mr->first; cur != NULL; cur = cur->next)
    {
      cur->y_offset = y;
      cur->x = 5;
      if ((*cur).icon.pix != None)
	cur->x += (*cur).icon.width + 5;
      if (mr->width2 == 0)
	{
	  cur->x2 = cur->x;
	}
      else
	{
	  cur->x2 = mr->width - 5;
	}
      y += cur->y_height;
    }
  if ((*mr).is_mapped == True && (*mr).is_pinned == True)
    was_pinned = True;
  if ((*mr).is_mapped == True)
    unmap_menu (mr);
  mr->height = y;

  /* free resources */
#ifndef NO_TEXTURE
  if ((*mr).titlebg != None)
    XFreePixmap (dpy, (*mr).titlebg);
  if ((*mr).itembg != None)
    XFreePixmap (dpy, (*mr).itembg);
  if ((*mr).itemhibg != None)
    XFreePixmap (dpy, (*mr).itemhibg);
  (*mr).titlebg = None;
  (*mr).itembg = None;
  (*mr).itemhibg = None;
#endif
  if ((*mr).w != None)
    {
      XDestroyWindow (dpy, (*mr).w);
      XDeleteContext (dpy, (*mr).w, MenuContext);
    }
#ifndef NO_SAVEUNDERS
  valuemask = (CWBackPixel | CWEventMask | CWCursor | CWSaveUnder);
#else
  valuemask = (CWBackPixel | CWEventMask | CWCursor);
#endif
  attributes.event_mask = (ExposureMask | EnterWindowMask);
  attributes.cursor = Scr.ASCursors[MENU];
#ifndef NO_SAVEUNDERS
  attributes.save_under = TRUE;
#endif
  mr->width = mr->width + mr->width2;

  mr->w = XCreateWindow (dpy, Scr.Root, 0, 0, (unsigned int) (mr->width),
			 (unsigned int) mr->height, (unsigned int) 0,
			 CopyFromParent, (unsigned int) InputOutput,
			 (Visual *) CopyFromParent,
			 valuemask, &attributes);
  /* allow us to set a menu's position before calling AddWindow */
  hints.flags = USPosition;
  XSetNormalHints (dpy, mr->w, &hints);
  XSaveContext (dpy, mr->w, MenuContext, (caddr_t) mr);

  /* if this menu is supposed to be mapped, map it */
  if (was_pinned == True)
    {
      setup_menu_pixmaps (mr);
      map_menu (mr, (*mr).context);
      pin_menu (mr);
    }

  return;
}

/***********************************************************************
 * Procedure:
 *	scanForHotkeys - Look for hotkey markers in a MenuItem
 * 							(pete@tecc.co.uk)
 * 
 * Inputs:
 *	it	- MenuItem to scan
 * 	which 	- +1 to look in it->item1 and -1 to look in it->item2.
 *
 ***********************************************************************/

void
scanForHotkeys (MenuItem * it, int which)
{
  char *start, *txt;

  start = (which > 0) ? it->item : it->item2;	/* Get start of string  */

  if (start == NULL)
    return;

  for (txt = start; *txt != '\0'; txt++)
    {				/* Scan whole string    */
      if (*txt == '&')
	{			/* A hotkey marker?                     */
	  if (txt[1] == '&')
	    {			/* Just an escaped &                    */
	      char *tmp;	/* Copy the string down over it         */
	      for (tmp = txt; *tmp != '\0'; tmp++)
		tmp[0] = tmp[1];
	      continue;		/* ...And skip to the key char          */
	    }
	  /* It's a hot key marker - work out the offset value        */
	  it->hotkey = txt[1];
	  for (; txt[1] != '\0'; txt++)
	    txt[0] = txt[2];	/* Copy down..  */
	  return;		/* Only one hotkey per item...          */
	}
    }
}



/***********************************************************************
 *
 *  Procedure:
 *	AddToMenu - add an item to a root menu
 *
 *  Returned Value:
 *	(MenuItem *)
 *
 *  Inputs:
 *	menu	- pointer to the root menu to add the item
 *	item	- the text to appear in the menu
 *	action	- the string to possibly execute
 *	func	- the numeric function
 *
 ***********************************************************************/

void
AddToMenu (MenuRoot * menu, char *item, char *item2, char *action, int func,
	   long func_val_1, long func_val_2, char unit_1, char unit_2)
{
  MenuItem *tmp;

  if (item == NULL)    return;
  
  tmp = (MenuItem *) safemalloc (sizeof (MenuItem));
  if (menu->first == NULL)
    {
      menu->first = tmp;
      tmp->prev = NULL;
    }
  else
    {
      menu->last->next = tmp;
      tmp->prev = menu->last;
    }
  tmp->next = NULL;
  menu->last = tmp;

  tmp->item = mystrdup(item);
  scanForHotkeys (tmp, 1);	/* pete@tecc.co.uk */
  tmp->strlen = strlen (tmp->item);

  if (item2 != NULL)
  {
      tmp->item2 = mystrdup(item2);
      if (tmp->hotkey == 0)
	scanForHotkeys (tmp, -1);	/* pete@tecc.co.uk */
      tmp->strlen2 = strlen (item2);
    }
  else
  {
    tmp->strlen2 = 0;
    tmp->item2 = NULL;
  }
  tmp->menu = NULL;

  if ((func == F_POPUP) || (func == F_FUNCTION))
      if ((tmp->menu=FindPopup(action)) == NULL)  func = F_NOP;

  tmp->action = mystrdup(action);

  tmp->is_hilited = False;
  tmp->icon.pix = None;
  tmp->icon.mask = None;
  tmp->icon.width = 0;
  tmp->icon.height = 0;
  tmp->func = func;
  tmp->val1 = func_val_1;
  tmp->val2 = func_val_2;
  if ((unit_1 == 'p') || (unit_1 == 'P'))
    tmp->val1_unit = 100;
  else
    tmp->val1_unit = Scr.MyDisplayWidth;
  if ((unit_2 == 'p') || (unit_2 == 'P'))
    tmp->val2_unit = 100;
  else
    tmp->val2_unit = Scr.MyDisplayHeight;

  tmp->item_num = menu->items++;
}

/***********************************************************************
 *
 *  Procedure:
 *	NewMenuRoot - create a new menu root
 *
 *  Returned Value:
 *	(MenuRoot *)
 *
 *  Inputs:
 *	name	- the name of the menu root
 *
 ***********************************************************************/


MenuRoot *
NewMenuRoot (char *name)
{
  MenuRoot *tmp;

  tmp = (MenuRoot *) safemalloc (sizeof (MenuRoot));
  tmp->next = Scr.first_menu;
  Scr.first_menu = tmp;

  /* 
   * need to allocate our own mem here, at least for do_windowList;
   * same for AddToMenu above;
   * really should go through and make sure we're not leaking mem 
   * like a sieve ;)
   */
  tmp->name = (name == NULL) ? NULL : mystrdup (name);
  tmp->first = NULL;
  tmp->last = NULL;
  tmp->items = 0;
  tmp->width = 0;
  tmp->width2 = 0;
  tmp->is_mapped = False;
  tmp->is_transient = False;
  tmp->is_pinned = False;
#ifndef NO_TEXTURE
  tmp->titlebg = None;
  tmp->itembg = None;
  tmp->itemhibg = None;
#endif
  tmp->w = None;
  tmp->aw = NULL;
  return (tmp);
}

void
DeleteMenuRoot (MenuRoot * menu)
{
  /* unmap if necessary */
  if (menu->is_mapped == True)
    unmap_menu (menu);

  /* remove ourself from the root menu list */
  if (Scr.first_menu == menu)
    Scr.first_menu = menu->next;
  else if (Scr.first_menu != NULL)
    {
      MenuRoot *ptr;
      for (ptr = Scr.first_menu; ptr->next != NULL; ptr = ptr->next)
	if (ptr->next == menu)
	  break;
      if (ptr->next == menu)
	ptr->next = menu->next;
    }

  /* kill our children */
  while (menu->first != NULL)
    {
      MenuItem *item = menu->first;
      menu->first = item->next;
      if (item->item != NULL)
	free (item->item);
      if (item->item2 != NULL)
	free (item->item2);
      if (item->action != NULL)
	free (item->action);
      if (item->icon.pix != None)
	UnloadImage (item->icon.pix);
      free (item);
    }

#ifndef NO_TEXTURE
  /*  free background pixmaps */
  if (menu->titlebg != None)
    XFreePixmap (dpy, menu->titlebg);
  if (menu->itembg != None)
    XFreePixmap (dpy, menu->itembg);
  if (menu->itemhibg != None)
    XFreePixmap (dpy, menu->itemhibg);
#endif
  if (menu->w != None)
    {
      XDestroyWindow (dpy, menu->w);
      XDeleteContext (dpy, menu->w, MenuContext);
    }

  /* become nameless */
  if (menu->name != NULL)
    free (menu->name);

  /* free our own mem */
  free (menu);
}

/***********************************************************************
 *
 *  Procedure:
 *	AddFuncKey - add a function key to the list
 *
 *  Inputs:
 *	name	- the name of the key
 *	cont	- the context to look for the key press in
 *	mods	- modifier keys that need to be pressed
 *	func	- the function to perform
 *	action	- the action string associated with the function (if any)
 *
 ***********************************************************************/

void
AddFuncKey (char *name, int cont, int mods, int func, char *action,
	    int val1, int val2, MenuRoot * mr, char unit_1, char unit_2)
{
  FuncKey *tmp;
  KeySym keysym;
  KeyCode keycode;
  int i, min, max;

  /*
   * Don't let a 0 keycode go through, since that means AnyKey to the
   * XGrabKey call in GrabKeys().
   */
  if ((keysym = XStringToKeysym (name)) == NoSymbol ||
      (keycode = XKeysymToKeycode (dpy, keysym)) == 0)
    return;


  XDisplayKeycodes (dpy, &min, &max);
  for (i = min; i <= max; i++)
    if (XKeycodeToKeysym (dpy, i, 0) == keysym)
      {
	tmp = (FuncKey *) safemalloc (sizeof (FuncKey));
	tmp->next = Scr.FuncKeyRoot.next;
	Scr.FuncKeyRoot.next = tmp;

	tmp->name = (name != NULL) ? mystrdup (name) : NULL;
	tmp->keycode = i;
	tmp->cont = cont;
	tmp->mods = mods;
	tmp->func = func;
	tmp->action = (action != NULL) ? mystrdup (action) : NULL;
	tmp->val1 = val1;
	tmp->val2 = val2;
	if ((unit_1 == 'p') || (unit_1 == 'P'))
	  tmp->val1_unit = 100;
	else
	  tmp->val1_unit = Scr.MyDisplayWidth;
	if ((unit_2 == 'p') || (unit_2 == 'P'))
	  tmp->val2_unit = 100;
	else
	  tmp->val2_unit = Scr.MyDisplayHeight;

	tmp->menu = mr;
      }
  return;
}

/****************************************************************************
 * 
 * Copies a string into a new, malloc'ed string
 * Strips all data before the second quote. and strips trailing spaces and
 * new lines
 *
 ****************************************************************************/

char *
stripcpy3 (const char *source, const Bool Warn)
{
  while ((*source != '"') && (*source != 0))
    source++;
  if (*source != 0)
    source++;
  while ((*source != '"') && (*source != 0))
    source++;
  if (*source == 0)
    {
      if (Warn)
	bad_binding (3);
      return 0;
    }
  source++;
  return stripcpy (source);
}

void
bad_binding (int num)
{
  afterstep_err ("bad binding in line %s", orig_tline, NULL, NULL);
  return;
}

/***********************************************************************
 *
 *  Procedure:
 *	CreateGCs - open fonts and create all the needed GC's.  I only
 *		    want to do this once, hence the first_time flag.
 *
 ***********************************************************************/

void
CreateGCs (void)
{
  XGCValues gcv;
  unsigned long gcm;

  gcm = GCForeground | GCBackground | GCGraphicsExposures;

  gcv.foreground = (*Scr.MSFWindow).colors.fore;
  gcv.background = (*Scr.MSFWindow).colors.back;
  gcv.graphics_exposures = False;

  gcm = GCLineWidth | GCForeground | GCBackground | GCFunction;
  gcv.function = GXcopy;
  gcv.line_width = 1;

  gcv.foreground = (*Scr.MSFWindow).colors.fore;
  gcv.background = (*Scr.MSFWindow).colors.back;

  Scr.LineGC = XCreateGC (dpy, Scr.Root, gcm, &gcv);

  gcm = GCFunction | GCLineWidth | GCForeground | GCSubwindowMode;
  gcv.function = GXxor;
  gcv.line_width = 0;
  gcv.foreground = XORvalue;
  gcv.subwindow_mode = IncludeInferiors;
  Scr.DrawGC = XCreateGC (dpy, Scr.Root, gcm, &gcv);

  gcm = GCFunction | GCPlaneMask | GCGraphicsExposures | GCLineWidth |
    GCForeground | GCBackground | GCFont;
  gcv.line_width = 0;
  gcv.function = GXcopy;
  gcv.plane_mask = AllPlanes;

  gcv.foreground = (*Scr.MSFWindow).colors.fore;
  gcv.background = (*Scr.MSFWindow).colors.back;
  gcv.font = (*Scr.MSFWindow).font.font->fid;
  /*
   * Prevent GraphicsExpose and NoExpose events.  We'd only get NoExpose
   * events anyway;  they cause BadWindow errors from XGetWindowAttributes
   * call in FindScreenInfo (events.c) (since drawable is a pixmap).
   */
  gcv.graphics_exposures = False;

  Scr.NormalGC = XCreateGC (dpy, Scr.Root, gcm, &gcv);

  gcv.fill_style = FillStippled;
  gcv.stipple = Scr.gray_bitmap;
  gcm = GCFunction | GCPlaneMask | GCGraphicsExposures | GCLineWidth | GCForeground |
    GCBackground | GCFont | GCStipple | GCFillStyle;

  Scr.StippleGC = XCreateGC (dpy, Scr.Root, gcm, &gcv);

  gcm = GCFunction | GCPlaneMask | GCGraphicsExposures | GCLineWidth | GCForeground |
    GCBackground | GCFont;
  Globalgcm = gcm;
  Globalgcv = gcv;
  gcv.foreground = (*Scr.MSFWindow).relief.fore;
  gcv.background = (*Scr.MSFWindow).relief.back;
  Scr.ScratchGC1 = XCreateGC (dpy, Scr.Root, gcm, &gcv);

  gcv.foreground = (*Scr.MSFWindow).relief.back;
  gcv.background = (*Scr.MSFWindow).relief.fore;
  Scr.ScratchGC2 = XCreateGC (dpy, Scr.Root, gcm, &gcv);
}
