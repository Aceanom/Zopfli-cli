#include <string.h>
#include "../configure.h"
#include "../include/aftersteplib.h"

char *
mystrdup (const char *str)
{
  char *c = NULL ;
  if(str)
  {
      c = safemalloc (strlen (str) + 1);
      strcpy (c, str);
  }
  return c;
}

char *
mystrndup (const char *str, size_t n)
{
  char *c = NULL ;
  if(str)
  {
      c = safemalloc (n + 1);
      strncpy (c, str, n);
      c[n] = '\0';
  }
  return c;
}
