# Remote Service Admin EventAdmin Publisher

Is used to publish EventAdmin events for Remote Service Admin events notifications.
