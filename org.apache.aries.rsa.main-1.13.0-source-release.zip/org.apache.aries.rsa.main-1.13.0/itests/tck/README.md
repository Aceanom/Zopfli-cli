# TCK Tests

## Install tests from tck

Call install-tests.sh with the path to the directory where the test jars reside.

	sh install/install-tests.sh ~/checkout/osgi_ct_enterprise/jar
	
This installs the tests to your local maven repo and only needs to be done once.

## Build the index

	mvn package


## Run the tests

TODO

