#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "../include/aftersteplib.h"

int 
mystrcasecmp (char *s1, char *s2)
{
  int c1, c2;
  int n1, n2;

  n1 = strlen (s1);
  n2 = strlen (s2);
  if (n1 != n2)
    return 1;

  for (;;)
    {
      c1 = *s1++;
      c2 = *s2++;
      if (!c1 || !c2)
	return (c1 - c2);
      if (isupper (c1))
	c1 += 32;
      if (isupper (c2))
	c2 += 32;
      if (c1 != c2)
	return (c1 - c2);
    }
}
