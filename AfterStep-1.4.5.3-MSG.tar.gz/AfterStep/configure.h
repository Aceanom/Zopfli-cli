/* Please don't change version number !! */

#define VERSION "1.4.5.3"

/* To override imake default compiler, undef OVERRIDE_COMPILER in Imakefiles */

#define OVERRIDE_COMPILER CC=cc

/* Where AfterStep will install its binaries */

#define AFTER_BIN_DIR	BINDIR=/usr/X11R6/bin
#define AFTER_MOD_DIR	"/usr/X11R6/bin/"
#define AFTER_MAN_DIR	MANDIR=/usr/X11R6/man/man1

/* Where AfterStep will find its binaries, pixmaps & defaults */

#define AFTER_BPMDIR	"/usr/X11R6/include/X11/bitmaps"
#define AFTER_XPMDIR	"/usr/X11R6/include/X11/pixmaps"
#define AFTER_SHAREDIR	"/usr/share/afterstep"

/* Home directories NEEDED */

#define GNUSTEP		"~/GNUstep"
#define GNUSTEPLIB	"~/GNUstep/Library"
#define AFTER_DIR	"~/GNUstep/Library/AfterStep"
#define AFTER_SAVE 	"~/GNUstep/Library/AfterStep/.workspace_state"
#define AFTER_NONCF	"~/GNUstep/Library/AfterStep/non-configurable"
#define AFTER_NONCFDESK	"~/GNUstep/Library/AfterStep/non-configurable/desk%d"

/* Temporary dir & file : each user must have a different tmp dir */

#define AFTER_TMPDIR	"~/GNUstep/Library/AfterStep/non-configurable/tmp"
#define TMP_STARTMENU	"startmenu"

/* in home or share directories : */

#define START_DIR	"start"
#define BACK_DIR	"desktop/backgrounds"
#define LOOK_DIR	"looks"
#define FEEL_DIR	"feels"
#define COMPATIBILITY_FILE "compatibility"		     /* with -f oldrc */
#define BASE_FILE	"base"                               /* scrdepth */
#define BACK_FILE	"non-configurable/desk%d/background" /* desk */
#define LOOK_FILE	"non-configurable/desk%d/look.%dbpp" /* desk,scrdepth */
#define FEEL_FILE	"non-configurable/desk%d/feel.%dbpp" /* desk,scrdepth */
#define AUTOEXEC_FILE	"autoexec"
#define DATABASE_FILE	"database"

/***************************************************************************
 * #define XIMAGELOADER
 *
 * External used by afterstep to process non XPM files
 * Xli is faster & freeware, but some people will prefer xv.
 * If you have xli, use "xli -onroot -quiet -colors 20"
 ***************************************************************************/

/* #define XIMAGELOADER  "xli -onroot -quiet -colors 20" */
#define XIMAGELOADER  "xv -root -quit"       /* you can add "-rmode 5" */

/***************************************************************************
 * #define ANIM*
 *
 * Wharf animation speed options : greater is smoother and slower, must be >=1
 * You may want to raise the following values if your machine is fast or lower
 * if it is slow
 ***************************************************************************/

#define ANIM_STEP       10 
#define ANIM_STEP_MAIN  10
#define ANIM_DELAY      10
 

/***************************************************************************
 * #define MAXLINELENGTH
 *
 * Maximal lenght of config. file lines ; attention : the more you define
 * the more memory it uses.  It's safe to leave 255 for long lines.
 ***************************************************************************/

#define MAXLINELENGTH 255

/***************************************************************************
 * #define HELPCOMMAND
 *
 * How will you get your help when right-clicking on extreme left button ?
 * If you don't like this default, you can use xless, xman ...
 ***************************************************************************/

#define HELPCOMMAND     "xiterm -e man"

/***************************************************************************
 * #define NO_ICON_BACKGROUND
 *
 * Don't want background behind iconifyied windows & allow icon > than 64x64 ?
 * Very nice looking, but not very nexitish ! NOT FINISHED YET !!!!!
 ****************************************************************************/

/* #define NO_ICON_BACKGROUND */

/***************************************************************************
 * #define DEFAULTSTARTMENUSORT
 *
 * The way options in start menu are auto sorted ; only SORTBYALPHA or
 * SORTBYDATE are available for now
 ****************************************************************************/

#define DEFAULTSTARTMENUSORT SORTBYALPHA

/***************************************************************************
 * #define DIFFERENTLOOKNFEELFOREACHDESKTOP
 *
 * Restart automagically with a different look & feel each time you change
 * desktop (i.e. with Pager, not by circulating windows !)
 * Not recommended on slow or multiusers machines !
 ***************************************************************************/

/*#define DIFFERENTLOOKNFEELFOREACHDESKTOP*/

/***************************************************************************
 * #define NO_WARP_POINTER_TO_MENU
 *
 * If you don't want your mouse pointer to be automatically put in the center
 * of a menu title when you open it
 ***************************************************************************/

#define NO_WARP_POINTER_TO_MENU

/***************************************************************************
 * #define NO_SAVEWINDOWS
 *
 * If you don't want windows still opened when you close your session to be
 * reopened next time you start, define this.
 */

/*#define NO_SAVEWINDOWS*/

/***************************************************************************
 * #define NO_MAKESTARTMENU
 *
 * If you don't want start menu to be rebuilt every time you start afterstep
 * but rather edit it by hand. Not recommended at all !
 ***************************************************************************/

/*#define NO_MAKESTARTMENU*/

/***************************************************************************
 * #define NO_TEXTURE
 *
 * If you don't like gradients, uncomment this
 * For icons gradients, define NO_ICON_BACKGROUND too !!!
 ***************************************************************************/

/*#define NO_TEXTURE*/

/***************************************************************************
 * #define NO_SHADE
 *
 * If you do not want shade to be animated, uncomment this
 ***************************************************************************/

/*#define NO_SHADE*/

/***************************************************************************
 * #define NO_VIRTUAL
 *
 * Omits the virtual desktop but Pager module won't work !
 ***************************************************************************/

/*#define NO_VIRTUAL*/

/***************************************************************************
 * #define NO_SAVEUNDERS 
 *
 * Tells the WM not to request save unders for pop-up menus.
 * A quick test using monochrome X11 shows that save unders cost about 4Kbytes
 * RAM, but saves a lot of window redraws if you have windows that take a while
 * to refresh. For xcolor, I assume the cost is more like :
 *  4Kbytesx8 = 32kbytes (256 color).
 ***************************************************************************/

/*#define NO_SAVEUNDERS*/

/***************************************************************************
 * #define NO_WINDOWLIST 
 *
 *   Causes built-in window-list (started on right clicking root window) to be
 *   omitted.
 *   The window-list module WinList can be used instead but it's slower !
 ***************************************************************************/

/*#define NO_WINDOWLIST*/

/***************************************************************************
 * #define XPM
 *
 * If you want color icons, specify #define XPM, and get libXpm
 * For monochrome, Xpm icons still work, but they're only better than regular
 * bitmaps because they're shaped (if you specify #define SHAPE).
 ***************************************************************************/

#define XPM
#define XPMLIBRARY -L/usr/X11R6/lib -lXpm

/***************************************************************************
 * #define NO_SHAPE
 *
 * If you don't want the Shaped window extensions, #define NO_SHAPE
 *  Shaped window extensions seem to increase the window managers RSS
 *  by about 60 Kbytes. They provide for leaving a title-bar on the window
 *  without a border.
 *  If you dont use shaped window extension, you can either make your shaped
 *  windows undecorated, or live with a border and backdrop around all
 *  your shaped windows (oclock, xeyes)
 *  If you normally use a shaped window (xeyes or oclock), you might as
 *  well compile this extension in, since the memory cost is  minimal in
 *  this case (The shaped window shared libs will be loaded anyway. If you
 *  don't normally use a shaped window, you have to decide for yourself
 ***************************************************************************/

/*#define NO_SHAPE*/

/***************************************************************************
 * Please don't translate the strings into the language which you use for your
 * pop-up menus since this is default : some decisions about where a function
 * is prohibited (based on mwm-function-hints) is based on a string comparison
 * between the menu item and the strings below
 ***************************************************************************/

#define MOVE_STRING      "move"
#define RESIZE_STRING1   "size"
#define RESIZE_STRING2   "resize"
#define MINIMIZE_STRING  "minimize"
#define MINIMIZE_STRING2 "iconify"
#define MAXIMIZE_STRING  "maximize"
#define CLOSE_STRING1    "close"
#define CLOSE_STRING2    "delete"
#define CLOSE_STRING3    "destroy"
#define CLOSE_STRING4    "quit"

/*##########################################################################*/
/*************************** OS DEPENDANT DEFINES ***************************/
/*##########################################################################*/

#include "os-dependant.h"

/* Really, no one but me should need this */
/* #define BROKEN_SUN_HEADERS */

/* Some logical checks */
#ifdef HAVE_UNAME
#undef HAVE_GETHOSTNAME
#endif

/* Allows gcc users to use inline, doesn't cause problems for others. */
#ifndef __GNUC__
#define  AFTER_INLINE  /* nothing */
#else
#if defined(__GNUC__) && !defined(inline)
#define AFTER_INLINE __inline__
#else
#define AFTER_INLINE inline
#endif /* __GNUC__ && !(inline) */
#endif /* !(__GNUC__) */
