// wmcdplay - a cdplayer designed for WindowMaker
// 07/05/98  Release 0.8
// Copyright (C) 1998  Sam Hawker <shawkie@geocities.com>
// This software comes with ABSOLUTELY NO WARRANTY
// This software is free software, and you are welcome to redistribute it
// under certain conditions
// See the README file for a more complete notice.

#define WINDOWMAKER FALSE
#define USESHAPE FALSE
#define NAME "wmcdplay"
#define CLASS "WMCDPlay"

#define DEFAULTDEVICE "/dev/cdrom"
#define LEDCOLOR "green"
#define BACKCOLOR "#282828"
#define POSRELABS 0    // 0=relative position, 1=absolute position (click the time display to alter at runtime)
#define UINTERVAL 5    // update interval in 20ths of a second     (MUST BE AT LEAST 1 !!)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include "cdctl.h"

// Not part of Artwork
Pixmap tile;

// Artwork pixmaps
Pixmap cdXPM;
Pixmap cdMask;
Pixmap symXPM;
Pixmap symMask;
Pixmap ledXPM;
Pixmap sledXPM;
Pixmap tledXPM;

// Runtime pixmaps
Pixmap disp;
Pixmap dmsk;

// Not part of Artwork
#include "XPM/tile.xpm"

// Artwork pixmaps
#include "XPM/standard.art"

// For command line arguments
bool wmaker = WINDOWMAKER;
bool ushape = USESHAPE;
bool artwrk = FALSE;
char txtdpy[256] = "";
char txtdev[256] = DEFAULTDEVICE;
char ledcol[256] = LEDCOLOR;
char bckcol[256] = BACKCOLOR;
char artwrkf[256] = "";
int tsel=1;
int vol=-1;     // -1 means don't set volume

Atom _XA_GNUSTEP_WM_FUNC;
Atom deleteWin;

Display *dpy;
Window Win[2];
Window Root;
XWMHints *hints;
GC WinGC, mGC;
int activeWin;
int mode=-1,track=-1,pos=-1;
int ucount=0;
int tdisplay=POSRELABS;
char chrset[]="00112233445566778899  ddAAttnnoocc--PPEE:;";
int **style_btnlist;
int *style_factions=style_actions;
int *style_fbtns=style_btns;
int style_symbolsize[2];
int style_ledsize[6];

CDCtl *cdctl;
char text_track[8]="";
char text_timer[8]="";

// Standard dock-app stuff
void initXWin(int argc, char *argv[]);
void freeXWin();
void createWin(Window *win);
unsigned long getColor(char *colorName, float dim);

// Custom dock-app stuff
void scanArgs(int argc, char *argv[]);
void checkStatus(bool forced);
void pressEvent(XButtonEvent *xev);
void repaint();
void update();
void drawText(int x, int y, char *text);

// Basic artwork stuff
void readArtwork(char *artfilen);
char *readBlock(FILE *dfile);
int arrayItems(char *buf);
void readArrayInt(char *buf, int *array, int n);
void readArrayBool(char *buf, bool *array, int n);

// Really smart artwork stuff
void createPixmap(char *data[], char *buf, Pixmap *image, Pixmap *mask, int *width, int *height);
void setBtnList(int *bset);
bool inPolygon(int *points, int px, int py);

int main(int argc, char *argv[])
{
   scanArgs(argc, argv);
   initXWin(argc, argv);

   if(artwrk){
      // Read pixmaps from artwork file
      readArtwork(artwrkf);
   }
   else{
      // Use compiled-in pixmaps
      int w,h;
      createPixmap(cdplayer_xpm, NULL, &cdXPM, &cdMask, NULL, NULL);
      createPixmap(symbols_xpm, NULL, &symXPM, &symMask, &w, &h);
      style_symbolsize[0]=(w+1)/11-1;
      style_symbolsize[1]=h;
      createPixmap(led_xpm, NULL, &ledXPM, NULL, &w, &h);
      style_ledsize[0]=(w+1)/strlen(chrset)-1;
      style_ledsize[1]=h;
      createPixmap(ledsym_xpm, NULL, &sledXPM, NULL, &w, &h);
      style_ledsize[2]=(w+1)/6-1;
      style_ledsize[3]=h;
      createPixmap(ledtsel_xpm, NULL, &tledXPM, NULL, &w, &h);
      style_ledsize[4]=(w+1)/5-1;
      style_ledsize[5]=h;
   }
   setBtnList(style_fbtns);
   createPixmap(tile_xpm, NULL, &tile, NULL, NULL, NULL);
   disp = XCreatePixmap(dpy, Root, 64, 64, DefaultDepth(dpy,DefaultScreen(dpy)));
   dmsk = XCreatePixmap(dpy, Root, 64, 64, 1);

   XGCValues gcv;
   unsigned long gcm;
   gcm = GCForeground|GCBackground|GCGraphicsExposures;
   gcv.graphics_exposures = False;
   WinGC = XCreateGC(dpy, Root, gcm, &gcv);
   mGC = XCreateGC(dpy, dmsk, gcm, &gcv);

   cdctl = new CDCtl(txtdev);
   if(vol!=-1)
      cdctl->setVolume(vol,vol);
   int tsels[] = { tsNone, tsNext, tsRepeat, tsRepeatCD, tsRandom };
   cdctl->setTrackSelection(tsels[tsel]);

   checkStatus(TRUE);

   XEvent event;
   XSelectInput(dpy, Win[activeWin], ButtonPress | ExposureMask);
   XMapWindow(dpy, Win[0]);

   bool finished=FALSE;
   while(!finished){
      while(XPending(dpy)){
         XNextEvent(dpy,&event);
         switch(event.type){
          case Expose:
             repaint();
          break;
	  case ButtonPress:
             pressEvent(&event.xbutton);
          break;
          case ClientMessage:
             if(event.xclient.data.l[0]==deleteWin)
                finished=TRUE;
          break;
         }
      }
      if((ucount++)==(UINTERVAL-1))
         checkStatus(FALSE);
      XFlush(dpy);
      usleep(5000);
   }
   XFreeGC(dpy, WinGC);
   XFreeGC(dpy, mGC);
   // Free pixmaps not in Artwork
   XFreePixmap(dpy, tile);
   // Free runtime pixmaps
   XFreePixmap(dpy, disp);
   XFreePixmap(dpy, dmsk);
   // Free Artwork pixmaps
   XFreePixmap(dpy, cdXPM);
   XFreePixmap(dpy, cdMask);
   XFreePixmap(dpy, symXPM);
   XFreePixmap(dpy, symMask);
   XFreePixmap(dpy, ledXPM);
   XFreePixmap(dpy, sledXPM);
   XFreePixmap(dpy, tledXPM);
   // Finish with X stuff
   freeXWin();
   // Free Artwork data
   if(artwrk){
      free(style_factions);
      free(style_fbtns);
   }
   free(style_btnlist);
   delete cdctl;
   return 0;
}

void initXWin(int argc, char *argv[]){
   if((dpy=XOpenDisplay(txtdpy))==NULL){
      fprintf(stderr,"You're probably trying to run an X app from the console, you idiot! RTFM\n");
      exit(1);
   }
   _XA_GNUSTEP_WM_FUNC = XInternAtom(dpy, "_GNUSTEP_WM_FUNCTION", False);
   deleteWin = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
   Root=DefaultRootWindow(dpy);
   createWin(&Win[0]);
   createWin(&Win[1]);
   XWMHints hints;
   XSizeHints shints;
   hints.window_group = Win[0];
   shints.min_width=64;
   shints.min_height=64;
   shints.max_width=64;
   shints.max_height=64;
   shints.x=0;
   shints.y=0;
   if(wmaker){
      hints.initial_state = WithdrawnState;
      hints.icon_window = Win[1];
      hints.flags = WindowGroupHint | StateHint | IconWindowHint;
      shints.flags = PMinSize | PMaxSize | PPosition;
      activeWin=1;
   }
   else{
      hints.initial_state = NormalState;
      hints.flags = WindowGroupHint | StateHint;
      shints.flags = PMinSize | PMaxSize;
      activeWin=0;
   }
   XSetWMHints(dpy, Win[0], &hints);
   XSetWMNormalHints(dpy, Win[0], &shints);
   XSetCommand(dpy, Win[0], argv, argc);
   XStoreName(dpy, Win[0], NAME);
   XSetIconName(dpy, Win[0], NAME);
   XSetWMProtocols(dpy, Win[activeWin], &deleteWin, 1);
}

void freeXWin(){
   XDestroyWindow(dpy, Win[0]);
   XDestroyWindow(dpy, Win[1]);
   XCloseDisplay(dpy);
}

void createWin(Window *win){
   XClassHint classHint;
   *win = XCreateSimpleWindow(dpy, Root, 10, 10, 64, 64,0,0,0);
   classHint.res_name = NAME;
   classHint.res_class = CLASS;
   XSetClassHint(dpy, *win, &classHint);
}

unsigned long getColor(char *colorName, float dim)
{
   XColor Color;
   XWindowAttributes Attributes;

   XGetWindowAttributes(dpy, Root, &Attributes);
   Color.pixel = 0;

   XParseColor (dpy, Attributes.colormap, colorName, &Color);
   Color.red=(unsigned short)(Color.red/dim);
   Color.blue=(unsigned short)(Color.blue/dim);
   Color.green=(unsigned short)(Color.green/dim);
   Color.flags=DoRed | DoGreen | DoBlue;
   XAllocColor (dpy, Attributes.colormap, &Color);

   return Color.pixel;
}

void scanArgs(int argc, char *argv[]){
   for(int i=1;i<argc;i++){
      if(strcmp(argv[i],"-h")==0 || strcmp(argv[i],"-help")==0 || strcmp(argv[i],"--help")==0){
         fprintf(stderr,"wmcdplay - a cdplayer designed for WindowMaker\n07/05/98  Release 0.8\n");
         fprintf(stderr,"Copyright (C) 1998  Sam Hawker <shawkie@geocities.com>\n");
         fprintf(stderr,"This software comes with ABSOLUTELY NO WARRANTY\n");
         fprintf(stderr,"This software is free software, and you are welcome to redistribute it\n");
         fprintf(stderr,"under certain conditions\n");
         fprintf(stderr,"See the README file for a more complete notice.\n\n");
         fprintf(stderr,"usage:\n\n   %s [options]\n\noptions:\n\n",argv[0]);
         fprintf(stderr,"   -h | -help | --help    display this help screen\n");
         fprintf(stderr,"   -w                     use WithdrawnState    (for WindowMaker)\n");
         fprintf(stderr,"   -s                     shaped window\n");
         fprintf(stderr,"   -a artwork_file        load the specified artwork file\n");
         fprintf(stderr,"   -t track_selection     set track selection   (between 0 and 4)\n");
         fprintf(stderr,"   -v volume              set the cdrom volume  (between 0 and 255)\n");
         fprintf(stderr,"   -l led_color           use the specified color for led displays\n");
         fprintf(stderr,"   -b back_color          use the specified color for backgrounds\n");
         fprintf(stderr,"   -d cd_device           use specified device  (rather than /dev/cdrom)\n");
         fprintf(stderr,"   -display display       select target display (see X manual pages)\n\n");
         exit(0);
      }
      if(strcmp(argv[i],"-w")==0)
         wmaker=TRUE;
      if(strcmp(argv[i],"-s")==0)
         ushape=TRUE;
      if(strcmp(argv[i],"-t")==0){
	 if(i<argc-1){
            i++;
            sscanf(argv[i],"%i",&tsel);
	 }
         continue;
      }
      if(strcmp(argv[i],"-v")==0){
         if(i<argc-1){
            i++;
            sscanf(argv[i],"%i",&vol);
         }
         continue;
      }
      if(strcmp(argv[i],"-a")==0){
         artwrk=TRUE;
	 if(i<argc-1){
            i++;
            sprintf(artwrkf,"%s",argv[i]);
         }
         continue;
      }
      if(strcmp(argv[i],"-d")==0){
	 if(i<argc-1){
            i++;
            sprintf(txtdev,"%s",argv[i]);
         }
         continue;
      }
      if(strcmp(argv[i],"-l")==0){
         if(i<argc-1){
            i++;
            sprintf(ledcol,"%s",argv[i]);
         }
         continue;
      }
      if(strcmp(argv[i],"-b")==0){
	 if(i<argc-1){
            i++;
            sprintf(bckcol,"%s",argv[i]);
	 }
         continue;
      }
      if(strcmp(argv[i],"-display")==0){
	 if(i<argc-1){
            i++;
            sprintf(txtdpy,"%s",argv[i]);
         }
         continue;
      }
   }
}

void checkStatus(bool forced){
   ucount=0;
   int oldmode=mode;
   int oldpos=pos;
   int oldtrack=track;

   cdctl->doStatus();
   mode=cdctl->getStatusState();
   track=cdctl->getStatusTrack();

   if(mode==ssStopped){
      if(tdisplay==0)
         pos=0;
      if(tdisplay==1)
         pos=cdctl->getTrackStart(track);
   }
   if(mode==ssPlaying || mode==ssPaused){
      if(tdisplay==0)
         pos=cdctl->getStatusPosRel();
      if(tdisplay==1)
         pos=cdctl->getStatusPosAbs();
   }

   bool uMode=mode!=oldmode || forced;
   bool uTrack=uMode || (!(mode==ssNoCD || mode==ssTrayOpen) && track!=oldtrack);
   bool uTimer=uTrack || ((mode==ssPlaying || mode==ssPaused || mode==ssStopped) && pos!=oldpos);

   if(uTimer){
      if(uMode)
         update();
      if(uTrack){
         if(mode==ssNoCD || mode==ssTrayOpen)
            sprintf(text_track,"  ");
         else
            sprintf(text_track,"%2d",cdctl->getStatusTrack());
         if(style_leds[1])
            drawText(style_ledpos[1][0],style_ledpos[1][1],text_track);
      }
      if(mode==ssPlaying || mode==ssPaused || mode==ssStopped){
         int remain;
         if(tdisplay==0)
            remain=cdctl->getTrackLen(cdctl->getStatusTrack())-pos;
         if(tdisplay==1)
            remain=cdctl->getCDLen()-pos;
         if(remain<2250)
            sprintf(text_timer," -;%02d",remain/75);
         else
            sprintf(text_timer,"%2d:%02d",(pos/75)/60,(pos/75)%60);
      }
      if(style_leds[0])
         drawText(style_ledpos[0][0],style_ledpos[0][1],text_timer);
      repaint();
   }
}

void pressEvent(XButtonEvent *xev){
   int x=xev->x;
   int y=xev->y;
   int btn=-1;
   for(int i=0;i<style_nbtns;i++){
      if(inPolygon(&style_btnlist[i][2], x, y)==TRUE)
         btn=i;
   }
   if(btn==-1){
      if(style_leds[3]){
         if(x>=style_ledpos[3][0] && y>=style_ledpos[3][1] && x<=style_ledpos[3][0]+style_ledsize[4] && y<=style_ledpos[3][1]+style_ledsize[5]){ 
            int tsels[] = { tsNone, tsNext, tsRepeat, tsRepeatCD, tsRandom };
            tsel++;
            if(tsel>=5)
               tsel=0;
            cdctl->setTrackSelection(tsels[tsel]);
            XCopyArea(dpy, tledXPM, disp, WinGC, (style_ledsize[4]+1)*tsel, 0, style_ledsize[4], style_ledsize[5], style_ledpos[3][0], style_ledpos[3][1]);
            repaint();
            return;
         }
      }
      if(style_leds[0]){
         if(x>=style_ledpos[0][0] && y>=style_ledpos[0][1] && x<=style_ledpos[0][0]+(style_ledsize[0]+1)*9-1 && y<=style_ledpos[0][1]+style_ledsize[1]){ 
            tdisplay++;
            if(tdisplay>=2)
               tdisplay=0;
            checkStatus(FALSE);
            return;
         }
      }
   }
   else{
      int action = style_factions[6*btn+mode];
      int acmds[] = { acStop, acPlay, acPause, acResume, acPrev, acNext, acRewd, acFFwd, acEject, acClose };
      if(action>0){
         int acmd = acmds[action-1];
         cdctl->doAudioCommand(acmd);
         checkStatus(FALSE);
      }
   }
}

void repaint(){
   XCopyArea(dpy,disp,Win[activeWin],WinGC,0,0,64,64,0,0);
   XEvent xev;
   while(XCheckTypedEvent(dpy, Expose, &xev));
}

void update(){
   if(mode==ssData)
      sprintf(text_timer,"dA;tA");
   if(mode==ssNoCD)
      sprintf(text_timer,"no;cd");
   if(mode==ssTrayOpen)
      sprintf(text_timer,"oP;En");

   XPoint mply[style_nbtns];
   if(cdMask!=None){
      XSetForeground(dpy, mGC, 0);
      XCopyArea(dpy, cdMask, dmsk, mGC, 0, 0, 64, 64, 0, 0);
      for(int i=0; i<style_nbtns; i++){
         if(style_factions[6*i+mode]==0 && style_hidebtns){
            for(int k=0;k<style_btnlist[i][2];k++){
               mply[k].x=style_btnlist[i][k*2+3];
               mply[k].y=style_btnlist[i][k*2+4];
            }
            XFillPolygon(dpy, dmsk, mGC, (XPoint *)mply, style_btnlist[i][2], Convex, CoordModeOrigin);
         }
      }
      if(!(wmaker || ushape)){
         XCopyArea(dpy, tile, disp, WinGC, 0, 0, 64, 64, 0, 0);
         XSetClipMask(dpy, WinGC, dmsk);
      }
   }
   XCopyArea(dpy, cdXPM, disp, WinGC, 0, 0, 64, 64, 0, 0);
   if(symMask!=None){
      XSetClipMask(dpy, WinGC, symMask);
      XSetClipMask(dpy, mGC, symMask);
   }
   XSetForeground(dpy, mGC, 1);
   for(int i=0; i<style_nbtns; i++){
      if(!(style_factions[6*i+mode]==0 && style_hidebtns)){
         int sympos=(style_symbolsize[0]+1)*(style_factions[6*i+mode]);
         XSetClipOrigin(dpy, WinGC, style_btnlist[i][0]-sympos, style_btnlist[i][1]);
         XSetClipOrigin(dpy, mGC, style_btnlist[i][0]-sympos, style_btnlist[i][1]);
         XCopyArea(dpy, symXPM, disp, WinGC, sympos, 0, style_symbolsize[0], style_symbolsize[1], style_btnlist[i][0], style_btnlist[i][1]);
         XFillRectangle(dpy, dmsk, mGC, style_btnlist[i][0], style_btnlist[i][1], style_symbolsize[0], style_symbolsize[1]);
      }
   }
   if(wmaker || ushape)
      XShapeCombineMask(dpy, Win[activeWin], ShapeBounding, 0, 0, dmsk, ShapeSet);
   XSetClipOrigin(dpy, WinGC, 0, 0);
   XSetClipOrigin(dpy, mGC, 0, 0);
   XSetClipMask(dpy, WinGC, None);
   XSetClipMask(dpy, mGC, None);
   if(style_leds[2])
      XCopyArea(dpy, sledXPM, disp, WinGC, (style_ledsize[2]+1)*mode, 0, style_ledsize[2], style_ledsize[3], style_ledpos[2][0], style_ledpos[2][1]);
   if(style_leds[3])
      XCopyArea(dpy, tledXPM, disp, WinGC, (style_ledsize[4]+1)*tsel, 0, style_ledsize[4], style_ledsize[5], style_ledpos[3][0], style_ledpos[3][1]);
}

void drawText(int x, int y, char *text){
   int drawx=x;
   for(int i=0;i<strlen(text);i++){
      char *chrptr = strchr(chrset,text[i]);
      if(chrptr!=NULL){
         int chrindex = chrptr-chrset;
         int chrwidth = style_ledsize[0];
         if(chrset[chrindex+1]==text[i])
            chrwidth = 2*style_ledsize[0]+1;
         XCopyArea(dpy, ledXPM, disp, WinGC, chrindex*(style_ledsize[0]+1), 0, chrwidth, style_ledsize[1], drawx, y);
         drawx+=chrwidth+1;
      }
   }
}

void readArtwork(char *artfilen){
   FILE *artfile=fopen(artfilen,"r");
   char buf[256];
   int done;
   do{
      fgets(buf,250,artfile);
      if((done=feof(artfile))==0){
         long filepos=ftell(artfile);
         bool readMore=FALSE;
         char *block;
         int items;
         fseek(artfile,-strlen(buf),SEEK_CUR);
         buf[strlen(buf)-1]=0;
         if(strstr(buf,"int style_nbtns=")==(char *)buf)
            sscanf(buf+strlen("int style_nbtns="),"%d",&style_nbtns);
         if(strstr(buf,"int style_btns[]={")==(char *)buf){
            block=readBlock(artfile);
            int items=arrayItems(block);
            style_fbtns=(int *)malloc(sizeof(int)*items);
            readArrayInt(block,style_fbtns,items);
            free(block);
            readMore=TRUE;
         }
         if(strstr(buf,"int style_actions[]={")==(char *)buf){
            block=readBlock(artfile);
            int items=arrayItems(block);
            style_factions=(int *)malloc(sizeof(int)*items);
            readArrayInt(block,style_factions,items);
            free(block);
            readMore=TRUE;
         }
         if(strstr(buf,"bool style_hidebtns=")==(char *)buf)
            style_hidebtns=(strstr(buf,"TRUE")!=NULL);
         if(strstr(buf,"bool style_leds[4]={")==(char *)buf)
            readArrayBool((char *)buf,(bool *)style_leds,4);
         if(strstr(buf,"int style_ledpos[4][2]={")==(char *)buf)
            readArrayInt((char *)buf,style_ledpos[0],8);
         if(strstr(buf,"int style_symbolsize[2]={")==(char *)buf)
            readArrayInt((char *)buf,(int *)style_symbolsize,2);
         if(strstr(buf,"/* XPM */")==(char *)buf){
            long prevpos=ftell(artfile);
            fgets(buf,250,artfile);
            fgets(buf,250,artfile);
            fseek(artfile,prevpos,SEEK_SET);
            block=readBlock(artfile);
            int w,h;
            if(strstr(buf,"cdplayer_xpm")==(char *)(buf+14))
               createPixmap(NULL, block, &cdXPM, &cdMask, NULL, NULL);
            if(strstr(buf,"symbols_xpm")==(char *)(buf+14)){
               createPixmap(NULL, block, &symXPM, &symMask, &w, &h);
               style_symbolsize[0]=(w+1)/11-1;
               style_symbolsize[1]=h;
            }
            if(strstr(buf,"led_xpm")==(char *)(buf+14)){
               createPixmap(NULL, block, &ledXPM, NULL, &w, &h);
               style_ledsize[0]=(w+1)/strlen(chrset)-1;
               style_ledsize[1]=h;
            }
            if(strstr(buf,"ledsym_xpm")==(char *)(buf+14)){
               createPixmap(NULL, block, &sledXPM, NULL, &w, &h);
               style_ledsize[2]=(w+1)/6-1;
               style_ledsize[3]=h;
            }
            if(strstr(buf,"ledtsel_xpm")==(char *)(buf+14)){
               createPixmap(NULL, block, &tledXPM, NULL, &w, &h);
               style_ledsize[4]=(w+1)/5-1;
               style_ledsize[5]=h;
            }
            free(block);
            readMore=TRUE;
         }
         if(!readMore)
            fseek(artfile,filepos,SEEK_SET);
      }
   }  while(done==0);
   fclose(artfile);
}

char *readBlock(FILE *dfile){
   char buf[256];
   long bytes=0;
   char *block=NULL;
   do{
      fgets(buf,250,dfile);
      int buflen=strlen(buf);
      block=(char *)realloc(block,sizeof(char)*(bytes+buflen+1));
      strcpy(block+bytes,buf);
      bytes+=buflen;
   }  while(strstr(buf,"}")==NULL);
   return block;
}

int arrayItems(char *buf){
   int items=1;
   char *bufptr=buf;
   while((bufptr=strstr(bufptr,","))!=NULL){
      bufptr++;
      items++;
   };
   return items;
}

void readArrayInt(char *buf,int *array,int n){
   char *bufptr;
   bufptr=strtok(buf,"{,}");
   for(int i=0;i<n;i++){
      bufptr=strtok(NULL,"{,}");
      sscanf(bufptr,"%d",&array[i]);
   }
}

void readArrayBool(char *buf,bool *array,int n){
   char *bufptr;
   bufptr=strtok(buf,"{,}");
   for(int i=0;i<n;i++){
      bufptr=strtok(NULL,"{,}");
      array[i]=(strstr(bufptr,"TRUE")!=NULL);
   }
}

void createPixmap(char *data[], char *buf, Pixmap *image, Pixmap *mask, int *width, int *height){
   XpmAttributes pixatt;
   XpmColorSymbol ledcols[4]={{"led_color_high", NULL, 0},
                              {"led_color_med",  NULL, 0},
                              {"led_color_low",  NULL, 0},
                              {"color_back",     NULL, 0}};
   ledcols[0].pixel=getColor(ledcol,1.00);
   ledcols[1].pixel=getColor(ledcol,1.65);
   ledcols[2].pixel=getColor(ledcol,2.60);
   ledcols[3].pixel=getColor(bckcol,1.00);
   pixatt.numsymbols=4;
   pixatt.colorsymbols=ledcols;
   pixatt.exactColors=FALSE;
   pixatt.closeness=40000;
   pixatt.valuemask=XpmColorSymbols | XpmExactColors | XpmCloseness | XpmSize;
   if(data!=NULL)
      XpmCreatePixmapFromData(dpy, Root, data, image, mask, &pixatt);
   else
      XpmCreatePixmapFromBuffer(dpy, Root, buf, image, mask, &pixatt);
   if(width!=NULL)
      *width=pixatt.width;
   if(height!=NULL)
      *height=pixatt.height;
}

void setBtnList(int *bset){
   // Create a list of pointers to button data.
   // So, for example, data for button 2 can be accessed as style_btnlist[2];
   // Also, the y co-ordinate of its symbol would be style_btnlist[2][1]

   style_btnlist=(int **)malloc(style_nbtns*sizeof(int *));
   int curpos=0;
   for(int i=0;i<style_nbtns;i++){
      style_btnlist[i]=&bset[0+curpos];
      curpos+=2*style_btnlist[i][2]+3;
   }
}

bool inPolygon(int *points, int px, int py){
   int lx=points[1];
   int ly=points[2];
   int x,y;
   for(int i=1;i<=points[0];i++){
      if(i==points[0]){
         x=points[1];
         y=points[2];
      }
      else{
         x=points[i*2+1];
         y=points[i*2+2];
      }
      int a=ly-y;
      int b=x-lx;
      int c=-a*x-b*y;
      if(a*px+b*py+c<0)
         return FALSE;
      lx=x;
      ly=y;
   }
   return TRUE;
}
