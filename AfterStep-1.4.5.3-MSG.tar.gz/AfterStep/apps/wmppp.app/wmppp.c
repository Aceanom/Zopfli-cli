/*
	Best viewed with vim5, using ts=4

	This code was mainly put together by looking at the
	following programs:

	asclock
		A neat piece of equip, used to display the date
		and time on the screen.
		Comes with every AfterStep installation.

		Source used:
			How do I create a not so solid window?
			How do I open a window?
			How do I use pixmaps?
	
	pppstats
		A program that prints the amount of data that
		is transferred over a ppp-line.

		Source used:
			How do I read the ppp device?
	------------------------------------------------------------

	Authors: Martijn Pieterse (pieterse@xs4all.nl)
		 Antoine Nulle (warp@xs4all.nl)

	This program was hacked together between the 7th of March
	and the 27th of April 1998.

	This program might be Y2K resistant. We shall see. :)

	This program is distributed under the GPL license.
	(as were asclock and pppstats)

	----
	Changes:
	---
	27/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* WMIFS: stats scrolled, while red led burning
		* WMPPP: changed positions of line speed
	25/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Changed the checknetdevs routine, a lot!
	25/04/1998 (Antoine Nulle, warp@xs4all.nl)
		* WMPPP: Hacked the master.xpm again ;-) 
	23/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added line speed detection. via seperate exec. (this has to be suid root!)
		  Speed has to be no more than 99999
		* Added speed and forcespeed in ~/.wmppprc and /etc/wmppprc
		* wmifs: added on-line detection scheme, update the bitmap coordinates
		* wmppp: the x-button now allways disconnects.
	22/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added /etc/wmppprc support, including "forced" mode.
		* Added /etc/wmifsrc support, including "forced" mode.
	21/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Moved the stats one pixel down.
		* Added status led in wmifs.
		* Changed RX/TX leds of wmifs to resemble wmppp
		* Added the "dot" between eth.0 ppp.0 etc.
		* Changed to wmifs stats to match wmppp stats (only pppX changed)
		* Made sure that when specified -t 1, it stayed that way, even
		  when longer than 100 minutes online
		* With -t 1, jump from 59:59 to 01:00 instead of 99:59 to 01:40
	16/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added "all" devices in wmifs
		* Added "lo" support only if aked via -i
		* Added on-line time detection (using /var/run/ppp0.pid)
		* Added time-out for the orange led. (one minute)
	15/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Another wmppp-master.xpm.
			Line speed detection being the main problem here.. :(
		* Moved START_COMMAND / STOP_COMMAND to ~/.wmppprc
			Return 0, everything went ok.
			Return 10, the command did not work.
			Please note, these functions are ran in the background.
		* Removed the ability to configure
		* When "v" is clicked, an orange led will appear.
		  if the connect script fails (return value == 10)
		  it will become dark again. Else the on-line detection will
		  pick it up, and "green" it.
	14/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added "-timer"
		* Added "-display" support
		* Changed pixmap to a no-name pixmap.
			+ Changed LED positions
			+ Changed Timer position
			+ Changed Stats Size
	05/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added ~/.wmifsrc support.
		* Put some code in DrawStats
		* Check devices when pressing "device change"
	03/04/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added code for wmifs
	28/03/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* forgot what i did.. :)
	27/03/1998 (Martijn Pieterse, pieterse@xs4all.nl)
		* Added on-line detection
			Scan through /proc/net/route and check everye line
			for "ppp".
		* A bit of code clean-up.
*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>

#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>

#include <net/ppp_defs.h>
#include <net/if_ppp.h>

#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include "wmppp-master.xpm"
#include "wmppp-mask.xbm"
#include "wmifs-master.xpm"
#include "wmifs-mask.xbm"

  /***********/
 /* Defines */
/***********/

#define STAMP_FILE "/var/run/ppp0.pid"

/* Defines voor alle coordinate */

#define LED_PPP_RX (1)
#define LED_PPP_TX (2)
#define LED_PPP_POWER (3)

#define LED_NET_RX (4)
#define LED_NET_TX (5)
#define LED_NET_POWER (6)

#define BUT_V (1)
#define BUT_X (2)
#define BUT_Q (3)

#define TIMER_X (9)
#define TIMER_Y (14)

#define TIMER_SRC_Y (65)
#define TIMER_DES_Y (6)
#define TIMER_SZE_X (6)

#define WMPPP_VERSION "1.2"
#define WMIFS_VERSION "1.2"

#define ORANGE_LED_TIMEOUT (60)

  /**********************/
 /* External Variables */
/**********************/

extern	char **environ;

  /********************/
 /* Global Variables */
/********************/

char	*ProgName;
int		TimerDivisor=60;
int		WaveForm=0;

  /*****************/
 /* X11 Variables */
/*****************/

Display		*display;
Window		Root;
int			screen;
int			x_fd;
int			d_depth;
XSizeHints	mysizehints;
XWMHints	mywmhints;
Pixel		back_pix, fore_pix;
char		*Geometry = "";
Window		iconwin, win;
GC			NormalGC;

  /*****************/
 /* XPM Variables */
/*****************/

typedef struct _XpmIcon {
	Pixmap			pixmap;
	Pixmap			mask;
	XpmAttributes	attributes;
} XpmIcon;
XpmIcon	wmppp_pixmap;
XpmIcon	wmifs_pixmap;

  /*****************/
 /* Mouse Regions */
/*****************/

typedef struct {
	int		enable;
	int		top;
	int		bottom;
	int		left;
	int		right;
} MOUSE_REGION;

#define MAX_MOUSE_REGION (8)
MOUSE_REGION	mouse_region[MAX_MOUSE_REGION];

#define 	PPP_UNIT		0
int			ppp_h = -1;

#define		PPP_STATS_HIS	54

int		pixels_per_byte;

int		ppp_history[PPP_STATS_HIS+1][2];

/* functions */
void usage(void);
void printversion(void);
void GetXPM(void);
Pixel GetColor(char *);
void RedrawWindow(XpmIcon *);
void AddMouseRegion(int, int, int, int, int);
int CheckMouseRegion(int, int);
void DrawTime(int, int);
void DrawStats(int *, int, int, int, int);

void SetOnLED(int);
void SetErrLED(int);
void SetWaitLED(int);
void SetOffLED(int);

void ButtonUp(int);
void ButtonDown(int);

void openXwindow(int, char **);

void wmppp_routine(int, char **);
void wmifs_routine(int, char **);

void get_ppp_stats(struct ppp_stats *cur);

char	*active_interface = NULL;

void main(int argc, char *argv[]) {

	int		i;
	

	/* Parse Command Line */

	ProgName = argv[0];
	if (strlen(ProgName) >= 5)
		ProgName += (strlen(ProgName) - 5);
	
	for (i=1; i<argc; i++) {
		char *arg = argv[i];

		if (*arg=='-') {
			switch (arg[1]) {
			case 'd' :
				if (strcmp(arg+1, "display")) {
					usage();
					exit(1);
				}
				break;
			case 'i' :
				active_interface = argv[i+1];
				i++;
				break;
			case 't' :
				TimerDivisor = atoi(argv[i+1]);
				if (TimerDivisor != 1 && TimerDivisor != 60) {
					usage();
					exit(1);
				}
				break;
			case 'v' :
				printversion();
				exit(0);
				break;
			case 'w' :
				WaveForm = 1;
				break;
			default:
				usage();
				exit(0);
				break;
			}
		}
	}

	if (!strcmp(ProgName, "wmppp"))
		wmppp_routine(argc, argv);
	else if (!strcmp(ProgName, "wmifs"))
		wmifs_routine(argc, argv);
}

  /*****************/
 /* wmppp_routine */
/*****************/

char	start_action[128];
char	stop_action[128];
char	speed_action[128];
char	ifdown_action[128];

void wmppp_routine(int argc, char **argv) {

	int				i,j,k;

	int				but_stat;

	long			starttime;
	long			currenttime;
	long			lasttime;
	long			waittime;
	long			ppptime;
	int				hour,minute;

	char			*args[10];

	int				ppp_send,ppp_sl=-1;
	int				ppp_recv,ppp_rl=-1;
	FILE			*fppp;
	FILE			*fp;
	char			temppp[128];

	int				linespeed;

	struct ppp_stats	ppp_cur, ppp_old;

	struct stat		st;

	pid_t			stop_child = 0;
	pid_t			start_child = 0;
	int				status;

	XEvent			Event;

	char			*p;
	char			temp[128];
	char			*tokens = " :\t\n";

	int				led_status;

	/* Initialize some stuff */
	for (i=0; i<MAX_MOUSE_REGION; i++) {
		mouse_region[i].enable = 0;
	}

	/* Open the ppp device. */
	memset(&ppp_cur, 0, sizeof(ppp_cur));
	if ((ppp_h = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		fprintf(stderr, "wmppp: could not open ppp0 is not available\n");
	}
	get_ppp_stats(&ppp_cur);
	ppp_old = ppp_cur;

	start_action[0] = 0;
	stop_action[0] = 0;
	speed_action[0] = 0;
	ifdown_action[0] = 0;

	/* Scan through ~/.wmifsrc for the mouse button actions. */
	p = getenv("HOME");
	strcpy(temp, p);
	strcat(temp, "/.wmppprc");
	fp = fopen(temp, "r");
	if (fp) {
		while (fgets(temp, 128, fp)) {
			if (strstr(temp, "start")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(start_action, p);
			} else if (strstr(temp, "stop")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(stop_action, p);
			} else if (strstr(temp, "speed")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(speed_action, p);
			} else if (strstr(temp, "ifdown")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(ifdown_action, p);
			}
		}
		fclose(fp);
	} 

	/* Scan throug /etc/wmppprc for the global actions */
	fp = fopen("/etc/wmppprc", "r");
	if (fp) {
		while (fgets(temp, 128, fp)) {
			if (strstr(temp, "start")) {
				if (!start_action[0] || strstr(temp, "forcestart")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(start_action, p);
				}
			} else if (strstr(temp, "stop")) {
				if (!stop_action[0] || strstr(temp, "forcestop")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(stop_action, p);
				}
			} else if (strstr(temp, "speed")) {
				if (!speed_action[0] || strstr(temp, "forcespeed")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(speed_action, p);
				}
			} else if (strstr(temp, "ifdown")) {
				if (!speed_action[0] || strstr(temp, "forceifdown")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(ifdown_action, p);
				}
			}
		}
		fclose(fp);
	} 

	/* Open the display */

	openXwindow(argc, argv);

	/* V Button */
	AddMouseRegion(0, 35, 48, 46, 58);
	/* x Button */
	AddMouseRegion(1, 47, 48, 58, 58);

	/* Draw 00:00 */
	DrawTime(0, 1);

	starttime = 0;
	currenttime = time(0);
	ppptime = 0;
	but_stat = -1;
	led_status = 0;		/* OFF */
	waittime = 0;

/* wmppp main loop */
	while (1) {
		lasttime = currenttime;
		currenttime = time(0);
		/* Check if any child has left the playground */
		i = waitpid(0, &status, WNOHANG);
		if (i == stop_child && stop_child != 0) {
			if (WIFEXITED(status)) {
				if (WEXITSTATUS(status) != 10) {

					

					starttime = 0;
					SetOffLED(LED_PPP_POWER);
					SetOffLED(LED_PPP_RX);
					SetOffLED(LED_PPP_TX);
					DrawTime(0, 1);
					RedrawWindow(&wmppp_pixmap);

				}
				stop_child = 0;
			}
		}
		if (i == start_child && start_child != 0) {
			if (WIFEXITED(status)) {
				if (WEXITSTATUS(status) == 10) {

					starttime = 0;
					SetOffLED(LED_PPP_POWER);
					DrawTime(0, 1);
					RedrawWindow(&wmppp_pixmap);

				}
				start_child = 0;
			}
		}

		/* On-line detectie! 1x per second */
	
		if (currenttime != lasttime) {
			fppp = fopen("/proc/net/route", "r");
			if (fppp) {
				i = 0;	/* Line is dead */
				while (fgets(temppp, 128, fppp)) {
					if (strstr(temppp, "ppp")) {
						if (!starttime) {
							starttime = currenttime;

							if (stat(STAMP_FILE, &st) == 0)
								starttime = st.st_mtime;

							SetOnLED(LED_PPP_POWER);
							led_status = 1;		/* On */
							waittime = 0;

							if (speed_action[0]) {
								fp = popen(speed_action, "r");

								linespeed = 0;
								if (fp) {
									while (fgets(temp, 128, fp))
										;

									pclose(fp);

									if ((p=strstr(temp, "CONNECT"))) {
										linespeed = atoi(p + 8);
									}

									k = 30;
									while (linespeed && k > 0) {
										switch (linespeed % 10) {
										case 1:
											k -= 2;
											XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
												1, 86, 2, 9, k, 48);
											break;
										case 0:
											k -= 5;
											XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
												43, 86, 5, 9, k, 48);
											break;
										default:
											k -= 5;
											XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
												(linespeed % 10)*5-7, 86, 5, 9, k, 48);
											break;
										}
										linespeed /= 10;
									}
								}
							}

							RedrawWindow(&wmppp_pixmap);
						} 
						i = 1; /* Line is alive */
					}
				}
				fclose(fppp);
				if (!i && starttime) {
					starttime = 0;
					SetErrLED(LED_PPP_POWER);
					led_status = 2;

					for (k=5; k<30; k++) {
						XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
						0, 86, 1, 9, k, 48);
					}
					if (!fork()) {	
						args[0] = ifdown_action;
						args[1] = NULL;
						execvp(ifdown_action, args);
					}

					RedrawWindow(&wmppp_pixmap);
				}
			}
		}
		
		if (waittime && waittime <= currenttime) {
			SetOffLED(LED_PPP_POWER);
			led_status = 0;
			RedrawWindow(&wmppp_pixmap);
			waittime = 0;
		}

		/* If we are on-line. Print the time we are */
		if (starttime) {
			i = currenttime - starttime;

			i /= TimerDivisor;

			if (i > 59 * 60 + 59) i /= 60;

			minute = i % 60;
			hour = (i / 60) % 100;
			i = hour * 100 + minute;

			DrawTime(i, currenttime % 2);
			/* We are online, so we can check for send/recv packets */

			get_ppp_stats(&ppp_cur);

			ppp_send = ppp_cur.p.ppp_opackets;
			ppp_recv = ppp_cur.p.ppp_ipackets;

			if (ppp_send != ppp_sl) SetOnLED(LED_PPP_TX);
			else 					SetOffLED(LED_PPP_TX);

			if (ppp_recv != ppp_rl) SetOnLED(LED_PPP_RX);
			else 					SetOffLED(LED_PPP_RX);

			ppp_sl = ppp_send;
			ppp_rl = ppp_recv;

			/* Every five seconds we check to load on the line */

			if ((currenttime - ppptime >= 0) || (ppptime == 0)) {

				ppptime = currenttime + 5;

				i = ppp_cur.p.ppp_ibytes - ppp_old.p.ppp_ibytes;
				j = ppp_cur.p.ppp_obytes - ppp_old.p.ppp_obytes;

				ppp_history[PPP_STATS_HIS][0] = i;
				ppp_history[PPP_STATS_HIS][1] = j;

				pixels_per_byte = 25 * 32;
				for (i=1; i<=PPP_STATS_HIS; i++) {
					ppp_history[i-1][0] = ppp_history[i][0];
					ppp_history[i-1][1] = ppp_history[i][1];

					if (ppp_history[i][0] + ppp_history[i][1] > pixels_per_byte)
						pixels_per_byte = ppp_history[i][0] + ppp_history[i][1];
				}

				pixels_per_byte /= 25;

				ppp_old = ppp_cur;

				for (i=0; i<PPP_STATS_HIS; i++) {
					for (j=0; j<25; j++) {
						if (j < ppp_history[i][0] / pixels_per_byte)
							XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
									57+2, 85, 1, 1, i+5, 43-j);
						else if (j < (ppp_history[i][0] + ppp_history[i][1]) / pixels_per_byte)
							XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
									57+1, 85, 1, 1, i+5, 43-j);
						else
							XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
									57+0, 85, 1, 1, i+5, 43-j);
					}
				}
			}

			RedrawWindow(&wmppp_pixmap);
		}

		while (XPending(display)) {
			XNextEvent(display, &Event);
			switch (Event.type) {
			case Expose:
				RedrawWindow(&wmppp_pixmap);
				break;
			case DestroyNotify:
				XCloseDisplay(display);
				while (start_child | stop_child) {
					i = waitpid(0, &status, WNOHANG);
					if (i == stop_child) stop_child = 0;
					if (i == start_child) start_child = 0;
					usleep(50000l);
				}
				exit(0);
				break;
			case ButtonPress:
				i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);
				switch (i) {
				case 0:
					ButtonDown(BUT_V);
					break;
				case 1:
					ButtonDown(BUT_X);
					break;
				}
				but_stat = i;

				RedrawWindow(&wmppp_pixmap);
				break;
			case ButtonRelease:
				i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);
				// Button but_stat omhoogdoen!
				switch (but_stat) {
				case 0:
					ButtonUp(BUT_V);
					break;
				case 1:
					ButtonUp(BUT_X);
					break;
				}

				if (i == but_stat && but_stat >= 0) {
					switch (i) {
					case 0:
						if (!starttime) {
							if (!(start_child = fork())) {	
								args[0] = start_action;
								args[1] = NULL;
								i = execvp(start_action, args);
								if (i < 0) exit (10);
							}
							SetWaitLED(LED_PPP_POWER);
							waittime = ORANGE_LED_TIMEOUT + currenttime;
						}

						break;
					case 1:
						if (stop_child == 0) {
							if (!(stop_child = fork())) {	
								args[0] = stop_action;
								args[1] = NULL;
								i = execvp(stop_action, args);
								if (i < 0) exit(10);
							}
						}
						break;
					}
				}
				RedrawWindow(&wmppp_pixmap);
					
				but_stat = -1;
				break;
			default:
				break;
			}
		}
		usleep(50000L);
	}
}

/*******************************************************************************\
|* wmifs_routine															   *|
\*******************************************************************************/

#define MAX_STAT_DEVICES 4

typedef struct {

	char	name[8];
	int		his[55][2];
	long	istatlast;
	long	ostatlast;
	
} stat_dev;

stat_dev	stat_devices[MAX_STAT_DEVICES];

char		left_action[80];
char		right_action[80];
char		middle_action[80];

int checknetdevs(void);
int get_statistics(char *, long *, long *, long *, long *);
int stillonline(char *);
void DrawActiveIFS(char *);

void wmifs_routine(int argc, char **argv) {

	int			i,j;
	XEvent		Event;
	int			but_stat = -1;

	int			stat_online;
	int			stat_current;

	long		starttime;
	long		curtime;
	long		nexttime;

	long		ipacket, opacket, istat, ostat;

	FILE		*fp;
	char		temp[128];
	char		*tokens = ": \t\n";
	char		*p;
	char		*args[10];

	/* Initialize some stuff */
	for (i=0; i<MAX_MOUSE_REGION; i++) {
		mouse_region[i].enable = 0;
	}

	for (i=0; i<MAX_STAT_DEVICES; i++) {
		stat_devices[i].name[0] = 0;
		for (j=0; j<48; j++) {
			stat_devices[i].his[j][0] = 0;
			stat_devices[i].his[j][1] = 0;
		}
	}

	stat_online = checknetdevs();

/*
	if (stat_online == 0) {
		exit(1);
	}
*/

	stat_current = 0;
	if (active_interface) {
		for (i=0; i<stat_online; i++) {
			if (!strcmp(stat_devices[i].name, active_interface))
				stat_current = i;
		}
	}

	/* Scan through ~/.wmifsrc for the mouse button actions. */
	left_action[0] = 0;
	right_action[0] = 0;
	middle_action[0] = 0;

	
	p = getenv("HOME");
	strcpy(temp, p);
	strcat(temp, "/.wmifsrc");
	fp = fopen(temp, "r");
	if (fp) {
		while (fgets(temp, 128, fp)) {
			if (strstr(temp, "left")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(left_action, p);
			} else if (strstr(temp, "right")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(right_action, p);
			} else if (strstr(temp, "middle")) {
				p = strtok(temp, tokens);
				p = strtok(NULL, tokens);
				strcpy(middle_action, p);
			}
		}
		fclose(fp);
	} 

	/* Scan throug /etc/wmifsrc for the global actions */
	fp = fopen("/etc/wmifsrc", "r");
	if (fp) {
		while (fgets(temp, 128, fp)) {
			if (strstr(temp, "left")) {
				if (!left_action[0] || strstr(temp, "forceleft")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(left_action, p);
				}
			} else if (strstr(temp, "right")) {
				if (!right_action[0] || strstr(temp, "forceright")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(right_action, p);
				}
			} else if (strstr(temp, "middle")) {
				if (!middle_action[0] || strstr(temp, "forcemiddle")) {
					p = strtok(temp, tokens);
					p = strtok(NULL, tokens);
					strcpy(middle_action, p);
				}
			}
		}
		fclose(fp);
	} 

	openXwindow(argc, argv);

	/* > Button */
	AddMouseRegion(0, 5, 5, 35, 15);
	AddMouseRegion(1, 5, 20, 58, 58);

	starttime = time(0);
	nexttime = starttime + 5;

	for (i=0; i<stat_online; i++) {
		get_statistics(stat_devices[i].name, &ipacket, &opacket, &istat, &ostat);
		stat_devices[i].istatlast = istat;
		stat_devices[i].ostatlast = ostat;
	}

	DrawActiveIFS(stat_devices[stat_current].name);

	while (1) {
		curtime = time(0);

		for (i=0; i<stat_online; i++) {
			get_statistics(stat_devices[i].name, &ipacket, &opacket, &istat, &ostat);
			stat_devices[i].his[53][0] += istat - stat_devices[i].istatlast;
			stat_devices[i].his[53][1] += ostat - stat_devices[i].ostatlast;


			if (i == stat_current) {
				if (!stillonline(stat_devices[i].name)) {
					SetErrLED(LED_NET_POWER);
				} else {
					SetOnLED(LED_NET_POWER);
				}

				if (stat_devices[i].istatlast == istat)
					SetOffLED(LED_NET_RX);
				else
					SetOnLED(LED_NET_RX);
			
				if (stat_devices[i].ostatlast == ostat)
					SetOffLED(LED_NET_TX);
				else
					SetOnLED(LED_NET_TX);
			}
			
			stat_devices[i].istatlast = istat;
			stat_devices[i].ostatlast = ostat;
		}
		
		if (curtime >= nexttime) {
			nexttime+=5;

			for (i=0; i<stat_online; i++) {
				if (i == stat_current) {

					DrawStats(&stat_devices[i].his[0][0], 54, 40, 5, 58);
				}
				if (stillonline(stat_devices[i].name)) {
					for (j=1; j<54; j++) {
						stat_devices[i].his[j-1][0] = stat_devices[i].his[j][0];
						stat_devices[i].his[j-1][1] = stat_devices[i].his[j][1];
					}
					stat_devices[i].his[53][0] = 0;
					stat_devices[i].his[53][1] = 0;
				}	
			}
		}
		RedrawWindow(&wmifs_pixmap);
	
		while (XPending(display)) {
			XNextEvent(display, &Event);
			switch (Event.type) {
			case Expose:
				RedrawWindow(&wmifs_pixmap);
				break;
			case DestroyNotify:
				XCloseDisplay(display);
				exit(0);
				break;
			case ButtonPress:
				i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);

				but_stat = i;
				break;
			case ButtonRelease:
				i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);

				if (but_stat == i && but_stat >= 0) {
					switch (but_stat) {
					case 0 :
						/* re-read the table */
						strcpy(temp, stat_devices[stat_current].name);
						stat_online = checknetdevs();
						stat_current = 0;
						for (i=0; i<stat_online; i++) {
							if (!strncmp(temp, stat_devices[i].name, 4)) {
								stat_current = i;
							}
						}
					
						stat_current++;
						if (stat_current == stat_online) stat_current = 0;

						DrawActiveIFS(stat_devices[stat_current].name);
	
						DrawStats(&stat_devices[stat_current].his[0][0], 54, 40, 5, 58);
						break;
					case 1:
						switch (Event.xbutton.button) {
						case 1:
							if (left_action[0])
								if (!fork()) {	
									args[0] = left_action;
									args[1] = NULL;
									i = execvp(left_action, args);
									if (i < 0) exit(10);
								}
							break;
						case 2:
							if (middle_action[0])
								if (!fork()) {	
									args[0] = middle_action;
									args[1] = NULL;
									i = execvp(middle_action, args);
									if (i < 0) exit(10);
								}
							break;
						case 3:
							if (right_action[0])
								if (!fork()) {	
									args[0] = right_action;
									args[1] = NULL;
									i = execvp(right_action, args);
									if (i < 0) exit(10);
								}
							break;
						}
						break;
					
					}
				}
				but_stat = -1;
				RedrawWindow(&wmifs_pixmap);
				break;
			}
		}

		usleep(50000L);
	}
}

/*******************************************************************************\
|* void DrawActiveIFS(char *)												   *|
\*******************************************************************************/

void DrawActiveIFS(char *name) {

	/* Cijfers op: 0,65
	   Letters op: 0,75
	   Alles 9 hoog, 6 breedt

	   Destinatie: 5,5
	*/

	int		i;
	int		c;
	int		k;


	XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
		5, 84, 30, 10, 5, 5);


	k = 5;
	for (i=0; name[i]; i++) {
		if (i == strlen(name)-1 && strlen(name) <= 4 && name[strlen(name)-1] >= '0' && name[strlen(name)-1] <= '9') {
			XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
				61, 64, 4, 9, k, 5);
			k+=4;
		}
		c = toupper(name[i]);
		if (c >= 'A' && c <= 'Z') {
			c -= 'A';
			XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
				c * 6, 74, 6, 9, k, 5);
			k += 6;
		} else {
			c -= '0';
			XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
				c * 6, 64, 6, 9, k, 5);
			k += 6;
		}
	}

}

/*******************************************************************************\
|* get_statistics															   *|
\*******************************************************************************/

int get_statistics(char *devname, long *ip, long *op, long *is, long *os) {

	FILE				*fp;
	char				temp[128];
	char				*p;
	char				*tokens = " |:\n";
	int					input, output;
	int					i;
	int					found;
	struct ppp_stats	ppp_cur, ppp_old;
	static int			ppp_opened = 0;

	
	if (!strncmp(devname, "ppp", 3)) {
		if (!ppp_opened) {
			/* Open the ppp device. */
			memset(&ppp_cur, 0, sizeof(ppp_cur));
			if ((ppp_h = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
				return -1;
			get_ppp_stats(&ppp_cur);
			ppp_old = ppp_cur;
			ppp_opened = 1;
		}

		get_ppp_stats(&ppp_cur);

		*op = ppp_cur.p.ppp_opackets;
		*ip = ppp_cur.p.ppp_ipackets;

		*is = ppp_cur.p.ppp_ibytes;
		*os = ppp_cur.p.ppp_obytes;

		return 0;
	}

	/* Read from /proc/net/dev the stats! */
	fp = fopen("/proc/net/dev", "r");
	fgets(temp, 128, fp);
	fgets(temp, 128, fp);

	input = -1;
	output = -1;
	i = 0;
	found = -1;

	p = strtok(temp, tokens);
	do {
		if (!(strcmp(p, "packets"))) {
			if (input == -1) input = i;
			else output = i;
		}
		i++;
		p = strtok(NULL, tokens);
	} while (input == -1 || output == -1);

	while (fgets(temp, 128, fp)) {
		if (strstr(temp, devname)) {
			found = 0;
			p = strtok(temp, tokens);
			i = 0;
			do {
				if (i == input) {
					*ip = *is = atoi(p);
					input = -1;
				}
				if (i == output) {
					*op = *os = atoi(p);
					output = -1;
				}
				i++;
				p = strtok(NULL, tokens);
			} while (input != -1 || output != -1);
		}
	}
	fclose(fp);

	return found;
}

/*******************************************************************************\
|* stillonline																   *|
\*******************************************************************************/

int stillonline(char *ifs) {

	FILE	*fp;
	char	temp[128];
	int		i;

	i = 0;
	fp = fopen("/proc/net/route", "r");
	if (fp) {
		while (fgets(temp, 128, fp)) {
			if (strstr(temp, ifs)) {
				i = 1; /* Line is alive */
			}
		}
		fclose(fp);
	}
	return i;
}

/*******************************************************************************\
|* checknetdevs																   *|
\*******************************************************************************/

int checknetdevs(void) {

	FILE	*fd;
	char	temp[128];
	char	*p;
	int		i=0,j;
	int		k;
	int		mask;
	int		devsfound=0;
	char	*tokens = " \t\n";
	char	foundbuffer[MAX_STAT_DEVICES][8];

	for (i=0; i<MAX_STAT_DEVICES; i++) {
		foundbuffer[i][0] = 0;
	}

	fd = fopen("/proc/net/route", "r");
	if (fd) {
		fgets(temp, 128, fd);
		p = strtok(temp, tokens);
		mask = 0;
		i = 0;
		do {
			if (!strcmp(p, "Mask")) {
				mask = i;
			}
			i++;
			p = strtok(NULL, tokens);
		} while (p && !mask);

		while (fgets(temp, 128, fd) && devsfound < MAX_STAT_DEVICES) {
			p = strtok(temp, tokens);
			for (j=0; j<mask; j++) {
				p = strtok(NULL, tokens);
			}
			if (p && strcmp("00000000", p)) {
				/* We rely on the interface name being the first!! */
				p = strtok(temp, tokens);
				if (p && *p) {
					if (strcmp(p, "lo")) {
						strcpy(foundbuffer[devsfound], p);
						devsfound++;
					} else if (active_interface) {
						if (!strcmp(active_interface, "lo")) {
							strcpy(foundbuffer[devsfound], p);
							devsfound++;
						}
					}
				}
			}
		}
		fclose(fd);
	}

	/* Nu foundbuffer naar stat_devices[].name kopieeren */

	for (i=0; i<MAX_STAT_DEVICES; i++) {
		/* Loop stat_devices na, als die naam niet voorkomt in foundbuffer, kill! */

		if (stat_devices[i].name[0]) {
			k = 0;
			for (j=0; j<MAX_STAT_DEVICES; j++) {
				if (!strcmp(stat_devices[i].name, foundbuffer[j])) {
					k = 1;
					foundbuffer[j][0] = 0;
				}
			}
			if (!k) stat_devices[i].name[0] = 0;
		}
	}

	for (i=0, j=0; j<MAX_STAT_DEVICES; i++) {

		while (!stat_devices[j].name[0] && j < MAX_STAT_DEVICES)
			j++;

		if (j < MAX_STAT_DEVICES && i != j) {
			stat_devices[i] = stat_devices[j];
		}
		
		j++;
	}
	i--;

	for (j=0; j<MAX_STAT_DEVICES; j++) {
		if (foundbuffer[j][0]) {
			
			strcpy(stat_devices[i].name, foundbuffer[j]);
			
			for (k=0; k<48; k++) {
				stat_devices[i].his[k][0] = 0;
				stat_devices[i].his[k][1] = 0;
			}

			i++;
		}
	}


	return devsfound;
}

/*******************************************************************************\
|* DrawTime																	   *|
\*******************************************************************************/

void DrawTime(int i, int j) {

	int	k = 1000;

	XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			TIMER_SZE_X*((i / k)%10)+1, TIMER_SRC_Y, 5, 7, 6+6*0, TIMER_DES_Y);
	k = k /10;
	XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			TIMER_SZE_X*((i / k)%10)+1, TIMER_SRC_Y, 5, 7, 6+6*1, TIMER_DES_Y);
	k = k /10;

	if (j)
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
				62, TIMER_SRC_Y, 1, 7, 6+6*2+1, TIMER_DES_Y);
	else
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
				63, TIMER_SRC_Y, 1, 7, 6+6*2+1, TIMER_DES_Y);
			
	XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			TIMER_SZE_X*((i / k)%10)+1, TIMER_SRC_Y, 5, 7, 6+6*2 + 4, TIMER_DES_Y);
	k = k /10;
	XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			TIMER_SZE_X*((i / k)%10)+1, TIMER_SRC_Y, 5, 7, 6+6*3 + 4, TIMER_DES_Y);
}

/*******************************************************************************\
|* DrawStats																   *|
\*******************************************************************************/

void DrawStats(int *his, int num, int size, int x_left, int y_bottom) {

	int		pixels_per_byte;
	int		j,k;
	int		*p;
	int		p0,p1,p2,p3;

	pixels_per_byte = 1*size;
	p = his;
	for (j=0; j<num; j++) {
		if (p[0] + p[1] > pixels_per_byte)
			pixels_per_byte = p[0] + p[1];
		p += 2;
	}

	pixels_per_byte /= size;
	p = his;

	for (k=0; k<num; k++) {
		p0 = p[0];
		p1 = p[1];


		if (WaveForm) {
			p2 = 0;
			p3 = 1;
			for (j=0; j<size; j++) {
				if (j < p0 / pixels_per_byte)
					XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
							100+2, 68, 1, 1, k+x_left, y_bottom-size/2+p2/2);
				else if (j < (p0 + p1) / pixels_per_byte)
					XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
							100+1, 68, 1, 1, k+x_left, y_bottom-size/2+p2/2);
				else
					XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
							100+0, 68, 1, 1, k+x_left, y_bottom-size/2+p2/2);
	
				p2 = (p2 + p3);
				p3 *= -1;
				p2 *= -1;
			}
			XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
				88, 66, 1, 1, k+x_left, y_bottom-size/2);
		} else {
			for (j=0; j<size; j++) {
				if (j < p0 / pixels_per_byte)
					XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
							100+2, 68, 1, 1, k+x_left, y_bottom-j);
				else if (j < (p0 + p1) / pixels_per_byte)
					XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
							100+1, 68, 1, 1, k+x_left, y_bottom-j);
				else
					XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
							100+0, 68, 1, 1, k+x_left, y_bottom-j);
			}
		}
		p += 2;
	}
}

/*******************************************************************************\
|* usage																	   *|
\*******************************************************************************/

void usage(void) {

	if (!strcmp(ProgName, "wmppp")) {
		fprintf(stderr, "\nwmppp - programming: tijno, (de)bugging & design: warpstah\n\n");
		fprintf(stderr, "usage:\n");
		fprintf(stderr, "\t-display <display name>\n");
		fprintf(stderr, "\t-h\tthis screen\n");
		fprintf(stderr, "\t-t <dtime> (dtime == 1 or dtime == 60 (def))\n");
		fprintf(stderr, "\t-v\tprint the version number\n");
		fprintf(stderr, "\n");
	} else {
		fprintf(stderr, "\nwmifs - programming: tijno, (de)bugging & design: warpstah\n\n");
		fprintf(stderr, "usage:\n");
		fprintf(stderr, "\t-d <display name>\n");
		fprintf(stderr, "\t-h\tthis help screen\n");
		fprintf(stderr, "\t-i <interface name>\tdefault (as it appears in /proc/net/route)\n");
		fprintf(stderr, "\t-v\tprint the version number\n");
		fprintf(stderr, "\t-w\twaveform load\n");
		fprintf(stderr, "\n");
	}
}

/*******************************************************************************\
|* printversion																   *|
\*******************************************************************************/

void printversion(void) {

	if (!strcmp(ProgName, "wmppp")) {
		fprintf(stderr, "%s\n", WMPPP_VERSION);
	} else {
		fprintf(stderr, "%s\n", WMIFS_VERSION);
	}
}

/*******************************************************************************\
|* GetXPM																	   *|
\*******************************************************************************/

void GetXPM(void) {

	XWindowAttributes	attributes;
	int					err;

	/* For the colormap */
	XGetWindowAttributes(display, Root, &attributes);

	if (!strcmp(ProgName, "wmppp")) {
		wmppp_pixmap.attributes.valuemask |= (XpmReturnPixels | XpmReturnExtensions);
		err = XpmCreatePixmapFromData(display, Root, wmppp_master_xpm, &wmppp_pixmap.pixmap,
						&wmppp_pixmap.mask, &wmppp_pixmap.attributes);
	} else {
		wmifs_pixmap.attributes.valuemask |= (XpmReturnPixels | XpmReturnExtensions);
		err = XpmCreatePixmapFromData(display, Root, wmifs_master_xpm, &wmifs_pixmap.pixmap,
						&wmifs_pixmap.mask, &wmifs_pixmap.attributes);
	}
	
	if (err != XpmSuccess) {
		fprintf(stderr, "Not enough free colorcells.\n");
		exit(1);
	}
}

/*******************************************************************************\
|* GetColor																	   *|
\*******************************************************************************/

Pixel GetColor(char *name) {

	XColor				color;
	XWindowAttributes	attributes;

	XGetWindowAttributes(display, Root, &attributes);

	color.pixel = 0;
	if (!XParseColor(display, attributes.colormap, name, &color)) {
		fprintf(stderr, "wmppp: can't parse %s.\n", name);
	} else if (!XAllocColor(display, attributes.colormap, &color)) {
		fprintf(stderr, "wmppp: can't allocate %s.\n", name);
	}
	return color.pixel;
}

/*******************************************************************************\
|* flush_expose																   *|
\*******************************************************************************/

int flush_expose(Window w) {

	XEvent 		dummy;
	int			i=0;

	while (XCheckTypedWindowEvent(display, w, Expose, &dummy))
		i++;

	return i;
}

/*******************************************************************************\
|* RedrawWindow																   *|
\*******************************************************************************/

void RedrawWindow(XpmIcon *v) {
	
	flush_expose(iconwin);
	XCopyArea(display, v->pixmap, iconwin, NormalGC, 
				0,0, v->attributes.width, v->attributes.height, 0,0);
	flush_expose(win);
	XCopyArea(display, v->pixmap, win, NormalGC,
				0,0, v->attributes.width, v->attributes.height, 0,0);
}

/*******************************************************************************\
|* AddMouseRegion															   *|
\*******************************************************************************/

void AddMouseRegion(int index, int left, int top, int right, int bottom) {

	if (index < MAX_MOUSE_REGION) {
		mouse_region[index].enable = 1;
		mouse_region[index].top = top;
		mouse_region[index].left = left;
		mouse_region[index].bottom = bottom;
		mouse_region[index].right = right;
	}
}

/*******************************************************************************\
|* CheckMouseRegion															   *|
\*******************************************************************************/

int CheckMouseRegion(int x, int y) {

	int		i;
	int		found;

	found = 0;

	for (i=0; i<MAX_MOUSE_REGION && !found; i++) {
		if (mouse_region[i].enable &&
			x <= mouse_region[i].right &&
			x >= mouse_region[i].left &&
			y <= mouse_region[i].bottom &&
			y >= mouse_region[i].top)
			found = 1;
	}
	if (!found) return -1;
	return (i-1);
}

/*******************************************************************************\
|* get_ppp_stats															   *|
\*******************************************************************************/

void get_ppp_stats(struct ppp_stats *cur) {

	struct ifpppstatsreq    req;

	memset(&req, 0, sizeof(req));

	req.stats_ptr = (caddr_t) &req.stats;

	sprintf(req.ifr__name, "ppp%d", PPP_UNIT);

	if (ioctl(ppp_h, SIOCGPPPSTATS, &req) < 0) {
		fprintf(stderr, "heyho!\n");
	}

	*cur = req.stats;
}

#define LED_ON_X (50)
#define LED_ON_Y (80)
#define LED_OFF_Y (75)
#define LED_OFF_X (50)
#define LED_ERR_X (56)
#define LED_ERR_Y (75)
#define LED_WTE_X (56)
#define LED_WTE_Y (80)
#define LED_SZE_X (4)
#define LED_SZE_Y (4)
#define LED_SW_SZE_X (4)
#define LED_SW_SZE_Y (7)

#define LED_ON_NET_X (87) 
#define LED_ON_NET_Y (66)
#define LED_OFF_NET_X (93) 
#define LED_OFF_NET_Y (66)
#define LED_ERR_NET_X (81) 
#define LED_ERR_NET_Y (66)
#define LED_ON_SW_NET_X (49)
#define LED_ON_SW_NET_Y (85)
#define LED_OFF_SW_NET_X (44)
#define LED_OFF_SW_NET_Y (85)

#define LED_PWR_X (53)
#define LED_PWR_Y (7)
#define LED_SND_X (47)
#define LED_SND_Y (7)
#define LED_RCV_X (41)
#define LED_RCV_Y (7)

#define LED_SW_X (38)
#define LED_SW_Y (14)

/*******************************************************************************\
|* SetOnLED 																   *|
\*******************************************************************************/
void SetOnLED(int led) {

	switch (led) {
	case LED_PPP_POWER:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_ON_X, LED_ON_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	case LED_PPP_RX:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_ON_X, LED_ON_Y, LED_SZE_X, LED_SZE_Y,  LED_RCV_X, LED_RCV_Y);
		break;
	case LED_PPP_TX:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_ON_X, LED_ON_Y, LED_SZE_X, LED_SZE_Y,  LED_SND_X, LED_SND_Y);
		break;

	case LED_NET_RX:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_ON_NET_X, LED_ON_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_RCV_X, LED_RCV_Y);
		break;
	case LED_NET_TX:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_ON_NET_X, LED_ON_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_SND_X, LED_SND_Y);
		break;
	case LED_NET_POWER:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_ON_NET_X, LED_ON_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	}
}

/*******************************************************************************\
|* SetOffLED																   *|
\*******************************************************************************/
void SetOffLED(int led) {

	switch (led) {
	case LED_PPP_POWER:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_OFF_X, LED_OFF_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	case LED_PPP_RX:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_OFF_X, LED_OFF_Y, LED_SZE_X, LED_SZE_Y,  LED_RCV_X, LED_RCV_Y);
		break;
	case LED_PPP_TX:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_OFF_X, LED_OFF_Y, LED_SZE_X, LED_SZE_Y,  LED_SND_X, LED_SND_Y);
		break;

	case LED_NET_RX:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_OFF_NET_X, LED_OFF_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_RCV_X, LED_RCV_Y);
		break;
	case LED_NET_TX:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_OFF_NET_X, LED_OFF_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_SND_X, LED_SND_Y);
		break;
	case LED_NET_POWER:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_OFF_NET_X, LED_OFF_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	}
}

/*******************************************************************************\
|* SetErrLED 																   *|
\*******************************************************************************/
void SetErrLED(int led) {

	switch (led) {
	case LED_PPP_POWER:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_ERR_X, LED_ERR_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	case LED_NET_POWER:
		XCopyArea(display, wmifs_pixmap.pixmap, wmifs_pixmap.pixmap, NormalGC,
			LED_ERR_NET_X, LED_ERR_NET_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	}
}

/*******************************************************************************\
|* SetWaitLED 																   *|
\*******************************************************************************/
void SetWaitLED(int led) {

	switch (led) {
	case LED_PPP_POWER:
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			LED_WTE_X, LED_WTE_Y, LED_SZE_X, LED_SZE_Y,  LED_PWR_X, LED_PWR_Y);
		break;
	}
}

/*******************************************************************************\
|* ButtonUp 																   *|
\*******************************************************************************/
void ButtonUp(int button) {

	switch (button) {
	case BUT_V :
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			24, 74, 12, 11, 35, 48);
		break;
	case BUT_X :
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			36, 74, 12, 11, 47, 48);
		break;
	}
}

/*******************************************************************************\
|* ButtonDown																   *|
\*******************************************************************************/
void ButtonDown(int button) {

	switch (button) {
	case BUT_V :
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			0, 74, 12, 11, 35, 48);
		break;
	case BUT_X :
		XCopyArea(display, wmppp_pixmap.pixmap, wmppp_pixmap.pixmap, NormalGC,
			12, 74, 12, 11, 47, 48);
		break;
	}
}

/*******************************************************************************\
|* openXwindow																   *|
\*******************************************************************************/
void openXwindow(int argc, char *argv[]) {

	unsigned int	borderwidth = 1;
	XClassHint		classHint;
	char			*display_name = NULL;
	char			*wname = ProgName;
	XTextProperty	name;

	XGCValues		gcv;
	unsigned long	gcm;

	Pixmap			pixmask;

	int				dummy=0;
	int				i;

	for (i=1; argv[i]; i++) {
		if (!strcmp(argv[i], "-display")) 
			display_name = argv[i+1];
	}

	if (!(display = XOpenDisplay(display_name))) {
		fprintf(stderr, "%s: can't open display %s\n", 
						ProgName, XDisplayName(display_name));
		exit(1);
	}
	screen  = DefaultScreen(display);
	Root    = RootWindow(display, screen);
	d_depth = DefaultDepth(display, screen);
	x_fd    = XConnectionNumber(display);

	/* Convert XPM to XImage */
	GetXPM();

	/* Create a window to hold the stuff */
	mysizehints.flags = USSize | USPosition;
	mysizehints.x = 0;
	mysizehints.y = 0;

	back_pix = GetColor("white");
	fore_pix = GetColor("black");

	XWMGeometry(display, screen, Geometry, NULL, borderwidth, &mysizehints,
				&mysizehints.x, &mysizehints.y,&mysizehints.width,&mysizehints.height, &dummy);

	mysizehints.width = 64;
	mysizehints.height = 64;
		
	win = XCreateSimpleWindow(display, Root, mysizehints.x, mysizehints.y,
				mysizehints.width, mysizehints.height, borderwidth, fore_pix, back_pix);
	
	iconwin = XCreateSimpleWindow(display, win, mysizehints.x, mysizehints.y,
				mysizehints.width, mysizehints.height, borderwidth, fore_pix, back_pix);

	/* Activate hints */
	XSetWMNormalHints(display, win, &mysizehints);
	classHint.res_name = ProgName;
	classHint.res_class = ProgName;
	XSetClassHint(display, win, &classHint);

	XSelectInput(display, win, ButtonPressMask | ExposureMask | ButtonReleaseMask | PointerMotionMask | StructureNotifyMask);
	XSelectInput(display, iconwin, ButtonPressMask | ExposureMask | ButtonReleaseMask | PointerMotionMask | StructureNotifyMask);

	if (XStringListToTextProperty(&wname, 1, &name) == 0) {
		fprintf(stderr, "%s: can't allocate window name\n", ProgName);
		exit(1);
	}

	XSetWMName(display, win, &name);

	/* Create GC for drawing */
	
	gcm = GCForeground | GCBackground | GCGraphicsExposures;
	gcv.foreground = fore_pix;
	gcv.background = back_pix;
	gcv.graphics_exposures = 0;
	NormalGC = XCreateGC(display, Root, gcm, &gcv);

	/* ONLYSHAPE ON */

	if (!strcmp(ProgName, "wmppp")) {
		pixmask = XCreateBitmapFromData(display, win, wmppp_mask_bits, wmppp_mask_width,
					wmppp_mask_height);
	} else {
		pixmask = XCreateBitmapFromData(display, win, wmifs_mask_bits, wmifs_mask_width,
					wmifs_mask_height);
	}

	XShapeCombineMask(display, win, ShapeBounding, 0, 0, pixmask, ShapeSet);
	XShapeCombineMask(display, iconwin, ShapeBounding, 0, 0, pixmask, ShapeSet);

	/* ONLYSHAPE OFF */

	mywmhints.initial_state = WithdrawnState;
	mywmhints.icon_window = iconwin;
	mywmhints.icon_x = mysizehints.x;
	mywmhints.icon_y = mysizehints.y;
	mywmhints.window_group = win;
	mywmhints.flags = StateHint | IconWindowHint | IconPositionHint | WindowGroupHint;

	XSetWMHints(display, win, &mywmhints);

	XSetCommand(display, win, argv, argc);
	XMapWindow(display, win);

}
