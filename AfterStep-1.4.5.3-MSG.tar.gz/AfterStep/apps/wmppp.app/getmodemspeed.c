#include <stdio.h>

void main(void) {

	FILE	*fd;
	char	temp[256];
	
	

	fd = popen("tac /var/log/messages | grep CONNECT | head -1", "r");

	while (fgets(temp, 256, fd)) {
		printf("%s", temp);
	}

	pclose(fd);
}
