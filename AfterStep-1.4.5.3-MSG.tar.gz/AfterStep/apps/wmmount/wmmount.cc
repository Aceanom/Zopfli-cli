// wmmount - the WindowMaker universal mount point designed
// 07/05/98  Release 0.8
// Copyright (C) 1998  Sam Hawker <shawkie@geocities.com>
// This software comes with ABSOLUTELY NO WARRANTY
// This software is free software, and you are welcome to redistribute it
// under certain conditions
// See the README file for a more complete notice.

#define WINDOWMAKER FALSE
#define USESHAPE FALSE
#define NAME "wmmount"
#define CLASS "WMMount"

#define SYSRCFILE "/usr/lib/wmmount/system.wmmount"
#define BACKCOLOR "#282828"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#ifdef __linux__
#include <mntent.h>
#include <sys/vfs.h>
#endif

#ifdef __FreeBSD__
#include <sys/param.h>
#include <sys/mount.h>
#endif

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#ifndef TRUE
#define FALSE 0
#define TRUE 1
#endif

Pixmap back;
Pixmap tile;
Pixmap disp;
Pixmap mask;

#include "XPM/wmmount.xpm"
#include "XPM/tile.xpm"

struct MPInfo{
   char name[256];
   char mpoint[256];
   int icon;
   bool shwcap;
};

struct MPInfo *mpoint[20];
Pixmap icons[20];
int mpoints=0;
int nicons=0;
int curmnt=0;

bool cmounted;
int ccap;

// For new buttons
int btnstate=0;
#define btnNext  1
#define btnPrev  2
#define btnMnt   4

// With repeat next/prev if you hold down mouse button
#define btnrepeat 5
int btntimer=0;

// And double-click for open
#define dclick 5
int dtimer=0;

// Defaults. So these can be left out of ~/.wmmount if you like.
char mountcmd[256]="mount %s &";
char umountcmd[256]="umount %s &";
char opencmd[256]="nxterm -e mc %s &";
char txtfont[256]="-*-helvetica-bold-r-*-*-10-*-*-*-*-*-*-*";
char txtcolor[256]="black";
char capfont[256]="-*-helvetica-medium-r-*-*-10-*-*-*-*-*-*-*";
char capcolor[256]="gray90";

// Defaults. Altered by command line options.
bool wmaker = WINDOWMAKER;
bool ushape = USESHAPE;
char txtdpy[256] = "";
char bckcol[256] = BACKCOLOR;

Atom _XA_GNUSTEP_WM_FUNC;
Atom deleteWin;

Display *dpy;
Window Win[2];
Window Root;
XWMHints *hints;
GC WinGC;
int activeWin;

Font gcf1,gcf2;
unsigned long gcc1,gcc2;
int txtx1,txty1,txtx2=8,txty2=40;

// Standard dock-app stuff
void initXWin(int argc, char *argv[]);
void freeXWin();
void createWin(Window *win);
unsigned long getColor(char *colorName, float dim);

// Custom dock-app stuff
void scanArgs(int argc, char *argv[]);
void readFile();
void checkMount(bool forced);
void pressEvent(XButtonEvent *xev);
void releaseEvent(XButtonEvent *xev);
void repaint();
void update();
void drawBtns(int btns);
void drawBtn(int x, int y, int w, int h, bool down);

// Special stuff
void newSystem(char *command);

int main(int argc, char *argv[])
{
   scanArgs(argc,argv);
   initXWin(argc,argv);

   XGCValues gcv;
   unsigned long gcm;
   gcm = GCForeground|GCBackground|GCGraphicsExposures;
   gcv.graphics_exposures = False;
   WinGC = XCreateGC(dpy, Root, gcm, &gcv);

   XpmAttributes pixatt;
   XpmColorSymbol ledcols[1]={{"back_color", NULL, 0}};
   ledcols[0].pixel=getColor(bckcol, 1.00);
   pixatt.numsymbols=1;
   pixatt.colorsymbols=ledcols;
   pixatt.exactColors=FALSE;
   pixatt.closeness=40000;
   pixatt.valuemask=XpmColorSymbols | XpmExactColors | XpmCloseness;
   XpmCreatePixmapFromData(dpy, Root, wmmount_xpm, &back, &mask, &pixatt);
   XpmCreatePixmapFromData(dpy, Root, tile_xpm, &tile, NULL, &pixatt);
   disp = XCreatePixmap(dpy, Root, 64, 64, DefaultDepth(dpy,DefaultScreen(dpy)));

   // Install mask or copy background tile
   if(wmaker || ushape)
      XShapeCombineMask(dpy, Win[activeWin], ShapeBounding, 0, 0, mask, ShapeSet);
   else
      XCopyArea(dpy, tile, disp, WinGC, 0,0,64,64,0,0);

   // Copy background
   XSetClipMask(dpy, WinGC, mask);
   XCopyArea(dpy, back, disp, WinGC, 0,0,64,64,0,0);
   XSetClipMask(dpy, WinGC, None);

   readFile();

   if(mpoints!=0){
      XFontStruct *xfs;
      xfs = XLoadQueryFont(dpy, txtfont);
      gcf1 = xfs->fid;
      gcc1 = getColor(txtcolor, 1);
      txtx1 = 6-xfs->min_bounds.lbearing;
      txty1 = 5+xfs->ascent;
      txty2 = txty1+xfs->descent;

      xfs = XLoadQueryFont(dpy, capfont);
      gcf2 = xfs->fid;
      gcc2 = getColor(capcolor, 1);
      txtx2 = 6-xfs->min_bounds.lbearing;
      txty2 = txty2+xfs->ascent;

      checkMount(TRUE);                 // forced first time

      XEvent event;
      XSelectInput(dpy, Win[activeWin], ExposureMask | ButtonPressMask | ButtonReleaseMask);
      XMapWindow(dpy, Win[0]);

      bool finished=FALSE;
      while(!finished){
         while(XPending(dpy)){
            XNextEvent(dpy,&event);
            switch(event.type){
             case Expose:
                repaint();
             break;
             case ButtonPress:
                pressEvent(&event.xbutton);
             break;
             case ButtonRelease:
                releaseEvent(&event.xbutton);
             break;
             case ClientMessage:
                if(event.xclient.data.l[0]==deleteWin)
                   finished=TRUE;
             break;
            }
         }

         // Double-click timeout
         if(dtimer>0)
            dtimer--;

         // Repeat next/prev
         if(btnstate & (btnPrev | btnNext)){
            btntimer++;
            if(btntimer>=btnrepeat){
               if(btnstate & btnNext)
                  curmnt++;
               else
                  curmnt--;
               if(curmnt<0)
                  curmnt=mpoints-1;
               if(curmnt>=mpoints)
                  curmnt=0;
               checkMount(TRUE);      // forced because of changed mount point
               btntimer=0;
            }
         }
         else{
            // Check mounts, and update as needed
            checkMount(FALSE);
         }
         XFlush(dpy);
         usleep(50000L);
      }
   }

   while(mpoints>0){
      free(mpoint[mpoints-1]);
      mpoints--;
   }
   while(nicons>0){
      XFreePixmap(dpy,icons[nicons-1]);
      nicons--;
   }
   XFreeGC(dpy,WinGC);
   XUnloadFont(dpy, gcf1);
   XUnloadFont(dpy, gcf2);
   XFreePixmap(dpy, disp);
   XFreePixmap(dpy, mask);
   XFreePixmap(dpy, tile);
   XFreePixmap(dpy, back);
   freeXWin();
   return 0;
}

void initXWin(int argc, char *argv[]){
   if((dpy=XOpenDisplay(txtdpy))==NULL){
      fprintf(stderr,"You're probably trying to run an X app from the console, you idiot! RTFM\n");
      exit(1);
   }
   _XA_GNUSTEP_WM_FUNC = XInternAtom(dpy, "_GNUSTEP_WM_FUNCTION", False);
   deleteWin = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
   Root=DefaultRootWindow(dpy);
   createWin(&Win[0]);
   createWin(&Win[1]);
   XWMHints hints;
   XSizeHints shints;
   hints.window_group = Win[0];
   shints.min_width=64;
   shints.min_height=64;
   shints.max_width=64;
   shints.max_height=64;
   shints.x=0;
   shints.y=0;
   if(wmaker){
      hints.initial_state = WithdrawnState;
      hints.icon_window = Win[1];
      hints.flags = WindowGroupHint | StateHint | IconWindowHint;
      shints.flags = PMinSize | PMaxSize | PPosition;
      activeWin=1;
   }
   else{
      hints.initial_state = NormalState;
      hints.flags = WindowGroupHint | StateHint;
      shints.flags = PMinSize | PMaxSize;
      activeWin=0;
   }
   XSetWMHints(dpy, Win[0], &hints);
   XSetWMNormalHints(dpy, Win[0], &shints);
   XSetCommand(dpy, Win[0], argv, argc);
   XStoreName(dpy, Win[0], NAME);
   XSetIconName(dpy, Win[0], NAME);
   XSetWMProtocols(dpy, Win[activeWin], &deleteWin, 1);
}

void freeXWin(){
   XDestroyWindow(dpy, Win[0]);
   XDestroyWindow(dpy, Win[1]);
   XCloseDisplay(dpy);
}

void createWin(Window *win){
   XClassHint classHint;
   *win = XCreateSimpleWindow(dpy, Root, 10, 10, 64, 64,0,0,0);
   classHint.res_name = NAME;
   classHint.res_class = CLASS;
   XSetClassHint(dpy, *win, &classHint);
}

unsigned long getColor(char *colorName, float dim)
{
   XColor Color;
   XWindowAttributes Attributes;

   XGetWindowAttributes(dpy, Root, &Attributes);
   Color.pixel = 0;

   XParseColor (dpy, Attributes.colormap, colorName, &Color);
   Color.red=(unsigned short)(Color.red/dim);
   Color.blue=(unsigned short)(Color.blue/dim);
   Color.green=(unsigned short)(Color.green/dim);
   Color.flags=DoRed | DoGreen | DoBlue;
   XAllocColor (dpy, Attributes.colormap, &Color);

   return Color.pixel;
}

void scanArgs(int argc, char *argv[]){
   for(int i=1;i<argc;i++){
      if(strcmp(argv[i],"-h")==0 || strcmp(argv[i],"-help")==0 || strcmp(argv[i],"--help")==0){
         fprintf(stderr,"wmmount - the WindowMaker universal mount point\n07/05/98  Release 0.8\n");
         fprintf(stderr,"Copyright (C) 1998  Sam Hawker <shawkie@geocities.com>\n");
         fprintf(stderr,"This software comes with ABSOLUTELY NO WARRANTY\n");
         fprintf(stderr,"This software is free software, and you are welcome to redistribute it\n");
         fprintf(stderr,"under certain conditions\n");
         fprintf(stderr,"See the README file for a more complete notice.\n\n");
         fprintf(stderr,"usage:\n\n   %s [options]\n\noptions:\n\n",argv[0]);
         fprintf(stderr,"   -h | -help | --help    display this help screen\n");
         fprintf(stderr,"   -w                     use WithdrawnState    (for WindowMaker)\n");
         fprintf(stderr,"   -s                     shaped window\n");
         fprintf(stderr,"   -b back_color          use the specified color for backgrounds\n");
         fprintf(stderr,"   -display display       select target display (see X manual pages)\n\n");
         exit(0);
      }
      if(strcmp(argv[i],"-w")==0)
         wmaker=TRUE;
      if(strcmp(argv[i],"-s")==0)
         ushape=TRUE;
      if(strcmp(argv[i],"-b")==0){
	 if(i<argc-1){
            i++;
            sprintf(bckcol,"%s",argv[i]);
	 }
         continue;
      }
      if(strcmp(argv[i],"-display")==0){
         if(i<argc-1){
            i++;
            sprintf(txtdpy,"%s",argv[i]);
         }
         continue;
      }
   }
}

void readFile(){
   FILE *rcfile;
   char rcfilen[256];
   char buf[256];
   int done;
   sprintf(rcfilen,"%s/.wmmount",getenv("HOME"));
   if((rcfile=fopen(rcfilen,"r"))==NULL){
      fprintf(stderr,"Unable to read file ~/.wmmount\n");
      if((rcfile=fopen(SYSRCFILE,"r"))==NULL){
         fprintf(stderr,"Unable to read file %s\nDo not expect wmmount to function correctly\n",SYSRCFILE);
         return;
      }
   }
   XpmAttributes pixatt;
   pixatt.exactColors=FALSE;
   pixatt.closeness=40000;
   pixatt.valuemask=XpmExactColors | XpmCloseness;
   do{
      fgets(buf,250,rcfile);
      if((done=feof(rcfile))==0){
         buf[strlen(buf)-1]=0;
         if(strstr(buf,"mountcmd=")==(char *)buf)
            sprintf(mountcmd,"%s",buf+strlen("mountcmd="));
         if(strstr(buf,"umountcmd=")==(char *)buf)
            sprintf(umountcmd,"%s",buf+strlen("umountcmd="));
         if(strstr(buf,"opencmd=")==(char *)buf)
            sprintf(opencmd,"%s",buf+strlen("opencmd="));
         if(strstr(buf,"txtcolor=")==(char *)buf)
            sprintf(txtcolor,"%s",buf+strlen("txtcolor="));
         if(strstr(buf,"txtfont=")==(char *)buf)
            sprintf(txtfont,"%s",buf+strlen("txtfont="));
         if(strstr(buf,"capcolor=")==(char *)buf)
            sprintf(capcolor,"%s",buf+strlen("capcolor="));
         if(strstr(buf,"capfont=")==(char *)buf)
            sprintf(capfont,"%s",buf+strlen("capfont="));
         if(strstr(buf,"icon ")==(char *)buf){
            XpmReadFileToPixmap(dpy, Root, buf+strlen("icon "), &icons[nicons], NULL, &pixatt);
            nicons++;
         }
         if(strstr(buf,"mountname ")==(char *)buf){
            mpoint[mpoints]=(MPInfo *)malloc(sizeof(MPInfo));
            sprintf(mpoint[mpoints]->name,"%s",buf+strlen("mountname "));
            fscanf(rcfile," mountpoint %s",mpoint[mpoints]->mpoint);
            fscanf(rcfile," iconnumber %i",&mpoint[mpoints]->icon);
            fscanf(rcfile," showcapacity %s",buf);
            mpoint[mpoints]->shwcap=(strcasecmp(buf,"true")==0);
            mpoints++;
         }
      }
   }  while(done==0);
   fclose(rcfile);
}

void checkMount(bool forced){
   int nmounted=FALSE;
   int ncap;

   dev_t prvdev;
   dev_t dirdev;
   if(strcmp(mpoint[curmnt]->mpoint,"/")==0)
      nmounted=TRUE;    // I think I can assume that / is mounted.
   else{
      // Check that the directory above the mount point is on a different device.
      struct stat st;
      char *mpstr=(char *)malloc(sizeof(char)*strlen(mpoint[curmnt]->mpoint));
      strcpy(mpstr,mpoint[curmnt]->mpoint);
      stat(mpstr,&st);
      dirdev=st.st_dev;
      *strrchr(mpstr,'/')='\0';
      stat(mpstr,&st);
      prvdev=st.st_dev;
      if(prvdev!=dirdev)
         nmounted=TRUE;
      free(mpstr);
   }
   if(nmounted && mpoint[curmnt]->shwcap){     // If we dont want it, don't waste time getting it.
      struct statfs sfs;
      statfs(mpoint[curmnt]->mpoint,&sfs);
      ncap=(int)((sfs.f_blocks-sfs.f_bfree)*100.0/(sfs.f_blocks-sfs.f_bfree+sfs.f_bavail)+.5);
   }

   if(nmounted)
      btnstate|=btnMnt;
   else
      btnstate&=~btnMnt;

   if((nmounted!=cmounted) || (nmounted && ncap!=ccap && mpoint[curmnt]->shwcap) || forced){
      if(nmounted!=cmounted || forced){
         cmounted=nmounted;
         drawBtns(btnMnt);
         if(mpoint[curmnt]->shwcap || forced){
            ccap=ncap;
            update();
         }
      }
      else{
         if(nmounted && ncap!=ccap && mpoint[curmnt]->shwcap){
            ccap=ncap;
            update();
         }
      }
      repaint();
   }
}

void pressEvent(XButtonEvent *xev){
   int x=xev->x;
   int y=xev->y;
   char cmd[256];
   if(x>=46 && y>=47 && x<=58 && y<=57){
      curmnt++;
      if(curmnt>=mpoints)
         curmnt=0;
      btnstate|=btnNext;
      btntimer=0;
      drawBtns(btnNext);
      checkMount(TRUE);          // forced because of changed mount point
      return;
   }
   if(x>=33 && y>=47 && x<=45 && y<=57){
      curmnt--;
      if(curmnt<0)
         curmnt=mpoints-1;
      btnstate|=btnPrev;
      btntimer=0;
      drawBtns(btnPrev);
      checkMount(TRUE);          // forced because of changed mount point
      return;
   }
   if(x>=5 && y>=47 && x<=32 && y<=57){
      if(cmounted)
         sprintf(cmd,umountcmd,mpoint[curmnt]->mpoint);
      else
         sprintf(cmd,mountcmd,mpoint[curmnt]->mpoint);
      newSystem(cmd);
      return;
   }
   if(x>=4 && y>=12 && x<=59 && y<=42){
      if(cmounted){
         // First or second click of double-click?
         if(dtimer>0){
            sprintf(cmd,opencmd,mpoint[curmnt]->mpoint);
            newSystem(cmd);
            dtimer=0;
         }
         else
            dtimer=dclick;
      }
   }
}

void releaseEvent(XButtonEvent *xev){
   btnstate&=~(btnPrev | btnNext);
   drawBtns(btnPrev | btnNext);
   repaint();
}

void repaint(){
   XCopyArea(dpy, disp, Win[activeWin], WinGC, 0, 0, 64, 64, 0, 0);
   XEvent xev;
   while(XCheckTypedEvent(dpy, Expose, &xev));
}

void update(){
   // Needs to be called if the current mountpoint or capacity change

   // Copy part of background
   XCopyArea(dpy, back, disp, WinGC, 4,4,56,39,4,4);

   // Copy icon
   XCopyArea(dpy, icons[mpoint[curmnt]->icon], disp, WinGC, 0,0,32,10,25,30);

   // Draw capacity text
   char capstr[20];
   if(cmounted && mpoint[curmnt]->shwcap){
      sprintf(capstr,"%d%%",ccap);
      XSetFont(dpy, WinGC, gcf2);
      XSetForeground(dpy, WinGC, gcc2);
      XDrawString(dpy, disp, WinGC, txtx2, txty2, (char *)capstr, strlen(capstr));
   }

   // Draw mountpoint name text
   XSetFont(dpy, WinGC, gcf1);
   XSetForeground(dpy, WinGC, gcc1);
   XDrawString(dpy, disp, WinGC, txtx1, txty1, (char *)mpoint[curmnt]->name, strlen(mpoint[curmnt]->name));
}

void drawBtns(int btns){
   if(btns & btnPrev)
      drawBtn(33,47,13,11,(btnstate & btnPrev));
   if(btns & btnNext)
      drawBtn(46,47,13,11,(btnstate & btnNext));
   if(btns & btnMnt)
      drawBtn(5,47,28,11,(btnstate & btnMnt));
}

void drawBtn(int x, int y, int w, int h, bool down){
   if(!down)
      XCopyArea(dpy, back, disp, WinGC, x,y,w,h,x,y);
   else{
      XCopyArea(dpy, back, disp, WinGC, x,y,1,h-1,x+w-1,y+1);
      XCopyArea(dpy, back, disp, WinGC, x+w-1,y+1,1,h-1,x,y);
      XCopyArea(dpy, back, disp, WinGC, x,y,w-1,1,x+1,y+h-1);
      XCopyArea(dpy, back, disp, WinGC, x+1,y+h-1,w-1,1,x,y);
   }
}

void newSystem(char *command){
   // I am told that using system(3) is bad programming so I use this instead.
   // I also notice system(3) does odd things to footprint of wmmount in memory.

   int pid=fork();
   int status;
   if(pid==0){
      char *argv[4]={"sh","-c",command,0};
      execv("/bin/sh", argv);
      exit(127);
   }
   do{
      if(waitpid(pid,&status,0)!=-1)
         return;
   } while(1);
}
