/*
 * Copyright (C) 1996 Frank Fejes
 * Copyright (C) 1994 Robert Nation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define TRUE 1
#define FALSE

#include "../../configure.h"
#ifdef ISC
#include <sys/bsdtypes.h>	/* Saul */
#endif

#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>
#if defined ___AIX || defined _AIX || defined __QNX__ || defined ___AIXV3 || defined AIXV3 || defined _SEQUENT_
#include <sys/select.h>
#endif
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>

#define MODULE_X_INTERFACE

#include "../../configure.h"
#include "../../include/aftersteplib.h"
#include "../../include/afterstep.h"
#include "../../include/style.h"
#include "../../include/screen.h"
#include "../../include/module.h"

static int fd_width;
static int fd[2];
static int x_fd;
static int timeout, t_secs, t_usecs;
char *MyName = NULL;
Display *dpy;			/* which display are we talking to */
int screen;
ScreenInfo Scr;

/* masks for AS pipe */
#define mask_reg M_FOCUS_CHANGE

/*************************************************************************
 *
 * Subroutine Prototypes
 * 
 *************************************************************************/
void Loop (int *fd);
void DeadPipe (int nonsense);

void 
usage (void)
{
  printf ("Usage:\n"
	  "%s [--version] [--help] delay\n", MyName);
  exit (0);
}

/* error_handler:
 * catch X errors, display the message and continue running.
 */
int 
error_handler (Display * disp, XErrorEvent * event)
{
  fprintf (stderr, "%s: internal error, error code %d, request code %d, minor code %d.\n",
	 MyName, event->error_code, event->request_code, event->minor_code);
  return 0;
}

/***********************************************************************
 *
 *  Procedure:
 *	main - start of module
 *
 ***********************************************************************/
int
main (int argc, char **argv)
{
  int i;
  char *display_name = NULL;

  /* Save our program name - for error messages */
  SetMyName (argv[0]);

  i = ProcessModuleArgs (argc, argv, NULL, NULL, NULL, usage);

  /* And now find the argument - delay */
  if (i == (argc - 1))
    {
      if (strncmp (argv[i], "-", 1))
	timeout = atoi (argv[i]);
      else
	usage ();
    }
  else
    usage ();

  t_secs = timeout / 1000;
  t_usecs = (timeout - t_secs * 1000) * 1000;

  /* Dead pipes mean afterstep died */
  signal (SIGPIPE, DeadPipe);
  signal (SIGQUIT, DeadPipe);
  signal (SIGSEGV, DeadPipe);
  signal (SIGTERM, DeadPipe);

  x_fd = ConnectX (&Scr, display_name, PropertyChangeMask);
  XSetErrorHandler (error_handler);

  /* connect to AfterStep */
  fd_width = GetFdWidth ();
  fd[0] = fd[1] = ConnectAfterStep (mask_reg);

  Loop (fd);

  return 0;
}


/***********************************************************************
 *
 *  Procedure:
 *	Loop - wait for data to process
 *
 ***********************************************************************/
unsigned long focus_win = 0;

void
Loop (int *fd)
{
  int Raised = 0;
  ASMessage *asmsg = NULL;

  while (1)
    {
      /* read a packet */
      asmsg = CheckASMessageFine (fd[1], t_secs, t_usecs);
      if (asmsg)
	{
	  if (asmsg->header[1] == M_FOCUS_CHANGE)
	    {
	      focus_win = asmsg->body[0];
	      if (focus_win != 0)
		{
		  Raised = 0;
		  if (timeout == 0)
		    {
		      SendInfo (fd, "Raise", focus_win);
		      Raised = 1;
		    }
		}
	    }
	  DestroyASMessage (asmsg);
	}
      else
	{
	  /* Raise the current focus window */
	  if (focus_win != 0)
	    {
	      Raised = 1;
	      SendInfo (fd, "Raise", focus_win);
	    }
	}
    }
}



/***********************************************************************
 *
 *  Procedure:
 *	SIGPIPE handler - SIGPIPE means afterstep is dying
 *
 ***********************************************************************/
void
DeadPipe (int nonsense)
{
  exit (0);
}
