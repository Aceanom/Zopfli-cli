/***********************************************************************
 *
 * afterstep per-screen data include file
 *
 ***********************************************************************/

#ifndef _SCREEN_
#define _SCREEN_

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include "misc.h"
#include "menus.h"

#define SIZE_HINDENT 5
#define SIZE_VINDENT 3
#define MAX_WINDOW_WIDTH 32767
#define MAX_WINDOW_HEIGHT 32767


/* Cursor types */
#define POSITION 0		/* upper Left corner cursor */
#define TITLE_CURSOR 1		/* title-bar cursor */
#define DEFAULT 2		/* cursor for apps to inherit */
#define SYS 3			/* sys-menu and iconify boxes cursor */
#define MOVE 4			/* resize cursor */
#if defined(__alpha)		/* Do you honnestly think people will even */
#ifdef WAIT			/* have to wait on alphas :-) */
#undef WAIT
#endif
#endif
#define WAIT 5			/* wait a while cursor */
#define MENU 6			/* menu cursor */
#define SELECT 7		/* dot cursor for f.move, etc. from menus */
#define DESTROY 8		/* skull and cross bones, f.destroy */
#define TOP 9
#define RIGHT 10
#define BOTTOM 11
#define LEFT 12
#define TOP_LEFT 13
#define TOP_RIGHT 14
#define BOTTOM_LEFT 15
#define BOTTOM_RIGHT 16
#define MAX_CURSORS 18

/* Maximum number of icon boxes that are allowed */
#define MAX_BOXES 4

/* button styles */
#define XPM_BUTTON_STYLE	2

/* title bar text alignment  */
#define JUSTIFY_CENTER 0
#define JUSTIFY_LEFT   1
#define JUSTIFY_RIGHT  2

#ifndef NO_VIRTUAL
typedef struct {
    Window win;
    int isMapped;
} PanFrame;

#endif

typedef struct ScreenInfo {

    unsigned long screen;
    int d_depth;		/* copy of DefaultDepth(dpy, screen) */
    int NumberOfScreens;	/* number of screens on display */
    int MyDisplayWidth;		/* my copy of DisplayWidth(dpy, screen) */
    int MyDisplayHeight;	/* my copy of DisplayHeight(dpy, screen) */

    ASWindow ASRoot;		/* the head of the afterstep window list */
    Window Root;		/* the root window */
    Window SizeWindow;		/* the resize dimensions window */
    Window NoFocusWin;		/* Window which will own focus when no other
				 * windows have it */
#ifndef NO_VIRTUAL
    PanFrame PanFrameTop, PanFrameLeft, PanFrameRight, PanFrameBottom;
    int usePanFrames;		/* toggle to disable them */
#endif

    Pixmap gray_bitmap;		/*dark gray pattern for shaded out menu items */
    Pixmap gray_pixmap;		/* dark gray pattern for inactive borders */
    Pixmap light_gray_pixmap;	/* light gray pattern for inactive borders */
    Pixmap sticky_gray_pixmap;	/* light gray pattern for sticky borders */

    MouseButton *MouseButtonRoot;
    FuncKey FuncKeyRoot;

    int root_pushes;		/* current push level to install root
				   colormap windows */
    ASWindow *pushed_window;	/* saved window to install when pushes drops
				   to zero */
    Cursor ASCursors[MAX_CURSORS];

    name_list *TheList;		/* list of window names with attributes */
    char *DefaultIcon;		/* Icon to use when no other icons are found */

    ColorPair MTitleColors;
    ColorPair MenuColors;
    ColorPair MenuHiColors;
    ColorPair MenuStippleColors;
    ColorPair MenuRelief;

    ColorPair StdColors;	/* standard fore/back colors */
    ColorPair StickyColors;	/* sticky fore/back colors */
    ColorPair StickyRelief;	/* sticky hilight colors */
    ColorPair HiColors;		/* standard fore/back colors */
    ColorPair StdRelief;
    ColorPair HiRelief;
    MyFont StdFont;		/* font structure */
    MyFont WindowFont;		/* font structure for window titles */
    MyFont IconFont;		/* for icon labels */

    GC IconGC;
    GC NormalGC;		/* normal GC for menus, pager, resize window */
    GC StippleGC;		/* normal GC for menus, pager, resize window */
    GC DrawGC;			/* GC to draw lines for move and resize */
    GC LineGC;			/* GC to draw lines on buttons */
    GC MaskGC;
    GC HiReliefGC;		/* GC for highlighted window relief */
    GC HiShadowGC;		/* GC for highlighted window shadow */
    GC BevelReliefGC;
    GC BevelShadowGC;
    GC MenuGC;
    GC MenuStippleGC;
    GC MenuReliefGC;
    GC MenuShadowGC;
    GC StdReliefGC;		/* GC for unselected window relief */
    GC StdShadowGC;		/* GC for unselected window shadow */
    GC ScratchGC1;
    GC ScratchGC2;

    GC StickyReliefGC;		/* GC for unselected sticky window relief */
    GC StickyShadowGC;		/* GC for unselected sticky window shadow */
    GC FontGC;			/* GC for non-standard fonts */
    GC HiFontReliefGC;
    GC HiFontShadowGC;
    GC HiFontGC;
    GC LoFontGC;
    GC LoFontShadowGC;
    GC LoFontReliefGC;
    int TitleTextType;
    int TitleTextY;

    int SizeStringWidth;	/* minimum width of size window */
    int CornerWidth;		/* corner width for decoratedwindows */
    int BoundaryWidth;		/* frame width for decorated windows */
    int NoBoundaryWidth;	/* frame width for decorated windows */
    int TitleHeight;		/* height of the title bar window */
    int TitleTextAlign;		/* alignment of title bar text */
#ifndef NO_TEXTURE
    int TitleStyle;		/* old or new titlebar style */
    Pixmap BackTitle;		/* Cached titlebars for gradient or tiling */
    Pixmap ForeTitle;		/* types 2 and 3. unfocused, focused */
    Pixmap StickyTitle;		/* and sticky */
  Pixmap MenuTitle;
  Pixmap MenuTitleMask;
  Pixmap MenuArrow;
  Pixmap MenuArrowMask;
  Pixmap MenuItem;
  Pixmap MenuItemHilite;
    Pixmap TitleGradient;	/* gradient for the focused title text */
#endif
    long next_focus_sequence;	/* keep track of previously focused windows */
    ASWindow *Hilite;		/* the afterstep window that is highlighted 
				 * except for networking delays, this is the
				 * window which REALLY has the focus */
    ASWindow *Focus;		/* Last window which AS gave the focus to 
				   * NOT the window that really has the focus */
    ASWindow *Ungrabbed;
    ASWindow *PreviousFocus;	/* Window which had focus before afterstep stole it
				   * to do moves/menus/etc. */
    int EntryHeight;		/* menu entry height */
    int EdgeScrollX;		/* #pixels to scroll on screen edge */
    int EdgeScrollY;		/* #pixels to scroll on screen edge */
    unsigned int nonlock_mods;	/* a mask for non-locking modifiers */
    unsigned int *lock_mods;	/* all combinations of lock modifier masks */
    unsigned char buttons2grab;	/* buttons to grab in click to focus mode */
    unsigned long flags;
    int IconBoxes[MAX_BOXES][4];
    int NumBoxes;
    int randomx;		/* values used for randomPlacement */
    int randomy;
    unsigned VScale;		/* Panner scale factor */

    int VxMax;			/* Max location for top left of virt desk */
    int VyMax;
    int Vx;			/* Current loc for top left of virt desk */
    int Vy;

    int nr_left_buttons;	/* number of left-side title-bar buttons */
    int nr_right_buttons;	/* number of right-side title-bar buttons */

    int ClickTime;		/* Max buttonclickdelay for Function built-in */
    int AutoRaiseDelay;		/* Delay between setting focus and raisingwin */
    int ScrollResistance;	/* resistance to scrolling in desktop */
    int MoveResistance;		/* res to moving windows over viewport edge */
    int OpaqueSize;
    int CurrentDesk;		/* The current desktop number */
    MenuRoot *InitFunction;
    MenuRoot *RestartFunction;
    MenuRoot* first_menu;	/* head of the menu root list */

    int ButtonType;
    int button_style[10];
    Pixmap button_pixmap[10];
    Pixmap button_pixmap_mask[10];
    Pixmap dbutton_pixmap[10];
    Pixmap dbutton_pixmap_mask[10];
    int button_width[10];
    int button_height[10];

    Pixmap IconBgPixmap;	/* Iconized button background */
    Pixmap IconBgMask;
    int IconBgWidth;
    int IconBgHeight;
    int IconBgDepth;

    int RaiseButtons;		/* The buttons to do click-to-raise */
} ScreenInfo;

extern ScreenInfo Scr;

/* for the flags value - these used to be seperate Bool's */
#define ClickToFocus               (1)	/* Focus follows mouse, or click to focus? */
#define DecorateTransients         (2)	/* decorate transient windows? */
#define DontMoveOff                (4)	/* make sure all windows stay on desktop */
#define RandomPlacement            (8)	/* place windows in random locations? */
#define SuppressIcons             (16)	/* prevent generation of icon windows */
#define StickyIcons               (32)	/* Icons always sticky? */
#define EdgeWrapX                 (64)	/* Should EdgeScroll wrap around? */
#define EdgeWrapY                (128)
#define CenterOnCirculate        (256)	/* center window when circulating? */
#define KeepIconWindows		 (512)
#define ClickToRaise		(1024)
#define EatFocusClick		(2048)
/*
   #define MWMDecorHints           (4096)
 */
#define MenusHigh		(4096)
#define NoPPosition             (8192)
#define SMART_PLACEMENT        (16384)
#define CirculateSkipIcons     (32768)
#define StubbornIcons          (65536)
#define StubbornPlacement     (131072)
#define StubbornIconPlacement (262144)
#define OpaqueResize          (524288)
/*
   #define MWMFunctionHints     (1048576)
   #define MWMHintOverride      (2097152)
 */
#define BackingStore         (4194304)
#define AppsBackingStore     (8388608)
#define SaveUnders          (16777216)
#define SloppyFocus         (33554432)
#define IconTitle		(1<<27)
#endif				/* _SCREEN_ */
