 /*
  * Extended version of struct dirent
  */

#include <sys/types.h>
#include <dirent.h>
struct direntry {
     mode_t d_mode; /* S_IFDIR if a directory */
     time_t d_mtime;
     char   d_name[1];
};

typedef int(*my_sort_f)(struct direntry **d1, struct direntry **d2);
extern my_sort_f my_sort_list[5];

int mystrcasecmp(char *, char *);
int mystrncasecmp(char *, char *,int);
char *CatString3(char *, char *, char *);
int mygethostname(char *, int);
void SendText(int *,char *,unsigned long);
void SendInfo(int *,char *,unsigned long);
char* safemalloc(int);
char *findIconFile(char *, char *, int);
int ReadASPacket(int , unsigned long *, unsigned long **);
void CopyString(char **, char *);
void sleep_a_little(int);
int GetFdWidth(void);
int CheckFile(char *);
int CheckDir(char *);
char *CheckOrShare (char *, char *, char *, int);
char *PutHome (char []);
int HomeCreate (char *);
void CheckOrCreate (char *);
void CheckOrCreateFile (char *);
int my_scandir(char *, struct direntry *(*[]), int (*select)(struct dirent *),
             int (*dcomp)(struct direntry **, struct direntry **));
int my_sort(struct direntry **, struct direntry **);
int my_dirsort(struct direntry **, struct direntry **);
int my_alphasort(struct direntry **, struct direntry **);
int my_datesort(struct direntry **, struct direntry **);
int ignore_dots(struct dirent *);

/*#define DEBUG_ALLOCS*/
#ifdef DEBUG_ALLOCS
#define safemalloc(a) countmalloc(__FUNCTION__, __LINE__, a)
#define realloc(a, b) countrealloc(__FUNCTION__, __LINE__, a, b)
#define free(a) countfree(__FUNCTION__, __LINE__, a)
void* countmalloc(char* fname, int line, int length);
void* countrealloc(char* fname, int line, void* ptr, int length);
void countfree(char* fname, int line, void* ptr);
void print_unfreed_mem(void);
#endif /*DEBUG_ALLOCS*/
