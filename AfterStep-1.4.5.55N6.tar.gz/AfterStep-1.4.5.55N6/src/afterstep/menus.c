/****************************************************************************
 * This module is based on Twm, but has been SIGNIFICANTLY modified 
 * by Rob Nation 
 * by Bo Yang
 * by Frank Fejes
 * by Alfredo Kojima
 * by Guylhem Aznar
 ****************************************************************************/

/*****************************************************************************/
/**       Copyright 1988 by Evans & Sutherland Computer Corporation,        **/
/**                          Salt Lake City, Utah                           **/
/**  Portions Copyright 1989 by the Massachusetts Institute of Technology   **/
/**                        Cambridge, Massachusetts                         **/
/**                                                                         **/
/**                           All Rights Reserved                           **/
/**                                                                         **/
/**    Permission to use, copy, modify, and distribute this software and    **/
/**    its documentation  for  any  purpose  and  without  fee is hereby    **/
/**    granted, provided that the above copyright notice appear  in  all    **/
/**    copies and that both  that  copyright  notice  and  this  permis-    **/
/**    sion  notice appear in supporting  documentation,  and  that  the    **/
/**    names of Evans & Sutherland and M.I.T. not be used in advertising    **/
/**    in publicity pertaining to distribution of the  software  without    **/
/**    specific, written prior permission.                                  **/
/**                                                                         **/
/**    EVANS & SUTHERLAND AND M.I.T. DISCLAIM ALL WARRANTIES WITH REGARD    **/
/**    TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES  OF  MERCHANT-    **/
/**    ABILITY  AND  FITNESS,  IN  NO  EVENT SHALL EVANS & SUTHERLAND OR    **/
/**    M.I.T. BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL  DAM-    **/
/**    AGES OR  ANY DAMAGES WHATSOEVER  RESULTING FROM LOSS OF USE, DATA    **/
/**    OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER    **/
/**    TORTIOUS ACTION, ARISING OUT OF OR IN  CONNECTION  WITH  THE  USE    **/
/**    OR PERFORMANCE OF THIS SOFTWARE.                                     **/
/*****************************************************************************/

/***********************************************************************
 *
 * afterstep menu code
 *
 ***********************************************************************/
#include "../../include/configure.h"

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>
#include <X11/keysym.h>

#include "../../include/afterstep.h"
#include "../../include/menus.h"
#include "../../include/misc.h"
#include "../../include/parse.h"
#include "../../include/screen.h"
#ifndef NO_TEXTURE
#include "../../include/stepgfx.h"
#endif

#ifndef NO_SHAPE
#include <X11/extensions/shape.h>
#endif                          /* ! NO_SHAPE */

Bool pin_menu(MenuRoot* menu);
Bool unpin_menu(MenuRoot* menu);
Bool map_menu(MenuRoot* menu);
Bool unmap_menu(MenuRoot* menu);
Bool configure_menu(MenuRoot* menu, MenuRoot* parent);
void select_item(MenuRoot* menu, MenuItem* item);
void unselect_item(MenuRoot* menu, MenuItem* item);
void do_menu_move_or_close(MenuRoot* menu, int buttonx, int buttony);

#ifdef DEBUG_MENUS
void test_menu_integrity(char* fname);
Bool test_item_list(MenuRoot* menu);
Bool test_item_integrity(MenuItem* item);
#endif /*DEBUG_MENUS*/

Bool IgnoreRelease = 1;
int BottomOfPage = 0;

int menuFromFrameOrWindowOrTitlebar = FALSE;

extern int Context, Button;
extern ASWindow *ButtonWindow, *Tmp_win;
extern XEvent Event;
extern int DrawMenuBorders;
extern int TextureMenuItemsIndividually;

int Stashed_X, Stashed_Y;
Bool menu_has_pointer = False;
/* if menu_has_pointer is true, this is the menu that grabbed */
MenuRoot* pointer_menu = NULL;

void DrawTrianglePattern(Window, GC, GC, GC, int, int, int, int);
void DrawSeparator(Window, GC, GC, int, int, int, int, int);
void DrawUnderline(Window w, GC gc, int x, int y, char *txt, int off);

extern XContext MenuContext;

Bool debug_menus = False;

/****************************************************************************
 *
 * Initiates a menu pop-up
 *
 ***************************************************************************/
int do_menu(MenuRoot* menu, MenuRoot* parent)
{
/**/if (debug_menus) printf("%s:%s\n", __FUNCTION__, (*menu).name);
configure_menu(menu, parent);
map_menu(menu);
}

/****************************************************************************
 *
 * positions a menu, and sets up the colors/pixmaps if necessary
 * use the parent's position to place the menu
 * if parent == NULL, use the current pointer position
 *
 ***************************************************************************/
Bool configure_menu(MenuRoot* menu, MenuRoot* parent)
{
    int x, y;
    int title_height, item_height, width;
    XGCValues gcv;
    GC gc;

    /* In case we wind up with a move from a menu which is
     * from a window border, we'll return to here to start
     * the move */
    XQueryPointer(dpy, Scr.Root, &JunkRoot, &JunkChild,
		  &x, &y, &JunkX, &JunkY, &JunkMask);
    if (parent == NULL) {
	Stashed_X = x;
	Stashed_Y = y;
	}

    if (parent != NULL) {
	MenuItem* item;
	/* find our entry in our parent menu */
	for (item = (*parent).first; item != NULL; item = item->next)
	    if ((*item).menu == menu)
		break;
	/* Offset the new menu depending on the geometry of its parent menu */
	if (item != NULL) {
	    int junk;
	    x = (*parent).x + (*parent).width;
	    y = (*parent).y;
	    if (!(Scr.flags & MenusHigh))
		y += -menu->first->y_height + item->y_offset;
	} else
	    printf("%s:menu not found\n", __FUNCTION__);
    } else {
        /* save the window we were called from */
        (*menu).aw = ButtonWindow;
	x -= (menu->width >> 1);
	y -= (menu->first->y_height >> 1);
    }

    if (BottomOfPage != 1) {
	if ((Tmp_win) && (Context & C_LALL)) {
	    y = Tmp_win->frame_y + Tmp_win->boundary_width + Tmp_win->title_height + 1;
	    x = Tmp_win->frame_x + Tmp_win->boundary_width +
		Button * Tmp_win->title_height + 1;
	}
	if ((Tmp_win) && (Context & C_RALL)) {
	    y = Tmp_win->frame_y + Tmp_win->boundary_width + Tmp_win->title_height + 1;
	    x = Tmp_win->frame_x + Tmp_win->frame_width - Tmp_win->boundary_width -
		Button * Tmp_win->title_height - menu->width + 1;
	}
	if ((Tmp_win) && (Context & C_TITLE)) {
	    y = Tmp_win->frame_y + Tmp_win->boundary_width + Tmp_win->title_height + 1;
	    if (x < Tmp_win->frame_x + Tmp_win->title_x)
		x = Tmp_win->frame_x + Tmp_win->title_x;
	    if ((x + menu->width) >
	    (Tmp_win->frame_x + Tmp_win->title_x + Tmp_win->title_width))
		x = Tmp_win->frame_x + Tmp_win->title_x + Tmp_win->title_width -
		    menu->width + 1;
	}
	/* clip to screen */
	if (x + menu->width > Scr.MyDisplayWidth - 2)
	    x = Scr.MyDisplayWidth - menu->width - 2;
	if (x < 0)
	    x = 0;

	if (y + menu->height > Scr.MyDisplayHeight - 2) {
	    BottomOfPage = 1;
	    y = Scr.MyDisplayHeight - menu->height - 2;
	    /* Warp pointer to middle of top line */

#ifndef NO_WARP_POINTER_TO_MENU
	    XWarpPointer(dpy, Scr.Root, Scr.Root, 0, 0, Scr.MyDisplayWidth,
			 Scr.MyDisplayHeight,
			 x + (menu->width >> 1), y + (Scr.EntryHeight >> 1));
#endif
	}
	if (y < 0)
	    y = 0;
    } else {
	y = (Scr.MyDisplayHeight - (menu->height + 2));
	if (y < 0)
	    y = 0;

	if (x + menu->width > Scr.MyDisplayWidth - 2)
	    x = Scr.MyDisplayWidth - menu->width - 2;
	if (x < 0)
	    x = 0;

    }
    (*menu).x = x;
    (*menu).y = y;

#ifndef NO_TEXTURE
    if (Scr.d_depth >= 8) {
	width = menu->width;
	title_height = menu->first->y_height;
	item_height = menu->last->y_height;
	if (TextureMenuItemsIndividually == 0)
	    item_height = menu->height - menu->first->y_offset - menu->first->y_height;
	if (DrawMenuBorders == 1) {
	    title_height -= 3;
	    item_height -= 3;
	    width -= 2;
	}
	if ((menu->titlebg == None) && (Textures.Mtype > 0)) {
	    menu->titlebg = XCreatePixmap(dpy, menu->w, width,
					  title_height,
					  Scr.d_depth);

	    switch (Textures.Mtype) {
	    case 1:		/* NW to SE gradient */
		if (!DrawDegradeRelief(dpy, menu->titlebg, 0, 0, width,
				       title_height,
				       Textures.Mfrom, Textures.Mto, 1,
				       Textures.Mmaxcols)) {
		    XFreePixmap(dpy, menu->titlebg);
		    menu->titlebg = None;
		}
		break;
	    case 2:		/* horizontal gradient */
	    case 3:		/* horiz. cylindrical */
		if (!DrawHGradient(dpy, menu->titlebg, 0, 0, width,
				   title_height,
				   Textures.Mfrom, Textures.Mto, 1,
				Textures.Mmaxcols, Textures.Mtype - 2)) {
		    XFreePixmap(dpy, menu->titlebg);
		    menu->titlebg = None;
		}
		break;
	    case 4:		/* vertical gradient */
	    case 5:		/* vert. cylindrical */
		if (!DrawVGradient(dpy, menu->titlebg, 0, 0, width,
				   title_height,
				   Textures.Mfrom, Textures.Mto, 1,
				Textures.Mmaxcols, Textures.Mtype - 4)) {
		    XFreePixmap(dpy, menu->titlebg);
		    menu->titlebg = None;
		}
		break;

	    case 128:		/* pixmap */
		gcv.fill_style = FillTiled;
		gcv.tile = Scr.MenuTitle;
		gc = XCreateGC(dpy, menu->titlebg, GCFillStyle | GCTile, &gcv);
		XFillRectangle(dpy, menu->titlebg, gc, 0, 0, width, title_height);
		XFreeGC(dpy, gc);
		break;

	    case 129:		/* transparent title BG */
		XSetWindowBackgroundPixmap(dpy, menu->w, 0);
		XFreePixmap(dpy, menu->titlebg);
		menu->titlebg = None;
		break;

	    default:
		XFreePixmap(dpy, menu->titlebg);
		menu->titlebg = None;
		afterstep_err("Invalid TextureType %i specified for menu title\n",
			      (char *) Textures.Mtype, NULL, NULL);
		Textures.Mtype = 0;
	    }
	}
/********************* Now let's work on menu items ***************************/


	if ((menu->itembg == None) && (Textures.Itype > 0) && (menu->last != NULL)) {
	    menu->itembg = XCreatePixmap(dpy, menu->w, width,
					 item_height,
					 Scr.d_depth);
	    switch (Textures.Itype) {
	    case 1:		/* NW to SE gradient */
		if (!DrawDegradeRelief(dpy, menu->itembg, 0, 0,
				       width, item_height,
				       Textures.Ifrom, Textures.Ito, 0,
				       Textures.Imaxcols)) {
		    XFreePixmap(dpy, menu->itembg);
		    menu->itembg = None;
		}
		break;
	    case 2:		/* horizontal gradient */
	    case 3:		/* horiz. cylindrical */
		if (!DrawHGradient(dpy, menu->itembg, 0, 0, width,
				   item_height,
				   Textures.Ifrom, Textures.Ito, 0,
				Textures.Imaxcols, Textures.Itype - 2)) {
		    XFreePixmap(dpy, menu->itembg);
		    menu->itembg = None;
		}
		break;
	    case 4:		/* vertical gradient */
	    case 5:		/* vert. cylindrical */
		if (!DrawVGradient(dpy, menu->itembg, 0, 0, width,
				   item_height,
				   Textures.Ifrom, Textures.Ito, 0,
				Textures.Imaxcols, Textures.Itype - 4)) {
		    XFreePixmap(dpy, menu->itembg);
		    menu->itembg = None;
		}
		break;

	    case 128:		/* pixmap */
		if (Textures.Mtype != 129) {
		    gcv.fill_style = FillTiled;
		    gcv.tile = Scr.MenuItem;
		    gc = XCreateGC(dpy, menu->itembg, GCFillStyle | GCTile, &gcv);
		    XFillRectangle(dpy, menu->itembg, gc, 0, 0, width, item_height);
		    XFreeGC(dpy, gc);
		} else {
		    XFreePixmap(dpy, menu->itembg);
		    menu->itembg = None;
		}
		break;

	    default:
		XFreePixmap(dpy, menu->itembg);
		menu->itembg = None;
		afterstep_err("Invalid TextureType %i specified for menu item\n",
			      (char *) Textures.Itype, NULL, NULL);
		Textures.Itype = 0;
	    }
	}
/****************** Now let's work on the menu item hilite ********************/

	if ((menu->itemhibg == None) && (Textures.Htype > 0) && (menu->last != NULL)) {
	    menu->itemhibg = XCreatePixmap(dpy, menu->w, width,
					 item_height, 
					 Scr.d_depth);
	    switch (Textures.Htype) {
	    case 1:		/* NW to SE gradient */
		if (!DrawDegradeRelief(dpy, menu->itemhibg, 0, 0,
				       width, item_height,
				       Textures.Hfrom, Textures.Hto, 0,
				       Textures.Hmaxcols)) {
		    XFreePixmap(dpy, menu->itemhibg);
		    menu->itemhibg = None;
		}
		break;
	    case 2:		/* horizontal gradient */
	    case 3:		/* horiz. cylindrical */
		if (!DrawHGradient(dpy, menu->itemhibg, 0, 0, width,
				   item_height,
				   Textures.Hfrom, Textures.Hto, 0,
				   Textures.Hmaxcols, Textures.Htype - 2)) {
		    XFreePixmap(dpy, menu->itemhibg);
		    menu->itemhibg = None;
		}
		break;
	    case 4:		/* vertical gradient */
	    case 5:		/* vert. cylindrical */
		if (!DrawVGradient(dpy, menu->itemhibg, 0, 0, width,
				   item_height,
				   Textures.Hfrom, Textures.Hto, 0,
				   Textures.Hmaxcols, Textures.Htype - 4)) {
		    XFreePixmap(dpy, menu->itemhibg);
		    menu->itemhibg = None;
		}
		break;

	    case 128:		/* pixmap */
		if (Textures.Mtype != 129) {
		    gcv.fill_style = FillTiled;
		    gcv.tile = Scr.MenuItemHilite;
		    gc = XCreateGC(dpy, menu->itemhibg, GCFillStyle | GCTile, &gcv);
		    XFillRectangle(dpy, menu->itemhibg, gc, 0, 0, width, item_height);
		    XFreeGC(dpy, gc);
		} else {
		    XFreePixmap(dpy, menu->itemhibg);
		    menu->itemhibg = None;
		}
		break;

	    default:
		XFreePixmap(dpy, menu->itemhibg);
		menu->itemhibg = None;
		afterstep_err("Invalid TextureType %i specified for menu item hilite\n",
			      (char *) Textures.Htype, NULL, NULL);
		Textures.Htype = 0;
	    }
	}
    }
#endif				/* ! NO_TEXTURE */
    if ((*menu).is_mapped == True)
	XMoveResizeWindow(dpy, (*menu).w, (*menu).x, (*menu).y, (*menu).width, (*menu).height);
    return True;
}

/***********************************************************************
 *
 *  Procedure:
 *	RelieveRectangle - add relief lines to a rectangular window
 *
 ***********************************************************************/
void RelieveRectangle(Window win, int x, int y, int w, int h, GC Hilite, GC Shadow)
{
    XDrawLine(dpy, win, Hilite, x, y, w + x - 1, y);
    XDrawLine(dpy, win, Hilite, x, y, x, h + y - 1);

    XDrawLine(dpy, win, Shadow, x, h + y - 1, w + x - 1, h + y - 1);
    XDrawLine(dpy, win, Shadow, w + x - 1, y, w + x - 1, h + y - 1);
}

/***********************************************************************
 *
 *  Procedure:
 *	RelieveHalfRectangle - add relief lines to the sides only of a
 *      rectangular window
 *
 ***********************************************************************/
void RelieveHalfRectangle(Window win, int x, int y, int w, int h,
			  GC Hilite, GC Shadow)
{
    XDrawLine(dpy, win, Hilite, x, y - 1, x, h + y);

/* �� */ XDrawLine(dpy, win, Hilite, x + 1, y, x + 1, h + y - 1);

    XDrawLine(dpy, win, Shadow, w + x - 1, y - 1, w + x - 1, h + y);
    XDrawLine(dpy, win, Shadow, w + x - 2, y, w + x - 2, h + y - 1);
}


/***********************************************************************
 *
 *  Procedure:
 *      PaintEntry - draws a single entry in a poped up menu
 *
 ***********************************************************************/
void PaintEntry(MenuRoot * mr, MenuItem * mi)
{
    int text_y, d;
    GC ShadowGC, ReliefGC, currentGC;
    char hk[2];
    /* 
     * get texture from
     * (0, bg_y_offset, width, y_height)
     *
     * put texture (or color) at
     * (x_offset, y_offset, width, y_height)
     */
    int x_offset, y_offset, width, y_height;
    Bool is_selected;
    ColorPair colors;
#ifndef NO_TEXTURE
    int bg_y_offset;
    Pixmap background;
#endif

    hk[1] = 0;
    width = mr->width;
    y_height = mi->y_height;
    x_offset = 0;
    y_offset = mi->y_offset;
    text_y = y_offset + Scr.StdFont.y;

    if (DrawMenuBorders == 1) {
	width -= 2;
	y_height -= 3;
	x_offset += 1;
	y_offset += 1;
    }
#ifndef NO_TEXTURE
    bg_y_offset = 0;
    if ((TextureMenuItemsIndividually == 0) && (mi->func != F_TITLE))
        bg_y_offset = mi->y_offset - mr->first->next->y_offset;
#endif
    if (mi->func == F_TITLE)
    	text_y += 4;

    is_selected = ((mi->is_hilited) && (mi->func != F_TITLE) && 
		*mi->item && check_allowed_function(mi)) 
		? True : False;

/* setup our colors */
    if (mi->func == F_TITLE)
    	colors = Scr.MTitleColors;
    else if (is_selected == True)
    	colors = Scr.MenuHiColors;
    else if (check_allowed_function(mi))
    	colors = Scr.MenuColors;
    /* should be a shaded out word, not just re-colored. */
    else
	colors = Scr.MenuStippleColors;

#ifndef NO_TEXTURE
/* setup our textures */
    if (mi->func == F_TITLE)
    	background = mr->titlebg;
    else if (is_selected == True)
    	background = mr->itemhibg;
    else
    	background = mr->itembg;
#endif

/* setup our GC */
    Globalgcv.foreground = colors.fore;
    Globalgcv.background = colors.back;
    if (mi->func == F_TITLE)
    	Globalgcv.font = Scr.WindowFont.font->fid;
    else
    	Globalgcv.font = Scr.StdFont.font->fid;
    Globalgcm = GCForeground | GCBackground | GCFont;
    XChangeGC(dpy, Scr.ScratchGC1, Globalgcm, &Globalgcv);
    currentGC = Scr.ScratchGC1;
    if (Textures.Mtype != 129)
	XSetWindowBackground(dpy, mr->w, colors.back);

    /* really should have separate GCs for the menu title */
    ShadowGC = Scr.MenuShadowGC;
    if (Scr.d_depth < 2)
	ReliefGC = Scr.MenuShadowGC;
    else
	ReliefGC = Scr.MenuReliefGC;

/* draw the background */
#ifndef NO_TEXTURE
    if (background != None) {
	XCopyArea(dpy, background, mr->w, DefaultGC(dpy, Scr.screen),
		  0, bg_y_offset, width, y_height, x_offset, y_offset);
    } else
#endif
    XClearArea(dpy, mr->w, x_offset, y_offset, width, y_height, False);
    
    if (mi->func != F_TITLE)
	text_y += HEIGHT_EXTRA >> 1;

/* draw the menu borders (the relief pattern) */
    if (DrawMenuBorders == 1) {
	RelieveRectangle(mr->w, 0, mi->y_offset, mr->width,
			mi->y_height, ReliefGC, ShadowGC);
	RelieveRectangle(mr->w, 0, mi->y_offset, mr->width, mi->y_height - 1,
			ReliefGC, ShadowGC);
	XDrawLine(dpy, mr->w, Scr.LineGC, 0, mi->y_offset + mi->y_height - 1,
			mr->width, mi->y_offset + mi->y_height - 1);
    }

/* draw the menu text */
    if (*mi->item)
	XDrawString(dpy, mr->w, currentGC, mi->x, text_y, mi->item, mi->strlen);
    else if ((mi->func == F_NOP) && (DrawMenuBorders != 1))
	DrawSeparator(mr->w, ReliefGC, ShadowGC, 
			x_offset, mi->y_offset, 
			x_offset + width, mi->y_offset, 0);
    if (mi->strlen2 > 0)
	XDrawString(dpy, mr->w, currentGC, mi->x2, text_y, mi->item2, mi->strlen2);

    d = (Scr.EntryHeight - 7) / 2;
    if (mi->func != F_POPUP && mi->hotkey != 0) {
	hk[0] = mi->hotkey;
	XDrawString(dpy, mr->w, currentGC,
	     mr->width - d - 4 - XTextWidth(Scr.StdFont.font, hk, 1) / 2,
		    text_y, hk, 1);
    }
    d = (Scr.EntryHeight - 7) / 2;
    if (mi->func == F_POPUP)
	DrawTrianglePattern(mr->w, ShadowGC, ReliefGC, ShadowGC, mr->width - d - 8,
		  mi->y_offset + d - 1, mr->width - d - 1, mi->y_offset + d + 7);

    return;
}

/****************************************************************************
 * Procedure:
 *	DrawUnderline() - Underline a character in a string (pete@tecc.co.uk)
 *
 * Calculate the pixel offsets to the start of the character position we
 * want to underline and to the next character in the string.  Shrink by
 * one pixel from each end and the draw a line that long two pixels below
 * the character...
 *
 ****************************************************************************/
void DrawUnderline(Window w, GC gc, int x, int y, char *txt, int posn)
{
    int off1 = XTextWidth(Scr.StdFont.font, txt, posn);
    int off2 = XTextWidth(Scr.StdFont.font, txt, posn + 1) - 1;

    XDrawLine(dpy, w, gc, x + off1, y + 2, x + off2, y + 2);
}

/****************************************************************************
 *
 *  Draws two horizontal lines to form a separator
 *
 ****************************************************************************/
void DrawSeparator(Window w, GC TopGC, GC BottomGC, int x1, int y1, int x2, int y2,
		   int extra_off)
{
    XDrawLine(dpy, w, TopGC, x1, y1, x2, y2);
    XDrawLine(dpy, w, BottomGC, x1 - extra_off, y1 + 1, x2 + extra_off, y2 + 1);
}

/****************************************************************************
 *
 *  Draws a little Triangle pattern within a window
 *
 ****************************************************************************/
void DrawTrianglePattern(Window w, GC GC1, GC GC2, GC GC3, int l, int u, int r, int b)
{
    int m;

    if (Scr.MenuArrow == None) {
	m = (u + b) / 2;

	XDrawLine(dpy, w, GC1, l, u, l, b);

	XDrawLine(dpy, w, GC2, l, b, r, m);
	XDrawLine(dpy, w, GC3, r, m, l, u);
    } else
	XCopyArea(dpy, Scr.MenuArrow, w, GC1, 0, 0, r - l, b - u, l, u);

}

/***********************************************************************
 *
 *  Procedure:
 *	PaintMenu - draws the entire menu
 *
 ***********************************************************************/
void PaintMenu(MenuRoot* mr, XEvent* e)
{
    MenuItem *mi;

    for (mi = mr->first; mi != NULL; mi = mi->next) {
	/* be smart about handling the expose, redraw only the entries
	 * that we need to
	 */
	if (e->xexpose.y < (mi->y_offset + mi->y_height) &&
	    (e->xexpose.y + e->xexpose.height) > mi->y_offset) {
	    PaintEntry(mr, mi);
	}
    }
    XSync(dpy, 0);
    return;
}

/***********************************************************************
 *
 *  finds the entry which the pointer is over
 *
 ***********************************************************************/
MenuItem* find_entry(MenuRoot* menu)
{
    MenuItem *mi;
    int x, y;

    XQueryPointer(dpy, (*menu).w, &JunkRoot, &JunkChild,
		  &JunkX, &JunkY, &x, &y, &JunkMask);

    /* look for the entry that the mouse is in */
    for (mi = (*menu).first; mi != NULL; mi = mi->next)
	if (y >= mi->y_offset && y < mi->y_offset + mi->y_height)
	    break;
    if ((x < 0) || (x >= (*menu).width))
	mi = NULL;

    return mi;
}

/***********************************************************************
 *
 *  Procedure:
 *	Updates menu display to reflect the highlighted item
 *
 ***********************************************************************/
int FindEntry(MenuRoot* menu)
{
    MenuItem* old_item;
    MenuItem* new_item;
    int retval = MENU_NOP;
    int x, y;

    /* find the hilited menu item (if any) */
    for (old_item = (*menu).first; old_item != NULL; old_item = old_item->next)
	if ((*old_item).is_hilited == True)
	    break;

    new_item = find_entry(menu);

    /* shouldn't need to do another XQueryPointer after find_entry */
    XQueryPointer(dpy, (*menu).w, &JunkRoot, &JunkChild,
		  &JunkX, &JunkY, &x, &y, &JunkMask);

    /* if we're not on the same item, change hilites */
    if (new_item != old_item)
	{
/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*menu).name);
	if (old_item != NULL)
	    unselect_item(menu, old_item);
	if (new_item != NULL)
	    select_item(menu, new_item);
	}

    if ((new_item != NULL) && 
        (new_item->func == F_POPUP) && 
        ((*menu).is_pinned == False) && 
        (x > ((*menu).width * 3 / 4))) {
	/* create a new sub-menu */
	if ((new_item->menu->is_mapped == False) || (new_item->menu->is_pinned == True)) {
	    configure_menu(new_item->menu, menu);
	    if (new_item->menu->is_mapped == False)
		map_menu(new_item->menu);
	    if (new_item->menu->is_pinned == True)
		unpin_menu(new_item->menu);
	}
    }
    return retval;
}

/***********************************************************************
 * Procedure
 * 	menuShortcuts() - Menu keyboard processing (pete@tecc.co.uk)
 *
 * Function called from UpdateMenu instead of Keyboard_Shortcuts()
 * when a KeyPress event is received.  If the key is alphanumeric,
 * then the menu is scanned for a matching hot key.  Otherwise if
 * it was the escape key then the menu processing is aborted.
 * If none of these conditions are true, then the default processing
 * routine is called.
 ***********************************************************************/
void menuShortcuts(MenuRoot* menu, XEvent* ev)
{
    MenuItem *mi;
    KeySym keysym = XLookupKeysym(&ev->xkey, 0);

    if ((*menu).is_pinned == False)
	pin_menu(menu);

    /* Try to match hot keys */
    if (1) {
	if (((keysym >= XK_a) && (keysym <= XK_z)) ||	/* Only consider alphabetic */
	    ((keysym >= XK_A) && (keysym <= XK_Z)) ||	/* Only consider alphabetic */
	    ((keysym >= XK_0) && (keysym <= XK_9))) {	/* ...or numeric keys     */
	    keysym = toupper(keysym);
	    /* Search menu for matching hotkey */
	    for (mi = (*menu).first; mi; mi = mi->next) {
		char key;
		if (mi->hotkey == 0)
		    continue;	/* Item has no hotkey   */
		key = mi->hotkey;

		if (keysym == key) {		/* Are they equal? */
		    select_item(menu, mi);	/* Yes: Make this the active item */
		    pin_menu(menu);
		    return;
		}
	    }
	}
    }
    switch (keysym) {		/* Other special keyboard handling */
    case XK_Escape:		/* Escape key pressed. Abort */
	unmap_menu(menu);
	break;

	/* Nothing special --- Allow other shortcuts (cursor movement)    */
    default:
	Keyboard_shortcuts(ev, ButtonRelease);
	break;
    }
}

/***********************************************************************
 *
 *  interactively moves a menu
 *  closes the menu if the menu is not moved
 *  buttonx and buttony are in local coords to the menu window
 *
 ***********************************************************************/
void do_menu_move_or_close(MenuRoot* menu, int buttonx, int buttony)
{
    ASWindow win;
    int x, y;

    /* fake an ASWindow, so moveLoop will be happy */
    win.frame = (*menu).w;
    win.w = None;
    win.bw = 0;
    win.flags = 0;
    XTranslateCoordinates(dpy, (*menu).w, Scr.Root, buttonx, buttony, &x, &y, &JunkChild);
    x = (*menu).x - x;
    y = (*menu).y - y;
    /* let our grab go, so we can change the grab cursor */
    if (menu_has_pointer == True)
	UngrabEm();
	GrabEm(MOVE);
    moveLoop(&win, x, y, (*menu).width, (*menu).height, &x, &y, True, False);
    /* grab the pointer back */
    UngrabEm();
    if (menu_has_pointer == True)
	GrabEm(MENU);
    if (((*menu).x == x) && ((*menu).y == y)) {
	unmap_menu(menu);
    } else {
	(*menu).x = x;
	(*menu).y = y;
	XMoveWindow(dpy, (*menu).w, (*menu).x, (*menu).y);
    }
}

/***********************************************************************
 *
 *  Procedure:
 *	Handles an X event in a menu
 *
 *  if menu == NULL, attempts to infer the menu from the event
 * 
 *  Returns:
 *      False if the event was not handled
 *      True if the event was handled
 *
 ***********************************************************************/
Bool HandleMenuEvent(MenuRoot *menu, XEvent* event)
{
    Bool done = False;
    MenuItem* item;
    int x, y;
    ASWindow* aswin;

    /* try to figure out where the event came from */
    if (menu == NULL)
	for (menu = Scr.first_menu ; menu != NULL ; menu = (*menu).next)
	    if ((*event).xany.window == (*menu).w)
		break;

    /* if there is a pointer grab and we got an event not in our window, 
     * report to the window that did the grab; this allows us to catch 
     * ButtonReleases outside the menu window
     */
    if ((menu == NULL) && (menu_has_pointer == True) && 
        ((*event).type == ButtonRelease))
	menu = pointer_menu;

    if (menu == NULL)
	return False;

    if ((*event).type == MotionNotify) {
	/* discard any extra motion events */
	while (XCheckTypedWindowEvent(dpy, (*menu).w, MotionNotify, event) == True);
    }

    XQueryPointer(dpy, Scr.Root, &JunkRoot, &JunkChild,
                  &JunkX, &JunkY, &x, &y, &JunkMask);
    if ((x >= (*menu).x) && (x < (*menu).x + (*menu).width)) {
        if (y < 2) {
            if ((*menu).y < 0) {
                y = (*menu).y + ((*menu).first->y_height - 2);
                if (y > 0)
                    y = 0;
                XMoveWindow(dpy, (*menu).w, (*menu).x, y);
                (*menu).y = y;
                FindEntry(menu);
                XSync(dpy, 0);
            }
        } else if (y > Scr.MyDisplayHeight - 3) {
            if ((*menu).y + (*menu).height > Scr.MyDisplayHeight - 2) {
                y = (*menu).y - ((*menu).first->y_height - 2);
                if (y + (*menu).height < Scr.MyDisplayHeight - 2)
                    y = (Scr.MyDisplayHeight - 2) - (*menu).height;
                XMoveWindow(dpy, (*menu).w, (*menu).x, y);
                (*menu).y = y;
                FindEntry(menu);
                XSync(dpy, 0);
            }
        }
    }

    if ((*event).type == KeyPress) {
	done = True;
/**/if (debug_menus) printf("%s:KeyPress:'%s'\n", __FUNCTION__, (*menu).name);
	/* Handle a limited number of key press events to allow mouseless
	 * operation */
	menuShortcuts(menu, event);
    }

    switch ((*event).type) {
	/* if the press was in the titlebar, start a move */
	/* else unpin the menu, and update the selection */
	case ButtonPress:
	    done = True;
/**/if (debug_menus) printf("%s:ButtonPress:'%s'\n", __FUNCTION__, (*menu).name);
	    item = find_entry(menu);
	    if ((item != NULL) && ((*item).func == F_TITLE)) {
		do_menu_move_or_close(menu, (*event).xbutton.x, (*event).xbutton.y);
	    } else {
		unpin_menu(menu);
		FindEntry(menu);
	    }
	    break;

	/* if the release was in the titlebar, pin the menu */
	/* else if the release was on an item, execute that item */
	/* in either case, unmap the pointer_menu */
	case ButtonRelease:
/**/if (debug_menus) printf("%s:ButtonRelease:'%s'\n", __FUNCTION__, (*menu).name);
	    done = True;
	    aswin = (*menu).aw;
	    item = find_entry(menu);
	    if ((item != NULL) && ((*item).is_hilited == True))
		unselect_item(menu, item);
	    if ((item != NULL) && (item->func == F_TITLE)) {
		if (pin_menu(menu) == False)
		    unmap_menu(menu);
	    } else
		unmap_menu(menu);
	    if (menu_has_pointer == True)
		unmap_menu(pointer_menu);
	    if (item && (item->func != F_NOP) && check_allowed_function(item)) {
		if (aswin != NULL) {
		    ExecuteFunction(item->func, item->action,
		                    aswin->frame,
		                    aswin, event, Context,
		                    item->val1, item->val2,
		                    item->val1_unit, item->val2_unit,
		                    item->menu, -1);
		} else {
		    ExecuteFunction(item->func, item->action,
		                    None, None, event,
		                    Context, item->val1,
		                    item->val2,
		                    item->val1_unit, item->val2_unit,
		                    item->menu, -1);
		}
	    }
	    break;

	/* ignore grab events */
	/* take the input focus */
	case EnterNotify:
	    done = True;
	    if ((*event).xcrossing.mode != NotifyNormal)
		break;
/**/if (debug_menus) printf("%s:EnterNotify:'%s'\n", __FUNCTION__, (*menu).name);
	    break;
	
	/* update the menu selection */
	case MotionNotify:
	    done = True;
	    FindEntry(menu);
	    break;

	/* ignore grab events */
	/* if the menu is pinned, unselect all items */
	/* else, unselect only if the selection is not a mapped, unpinned menu */
	case LeaveNotify:
	    done = True;
	    if ((*event).xcrossing.mode != NotifyNormal)
		break;
/**/if (debug_menus) printf("%s:LeaveNotify:'%s'\n", __FUNCTION__, (*menu).name);
	    if ((*menu).is_pinned == True) {
		for (item = (*menu).first ; item != NULL ; item = (*item).next)
		    if ((*item).is_hilited == True)
		        unselect_item(menu, item);
	    } else {
		for (item = (*menu).first ; item != NULL ; item = (*item).next)
		    if (((*item).is_hilited == True) &&
		        !(((*item).menu != NULL) && 
		          ((*(*item).menu).is_mapped == True) && 
		          ((*(*item).menu).is_pinned == False)))
		        unselect_item(menu, item);
	    }
	    break;

	case Expose:
	    PaintMenu(menu, event);
	    done = True;
	    break;

	default:
/**/if (debug_menus) printf("%s:Event %d ignored:'%s'\n", __FUNCTION__, (*event).type, (*menu).name);
	    break;
    }

if (debug_menus && (menu_has_pointer == True))
{ /* watch for major error condition */
    Window junk_win;
    int junk;
    unsigned int buttons;
    XQueryPointer(dpy, Scr.Root, &junk_win, &junk_win, &junk, &junk, &junk, &junk, &buttons);
    buttons &= Button1Mask | Button2Mask | Button3Mask | Button4Mask | Button5Mask;
if (!buttons)
{
/**/if (debug_menus) printf("%s:GRAB WITH NO BUTTONS!\n", __FUNCTION__);
XBell(dpy, 0);
}
}
    return done;
}


/*
 * select a menu item
 */
void select_item(MenuRoot* menu, MenuItem* item)
{
/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*item).item);
    (*item).is_hilited = True;
    if ((*menu).is_mapped == True)
	if ((*item).func != F_TITLE)
	    PaintEntry(menu, item);
}

/*
 * unselect a menu item
 *
 * an unselected item promises:
 *   all unpinned submenus of this item are unmapped
 */
void unselect_item(MenuRoot* menu, MenuItem* item)
{
/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*item).item);
    (*item).is_hilited = False;
    if ((*menu).is_mapped == True)
	if ((*item).func != F_TITLE)
	    PaintEntry(menu, item);
    if (((*item).menu != NULL) && ((*(*item).menu).is_pinned == False)) {
	if ((*(*item).menu).is_mapped == True)
	    unmap_menu((*item).menu);
    }
}

/*
 * unpin a menu
 *
 * an mapped, unpinned menu promises:
 *   there is a pointer grab
 *   a button was down, or a ButtonRelease waiting, when the menu was unpinned
 */
Bool unpin_menu(MenuRoot* menu)
{
    Window junk_win;
    int junk;
    unsigned int buttons;
    Bool success = False;
/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*menu).name);

    /* 
     * make sure there's a button down, else we could be left with 
     * a grab and no release!
     */
    XQueryPointer(dpy, Scr.Root, &junk_win, &junk_win, &junk, &junk, &junk, &junk, &buttons);
    buttons &= Button1Mask | Button2Mask | Button3Mask | Button4Mask | Button5Mask;
    if (buttons == 0) {
	XEvent e;
	/* we're still okay if there's a button release on the way */
	if (XCheckTypedWindowEvent(dpy, (*menu).w, ButtonRelease, &e) == True) {
	    buttons = 1;
	    XPutBackEvent(dpy, &e);
	}
    
    }
    if (((*menu).is_mapped == True) && (buttons != 0)) {
	success = True;
	if (menu_has_pointer == False)
	    if ((success = GrabEm(MENU)) == True) {
		menu_has_pointer = True;
		pointer_menu = menu;
	    }
	(*menu).is_pinned = !success;
    }

    return success;
}

/*
 * pin a menu
 *
 * a mapped, pinned menu promises:
 *   this menu is not transient
 *   this menu has not grabbed the pointer
 *   this menu has no mapped, unpinned submenus
 */
Bool pin_menu(MenuRoot* menu)
{
/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*menu).name);
    if (menu == pointer_menu) {
	UngrabEm();
	menu_has_pointer = False;
	pointer_menu = NULL;
	BottomOfPage = False;
    }
    if ((*menu).is_transient == True)
	return False;
    if ((*menu).is_mapped == False)
	return False;
    if ((*menu).is_pinned == False) {
	MenuItem* item;
	(*menu).is_pinned = True;
	for (item = (*menu).first ; item != NULL ; item = (*item).next)
	    if (((*item).menu != NULL) && 
		((*(*item).menu).is_mapped == True) && 
		((*(*item).menu).is_pinned == False))
		    unmap_menu((*item).menu);
    }

    return True;
}

/***********************************************************************
 *
 *  Procedure:
 *	map_menu - map a pull down menu
 *
 *  Inputs:
 *	menu	- the root pointer of the menu to pop up
 *
 ***********************************************************************/
Bool map_menu(MenuRoot* menu)
{
    int x = (*menu).x, y = (*menu).y;
    
/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*menu).name);
    InstallRootColormap();

    XMoveResizeWindow(dpy, (*menu).w, 
                      (*menu).x, (*menu).y, 
                      (*menu).width, (*menu).height);
    XMapRaised(dpy, (*menu).w);
    XSelectInput(dpy, menu->w,  EnterWindowMask | LeaveWindowMask | 
				KeyPressMask | KeyReleaseMask | 
				ButtonPressMask | ButtonReleaseMask | 
				ButtonMotionMask | PointerMotionMask | 
				ExposureMask);
    menu->is_mapped = True;

    if ((unpin_menu(menu) != True) && (pin_menu(menu) != True)) {
	unmap_menu(menu);
	return False;
	}
    XSetInputFocus(dpy, (*menu).w, RevertToParent, CurrentTime);

    return True;
}


/***********************************************************************
 *
 *  Procedure:
 *	unmap_menu - unhighlight the current menu selection and
 *		take down the open, unpinned submenus
 *
 ***********************************************************************/
Bool unmap_menu(MenuRoot* menu)
{
    MenuItem* item;
    
    (*menu).aw = NULL;

/**/if (debug_menus) printf("%s:'%s'\n", __FUNCTION__, (*menu).name);
    /* attempt to pin the menu, which removes any pointer grab */
    if (pointer_menu == menu)
	pin_menu(menu);

    /* close all mapped, unpinned children of this menu */
    for (item = (*menu).first ; item != NULL ; item = (*item).next)
    	if (((*item).menu != NULL) && 
    	    ((*(*item).menu).is_mapped == True) && 
    	    ((*(*item).menu).is_pinned == False))
    	    unmap_menu((*item).menu);
    
    /* turn off all items */
    for (item = (*menu).first ; item != NULL ; item = (*item).next)
	item->is_hilited = 0;

    XUnmapWindow(dpy, (*menu).w);

    UninstallRootColormap();
    XFlush(dpy);
    if (Context & (C_WINDOW | C_FRAME | C_TITLE | C_SIDEBAR))
	menuFromFrameOrWindowOrTitlebar = TRUE;
    else
	menuFromFrameOrWindowOrTitlebar = FALSE;
    (*menu).is_mapped = False;

    if ((*menu).is_transient == True) {
	DeleteMenuRoot(menu);
    }

    return True;
}

/***************************************************************************
 * 
 * Wait for all mouse buttons to be released 
 * This can ease some confusion on the part of the user sometimes 
 * 
 * Discard superflous button events during this wait period.
 *
 ***************************************************************************/
void WaitForButtonsUp()
{
    Bool AllUp = False;
    XEvent JunkEvent;
    unsigned int mask;

    while (!AllUp) {
	XAllowEvents(dpy, ReplayPointer, CurrentTime);
	XQueryPointer(dpy, Scr.Root, &JunkRoot, &JunkChild,
		      &JunkX, &JunkY, &JunkX, &JunkY, &mask);

	if ((mask &
	     (Button1Mask | Button2Mask | Button3Mask | Button4Mask | Button5Mask)) == 0)
	    AllUp = True;
    }
    XSync(dpy, 0);
    while (XCheckMaskEvent(dpy,
		  ButtonPressMask | ButtonReleaseMask | ButtonMotionMask,
			   &JunkEvent)) {
	StashEventTime(&JunkEvent);
	XAllowEvents(dpy, ReplayPointer, CurrentTime);
    }

}

#ifdef DEBUG_MENUS
Bool test_item_integrity(MenuItem* item)
{
MenuRoot* menu;
/* is our submenu in the root menu list? */
if ((*item).func == F_POPUP)
{
for (menu = Scr.first_menu ; menu != NULL ; menu = (*menu).next)
if (menu == (*item).menu)
break;
if (menu == NULL)
return False;
}

return True;
}

/* have to assume that the next links are correct... */
Bool test_item_list(MenuRoot* menu)
{
MenuItem* item;
MenuItem* i2;
int i;

/* do we have the right number of children? */
for (item = (*menu).first, i = 0 ; item != NULL ; i++, item = (*item).next);
if ((*menu).items != i)
return False;

/* are the prev links correct? */
for (item = (*menu).first, i2 = NULL ; item != NULL ; i2 = item, item = (*item).next)
if ((*item).prev != i2)
return False;

/* does last point to the last item? */
if ((*menu).last != i2)
return False;

/* are the items valid? */
for (item = (*menu).first ; item != NULL ; item = (*item).next)
if (test_item_integrity(item) == False)
return False;

return True;
}

/* make sure menu structures are valid */
void test_menu_integrity(char* fname)
{
MenuRoot* menu;
for (menu = Scr.first_menu ; menu != NULL ; menu = (*menu).next)
if (test_item_list(menu) == False)
{
printf("%s:menu integrity test failed\n", fname);
}
}
#endif /*DEBUG_MENUS*/
