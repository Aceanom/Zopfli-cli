/* Copyright: GNU GPL v2 */
/* Author: David Muse <dmuse@engr.latech.edu> 1997 */
/* Changes/Updates: Michal Vitecek <fuf@fuf.sh.cvut.cz> 1998 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Xlib.h>
#include <Intrinsic.h>
#include <IntrinsicP.h>
#include <xpm.h>
#include <extensions/shape.h>
#include <errno.h>		// for error reporting
#include <sys/types.h>
#ifndef SOLARIS
 #include <sys/vfs.h>		// for statfs()
#else
 #include <sys/statvfs.h>	// for solaris' statvfs()
#endif

#ifdef SIXTEENBIT
	#include "16bit/surreal.xpm"
	#include "16bit/purplestoneswirl.xpm"
#endif
#ifdef EIGHTBIT
	#include "8bit/surreal.xpm"
	#include "8bit/purplestoneswirl.xpm"
#endif

/**** defines ****/
#define 		MAX_FILESYSTEMS		24
#define 		MTAB_FILE		"/etc/mtab"
#define 		BUFF_SIZE		256
#define			DEFAULT_LIMIT		75

/**** type definitions ****/
struct XpmIcon 
{
  Pixmap		pixmap;
  Pixmap		mask;
  XpmAttributes	xpmattributes;
};

struct	fsrecord 
{
  char	*filesystem;
  char	*mountdir;
  long	blocks;
  long	used;
  long	totalused;
  long	free;
  long 	totalfree;
  int	percent;
  int	totalpercent;
  int	x1, y1, x2, y2;
  char 	*type;
};

struct	settingsrecord
{
  char	*value;
  char	changed;
};

/**** global variables ****/
XtAppContext	application;
Widget		mainwidget;
Display		*display;
int		screen, screenwidth, screenheight;
Window		root, mainwindow, filewindow, mountwindow, mounterwin[24], iconwin[24];
Pixel		bgpixel, fgpixel, lfgpixel, tlfgpixel, lfontfgpixel, borderpixel, 
		zeropixel, popupfgpixel, popupbgpixel, popupborderpixel, redpixel, 
		greenpixel, yellowpixel;
GC		mainwindowgc, barlimitgc, bartotallimitgc, fontbarlimitgc, zerogc, 
		flipgc, thingc, flipthingc, popupgc;
GC		translucentgc;
XGCValues	gcv;
unsigned long	gcm;
int		interval, poppedup1=0, poppedup2=0;
int		limit, showzero, showperc, showtotal;
Pixmap		bgpixmap, canvas;
struct	XpmIcon	bgtexture, popupbgpixmap;
XFontStruct	*popupfont1, *popupfont2, *percentagefont;
int		fscounter;

enum		{bgcolor, fgcolor, lfgcolor, tlfgcolor, lfontfgcolor, lfontname, 
  		zerocolor, popupbgcolor, popupfgcolor, 
		popupfont1name, popupfont2name, popupbordercolor, bgpix, popupbgpix, 
		LAST_OPTION};
struct settingsrecord settings[LAST_OPTION] =
{
  {"DarkSlateGray", 					0}, 	// bgcolor
  {"LightSlateGray", 					0}, 	// fgcolor
  {"LightGreen", 					0},	// lfgcolor
  {"Blue",						0},	// tlfgcolor
  {"Black",						0},	// lfontfgcolor
  {"-*-fixed-medium-r-*-*-8-*-*-*-*-*-*-*",		0},	// lfontname
  {"IndianRed",						0},	// zerocolor
  {"DarkSlateGray",					0},	// popupbgcolor
  {"#20B2AA",						0},	// popupfgcolor
  {"-*-helvetica-*-*-*-*-10-240-*-*-*-*-*-*",		0},	// popupfont1name
  {"-*-helvetica-medium-r-*-*-10-240-*-*-*-*-*-*",	0},	// popupfont2name
  {"LightGray", 					0},	// popupbordercolor
  {"default", 						0},	// bgpix
  {"default",						0}	// popupbgpix
};

char 		buffer[BUFF_SIZE];
struct fsrecord	fs[MAX_FILESYSTEMS], fstab[MAX_FILESYSTEMS];


/**** source ****/

Pixel getcolor(const char *colorname) 
{
  XColor	color;
  XWindowAttributes	attributes;

  XGetWindowAttributes(display, mainwindow, &attributes);
  color.pixel=0;

  XParseColor(display, attributes.colormap, colorname, &color);
  XAllocColor(display, attributes.colormap, &color);

  return(color.pixel);
}


void defaults1(void) 
{
  int i;
  
  // default configuration
  showperc = 1;
  showzero = 0;
  showtotal = 1;
  limit = DEFAULT_LIMIT;
  interval=3;

  for(i = 0; i < MAX_FILESYSTEMS; i++)
   {
     fs[i].filesystem = NULL;
     fs[i].mountdir = NULL;
   }
}


void defaults2(void) 
{
  if (strcmp(settings[bgpix].value,"None")) 
   {
    bgtexture.xpmattributes.valuemask |= (XpmReturnPixels | XpmReturnExtensions);
    if (!strcmp(settings[bgpix].value,"default")) 
     {
      XpmCreatePixmapFromData(display, mainwindow, surreal_xpm,
	  &bgtexture.pixmap, 
	  &bgtexture.mask, 
	  &bgtexture.xpmattributes);
     } 
    else 
     {
      XpmReadFileToPixmap(display, mainwindow, settings[bgpix].value, 
	  &bgtexture.pixmap, 
	  &bgtexture.mask, 
	  &bgtexture.xpmattributes);
     }
   }

  if(strcmp(settings[popupbgpix].value, "None")) 
   {
    popupbgpixmap.xpmattributes.valuemask |= (XpmReturnPixels | XpmReturnExtensions);
    if (!strcmp(settings[popupbgpix].value,"default")) 
      XpmCreatePixmapFromData(display, mainwindow, purplestoneswirl_xpm, &popupbgpixmap.pixmap, &popupbgpixmap.mask, &popupbgpixmap.xpmattributes);
    else 
     {
      if(!strcmp(settings[popupbgpix].value,"Transparent") || !strcmp(settings[popupbgpix].value,"Translucent")) 
	popupbgpixmap.pixmap = (Pixmap)NULL;
      else 
	XpmReadFileToPixmap(display, mainwindow, settings[popupbgpix].value, &popupbgpixmap.pixmap, &popupbgpixmap.mask, &popupbgpixmap.xpmattributes);
     }
   }
}


void parsecmdline(int argc, char *argv[]) 
{
  int	i;

  for(i = 1; i < argc; i++) 
   {
    if(*argv[i] == '-') 
     {
      if(!strncmp(argv[i],"-showzero", 9)) showzero = 1;
      else if(!strncmp(argv[i], "-noperc", 7)) showperc = 0;
      else if(!strncmp(argv[i], "-nototal", 10)) showtotal = 0;
      else if(argc - i - 1)
       {
	if(!strncmp(argv[i],"-bg", 3))
	 {
	  settings[bgcolor].value = strdup(argv[++i]);
	  settings[bgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-bp", 3))
	 {
	  settings[bgpix].value = strdup(argv[++i]);
	  settings[bgpix].changed = 1;
	 }
	else if(!strncmp(argv[i],"-fg", 3)) 
	 {
	  settings[fgcolor].value = strdup(argv[++i]);
	  settings[fgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-lfg", 4)) 
	 {
	  settings[lfgcolor].value = strdup(argv[++i]);
	  settings[lfgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i], "-tlfg", 5))
	 {
	  settings[tlfgcolor].value = strdup(argv[++i]);
	  settings[tlfgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-lffg", 5)) 
	 {
	  settings[lfontfgcolor].value = strdup(argv[++i]);
	  settings[lfontfgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-lfn", 4)) 
	 {
	  settings[lfontname].value = strdup(argv[++i]);
	  settings[lfontname].changed = 1;
	 }
	else if(!strncmp(argv[i],"-l", 2)) 
	 {
	  limit=atoi(argv[++i]);
	  if(!limit || (limit < 0) || (limit >= 100)) 
	   {
	    fprintf(stderr, "-l %s: bad value - using built in value\n", argv[i - 1]);
	    limit = DEFAULT_LIMIT;
	   }
	 }
	else if(!strncmp(argv[i],"-pbg", 4)) 
	 {
	  settings[popupbgcolor].value = strdup(argv[++i]);
	  settings[popupbgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-pbp", 4)) 
	 {
	  settings[popupbgpix].value = strdup(argv[++i]);
	  settings[popupbgpix].changed = 1;
	 }
	else if(!strncmp(argv[i],"-pfg",4)) 
	 {
	  settings[popupfgcolor].value = strdup(argv[++i]);
	  settings[popupfgcolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-pfn1", 5)) 
	 {
	  settings[popupfont1name].value = strdup(argv[++i]);
	  settings[popupfont1name].changed = 1;
	 }
	else if(!strncmp(argv[i],"-pfn2", 5)) 
	 {
	  settings[popupfont2name].value = strdup(argv[++i]);
	  settings[popupfont2name].changed = 1;
	 }
	else if(!strncmp(argv[i],"-pbd",4)) 
	 {
	  settings[popupbordercolor].value = strdup(argv[++i]);
	  settings[popupbordercolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-z",2)) 
	 {
	  settings[zerocolor].value = strdup(argv[++i]);
	  settings[zerocolor].changed = 1;
	 }
	else if(!strncmp(argv[i],"-i",2)) interval=atoi(argv[++i]);
	else fprintf(stderr, "%s: unknown option\n", argv[i]);
       }
      else fprintf(stderr, "%s: unknown option or missing parameters\n", argv[i]);
    }
  }

  for(i = 0; i < LAST_OPTION; i++)
   {
     if(settings[i].value == NULL)
      {
        fprintf(stderr, "not enough memory\n");
	exit(-1);
      }
   }
}


void setuppixmaps(void) 
{
  if(strcmp(settings[bgpix].value,"None")) bgpixmap = bgtexture.pixmap;
  else 
   {
    bgpixmap=XCreatePixmap(display, mainwindow, 55, 57, DefaultDepth(display, screen));
    XFillRectangle(display, bgpixmap, flipgc, 0, 0, 55, 57);
   }

  XDrawLine(display, bgpixmap, thingc, 0, 0, 56, 0);
  XDrawLine(display, bgpixmap, thingc, 1, 1, 55, 1);
  XDrawLine(display, bgpixmap, thingc, 2, 2, 54, 2);
  XDrawLine(display, bgpixmap, thingc, 0, 0, 0, 57);
  XDrawLine(display, bgpixmap, thingc, 1, 1, 1, 56);
  XDrawLine(display, bgpixmap, thingc, 2, 2, 2, 55);

  XDrawLine(display, bgpixmap, flipthingc, 54, 0, 54, 57);
  XDrawLine(display, bgpixmap, flipthingc, 53, 1, 53, 56);
  XDrawLine(display, bgpixmap, flipthingc, 52, 2, 52, 55);
  XDrawLine(display, bgpixmap, flipthingc, 0, 56, 54, 56);
  XDrawLine(display, bgpixmap, flipthingc, 1, 55, 53, 55);
  XDrawLine(display, bgpixmap, flipthingc, 2, 54, 52, 54);

  canvas=XCreatePixmap(display, mainwindow, 55, 57, DefaultDepth(display, screen));
}


void setupfonts(void) 
{
  popupfont1=XLoadQueryFont(display, settings[popupfont1name].value);
  popupfont2=XLoadQueryFont(display, settings[popupfont2name].value);
  percentagefont = XLoadQueryFont(display, settings[lfontname].value);
}


int compare(const void *fs1, const void *fs2)
{
  if((((struct fsrecord *)fs1)->blocks) && (((struct fsrecord *)fs2)->blocks)) return(0);
  if(((struct fsrecord *)fs1)->blocks > ((struct fsrecord *)fs2)->blocks) return(-1);
  if(((struct fsrecord *)fs1)->blocks < ((struct fsrecord *)fs2)->blocks) return(1);
  return(0);
}


void readstatfile(void) 
{
  int			counter;
  struct statfs 	fsstats;
  FILE 			*mtab;
  char 			*p2, *p1;
  
  // we must open the file with infos on mounted fs
  if((mtab = fopen(MTAB_FILE, "r")) == NULL)
   {
     fprintf(stderr, "%s: %s\n", MTAB_FILE, sys_errlist[errno]);
     exit(1);
   }
  // we go line by line through the file
  counter = 0;
  while(fgets(buffer, BUFF_SIZE, mtab) != NULL)
   {
     // first we'll get the filesystem device
     p1 = buffer;
     while(*p1 != ' ') p1++;
     // if the filesystem is 'none' we skip to next line if showzero != 1
     if(!strncmp(buffer, "none", p1 - buffer) && !(showzero)) continue;
     if((fs[counter].filesystem == NULL) || 
	((fs[counter].filesystem != NULL) && (strlen(fs[counter].filesystem) < (p1 - buffer))))
      {
       if((fs[counter].filesystem = (char *)realloc(fs[counter].filesystem, p1 - buffer + 1)) == NULL)
	{
	 fprintf(stderr, "Not enough memory\n");
	 fclose(mtab);
	 return;
	}
      }
     strncpy(fs[counter].filesystem, buffer, p1 - buffer);
     fs[counter].filesystem[p1 - buffer] = '\0';
      
     // then we'll get the mount dir
     while(*p1 == ' ') p1++;
     p2 = p1;
     while(*p2 != ' ') p2++;
     if((fs[counter].mountdir == NULL) ||
	((fs[counter].mountdir != NULL) && (strlen(fs[counter].mountdir) < (p2 - p1))))
      {
       if((fs[counter].mountdir = (char *)realloc(fs[counter].mountdir, p2 - p1 + 1)) == NULL)
	{
	 fprintf(stderr, "Not enough memory\n");
	 fclose(mtab);
	 return;
	}
      }
     strncpy(fs[counter].mountdir, p1, p2 - p1);
     fs[counter].mountdir[p2 - p1] = '\0';

     // and the fs type
     p1 = p2;
     while(*p1 == ' ') p1++;
     p2 = p1;
     while(*p2 != ' ') p2++;
     if((fs[counter].type == NULL) ||
	((fs[counter].type != NULL) && (strlen(fs[counter].type) < (p2 - p1))))
      {
       if((fs[counter].type = (char *)realloc(fs[counter].type, p2 - p1 + 1)) == NULL)
	{
	 fprintf(stderr, "Not enough memory\n");
	 fclose(mtab);
	 return;
	}
      }
     strncpy(fs[counter].type, p1, p2 - p1);
     fs[counter].type[p2 - p1] = '\0';
     
     // now that we know the mountdir, we can get some more info
#ifndef SOLARIS     
     if(statfs(fs[counter].mountdir, &fsstats))
#else
     if(statvfs(fs[counter].mountdir, &fsstats))
#endif	
      {
        fprintf(stderr, "statfs: %s\n", sys_errlist[errno]);
	fclose(mtab);
	return;
      }
     fs[counter].blocks = fsstats.f_blocks * fsstats.f_bsize / 1024;
     fs[counter].free = fsstats.f_bavail * fsstats.f_bsize / 1024;
     fs[counter].totalfree = fsstats.f_bfree * fsstats.f_bsize / 1024;
     fs[counter].used = fs[counter].blocks - fs[counter].free;
     fs[counter].totalused = fs[counter].blocks - fs[counter].totalfree;
     if(fs[counter].blocks) 
      {
       fs[counter].percent = (int)(fs[counter].used * 100.0 / fs[counter].blocks);
       fs[counter].totalpercent = (int)(fs[counter].totalused * 100.0 / fs[counter].blocks);
      }
     else
      {
       fs[counter].percent = 0;
       fs[counter].totalpercent = 0;
      }

     // if showzero == 1 we'll show also the FSs which are of zero size
     if(fs[counter].blocks || showzero) counter++;
     if(counter >= MAX_FILESYSTEMS) break;
   }
  fscounter = counter;
  fclose(mtab);

  // if zero block FSs are in the fs[] array, we'll move them to the end
  qsort(fs, fscounter, sizeof(struct fsrecord), compare);
}


int calclineheight(int num) 
{
  if(num > 0) return((50 - num) / num);
  else 
   {
    printf("\nWarning, Line height defaulted to 1.\n");
    return 1;
   }
}


int calclinewidth(struct fsrecord *fs, int y, int lineheight) 
{
  float	linewidth;

  if(!fs->blocks) linewidth=48;
  else linewidth=(int)(((float)fs->used / (float)fs->blocks) * 48.0);

  /* set up fsrecord x,y's */
  fs->x1 = 0;
  fs->y1 = y - (lineheight / 2);
  fs->x2 = linewidth;
  fs->y2 = y + (lineheight / 2);

  return(linewidth);
}


void checkusagecb(XtPointer XtP, XtIntervalId *XtI);

void checkusage(void) 
{
  int	i, lineheight, y, linewidth;
  int	rest;

  /* get a list of filesystems */
  readstatfile();
  /* restore canvas pixmap */
  XCopyArea(display, bgpixmap, canvas, mainwindowgc, 0, 0, 55, 57, 0, 0);
  /* calculate line height */
  lineheight = calclineheight(fscounter);

  XSetLineAttributes(display, mainwindowgc, lineheight, LineSolid, CapButt, JoinRound);
  XSetLineAttributes(display, barlimitgc, lineheight, LineSolid, CapButt, JoinRound);
  XSetLineAttributes(display, bartotallimitgc, 2, LineSolid, CapButt, JoinRound);
  XSetLineAttributes(display, zerogc, lineheight, LineSolid, CapButt, JoinRound);

  /* draw lines */
  y = (lineheight / 2) + 1;
  for(i = 0; i < fscounter; i++) 
   {
    /* calculate line width */
    linewidth = calclinewidth(&fs[i], y, lineheight);
    /* draw new lines */
    if(fs[i].blocks) 
     {
      if(fs[i].percent < limit) XDrawLine(display, canvas, mainwindowgc, 3, y + 3, linewidth + 3, y + 3);
      else
       {
	rest = (int)(((float)linewidth * (float)limit) / fs[i].percent);
	XDrawLine(display, canvas, mainwindowgc, 3, y + 3, rest + 3, y + 3);
	XDrawLine(display, canvas, barlimitgc, rest + 3, y + 3, linewidth + 3, y + 3);
	// if showtotal == 1 draw the total free percent too
	if(showtotal)
	 {
	  rest = (int)(((float)linewidth * (float)fs[i].totalpercent) / fs[i].percent);
	  XDrawLine(display, canvas, bartotallimitgc, rest, y + 3 - lineheight / 2, rest, y + 3 + lineheight / 2);
	 }
       }
     }
    else XDrawLine(display, canvas, zerogc, 3, y + 3, linewidth + 3, y + 3);
    if((lineheight > 2) && (linewidth > 2)) 
     {
      if(fs[i].blocks) 
       {
	/* raised */
	XDrawLine(display, canvas, thingc, 3, y + lineheight / 2 + 3, linewidth + 3, y + lineheight / 2 + 3);
	XDrawLine(display, canvas, flipthingc, 3, y - lineheight / 2 + 3, linewidth + 3, y - lineheight / 2 + 3);
	XDrawLine(display, canvas, flipthingc, 3, y + lineheight / 2 + 3, 3, y - lineheight / 2 + 3);
	XDrawLine(display, canvas, thingc, linewidth + 3, y + lineheight / 2 + 3, linewidth + 3, y - lineheight / 2 + 3);
       } 
      else 
       {
	/* lowered */
	XDrawLine(display, canvas, flipthingc, 3, y + lineheight / 2 + 3, linewidth + 3, y + lineheight / 2 + 3);
	XDrawLine(display, canvas, thingc, 3, y - lineheight / 2 + 3, linewidth + 3, y - lineheight / 2 + 3);
	XDrawLine(display, canvas, thingc, 3, y + lineheight / 2 + 3, 3, y - lineheight / 2 + 3);
	XDrawLine(display, canvas, flipthingc, linewidth + 3, y + lineheight / 2 + 3, linewidth + 3, y - lineheight / 2 + 3);
       }
     }
    // draw the percentage of usage
    sprintf(buffer, "%d%%", fs[i].percent);
    // if showperc == 1 and the font can get into the bar, draw it
// FIXME: how to determine the correct font height so it fits perfectly?    
    if((showperc) && (lineheight > percentagefont->ascent) && (linewidth > (XTextWidth(percentagefont, buffer, strlen(buffer)) + 9)))
      XDrawString(display, canvas, fontbarlimitgc, 7, y + lineheight / 2 + 1, buffer, strlen(buffer));
    y += lineheight + 1;
   }
  XCopyArea(display, canvas, mainwindow, mainwindowgc, 0, 0, 55, 57, 0, 0);

  /* get my stuff drawn, harmlessly */
  XPending(display);
  XtAppAddTimeOut(application, interval * 1000, checkusagecb, NULL);
}


void exposurecb(Widget w, XtPointer unused, register XButtonPressedEvent *event, Boolean *continue_to_dispatch)
{
  XCopyArea(display, canvas, mainwindow, mainwindowgc, 0, 0, 55, 57, 0, 0);
}  
  

void checkusagecb(XtPointer XtP, XtIntervalId *XtI) 
{
  checkusage();
}


void translucent(Window win, int width, int height) 
{
  int			i;
  static unsigned char	dotted[2]={ 1, 1 };

  gcm = GCForeground | GCLineStyle | GCCapStyle | GCLineWidth;
  gcv.foreground = bgpixel;
  gcv.line_style = LineOnOffDash;
  gcv.cap_style = CapButt;
  gcv.line_width = 1;
  translucentgc = XCreateGC(display, mainwindow, gcm, &gcv);
  XSetDashes(display, translucentgc, 0, dotted, 2);
  for(i = 0; i < height; i++) 
   {
    if(!(i % 2)) XDrawLine(display, win, translucentgc, 0, i, width, i);
    else XDrawLine(display, win, translucentgc, 1, i, width, i);
   }
  XFreeGC(display, translucentgc);
}


void popupfilewindow(struct fsrecord fs, int x, int y) 
{
  XSetWindowAttributes	setwinattr;
  int			winx, winy;
  int			longest=0,longest1;
  int			startfrom;

  if(!poppedup1) 
   {
    poppedup1=2;
    /* find longest word */
    longest1 = XTextWidth(popupfont1, fs.mountdir, strlen(fs.mountdir));
    if(longest1 > longest) longest = longest1;
    longest1 = XTextWidth(popupfont1, fs.filesystem, strlen(fs.filesystem));
    if(longest1 > longest) longest = longest1;
    // we'll consider all the following numbers as to be long 11 chars
    longest1 = 11 * XTextWidth(popupfont1, "2", 1);
    if(longest1 > longest) longest = longest1;
    startfrom = XTextWidth(popupfont1, "Total Percent Used", 18) + 12; 
    longest += startfrom;

    if(x >= (screenwidth / 2)) winx = x - 12 - longest;
    else winx = x + 12;

    if(y >= (screenheight / 2)) winy = y - 76;
    else winy = y;

    filewindow = XCreateSimpleWindow(display, root, winx, winy, longest, 123, 2, popupborderpixel, popupbgpixel);

    setwinattr.override_redirect = True;
    if(strcmp(settings[popupbgpix].value,"None")) 
     {
      setwinattr.background_pixmap = popupbgpixmap.pixmap;
      XChangeWindowAttributes(display, filewindow, CWOverrideRedirect | CWBackPixmap, &setwinattr);
     } 
    else XChangeWindowAttributes(display, filewindow, CWOverrideRedirect, &setwinattr);

    XSetFont(display, popupgc, popupfont1->fid);
    XMapWindow(display, filewindow);

    if(!strcmp(settings[popupbgpix].value,"Translucent")) translucent(filewindow, longest, 76);

    XDrawString(display, filewindow, popupgc, 2, 12, "Mount Dir", 9);
    XDrawString(display, filewindow, popupgc, 2, 27, "File System", 11);
    XDrawString(display, filewindow, popupgc, 2, 42, "Type", 4);
    XDrawString(display, filewindow, popupgc, 2, 57, "Blocks", 6);
    XDrawString(display, filewindow, popupgc, 2, 72, "Free", 4);
    XDrawString(display, filewindow, popupgc, 2, 87, "Percent Used", 12);
    XDrawString(display, filewindow, popupgc, 2, 102, "Total Free", 10);
    XDrawString(display, filewindow, popupgc, 2, 117, "Total Percent Used", 18);

    XSetFont(display, popupgc, popupfont2->fid);

    XDrawString(display, filewindow, popupgc, startfrom, 12, fs.mountdir, strlen(fs.mountdir));
    XDrawString(display, filewindow, popupgc, startfrom, 27, fs.filesystem, strlen(fs.filesystem));
    XDrawString(display, filewindow, popupgc, startfrom, 42, fs.type, strlen(fs.type));
    sprintf(buffer, "%ld", fs.blocks);
    XDrawString(display, filewindow, popupgc, startfrom, 57, buffer, strlen(buffer));
    sprintf(buffer, "%ld", fs.free);
    XDrawString(display, filewindow, popupgc, startfrom, 72, buffer, strlen(buffer));
    sprintf(buffer, "%d%%", fs.percent);
    XDrawString(display, filewindow, popupgc, startfrom, 87, buffer, strlen(buffer));
    sprintf(buffer, "%ld", fs.totalfree);
    XDrawString(display, filewindow, popupgc, startfrom, 102, buffer, strlen(buffer));
    sprintf(buffer, "%d%%", fs.totalpercent);
    XDrawString(display, filewindow, popupgc, startfrom, 117, buffer, strlen(buffer));

    /* get my stuff drawn, harmlessly */
    XPending(display);

    poppedup1=1;
  }
}


void popdownfilewindow(void) 
{
  if(poppedup1 == 1) 
   {
    XDestroyWindow(display, filewindow);
    poppedup1 = 0;
   }
}


void popdownfilewindowcb(Widget w, XtPointer unused, register XButtonPressedEvent *event, Boolean *continue_to_dispatch) 
{
  popdownfilewindow();
}


void handleclick(void) 
{
  Window	dummy;
  int		rootx, rooty, winx, winy, i;
  int		lineheight, y, inaline=0;
  unsigned int	mask;

  XQueryPointer(display, mainwindow, &dummy, &dummy, &rootx, &rooty, &winx, &winy, &mask);

  lineheight=calclineheight(fscounter);
  y = (lineheight / 2) + 1;

  for (i=0; i<fscounter; i++) 
   {
    calclinewidth(&fs[i], y, lineheight);
    if((winx >= (fs[i].x1 + 3)) && (winx <= (fs[i].x2 + 3)) && 	
	(winy>=(fs[i].y1 + 3)) && (winy <= (fs[i].y2 + 3))) 
     {
      popupfilewindow(fs[i], rootx, rooty);
      inaline = 1;
     }
    y += lineheight + 1;
   }
}


void handleclickcb(Widget w, XtPointer unused, register XButtonPressedEvent *event, Boolean *continue_to_dispatch) 
{
  handleclick();
}


void cleanup(void)
{
  int i;

  for(i = 0; i < LAST_OPTION; i++)
   {
    if((settings[i].changed) && (settings[i].value != NULL)) free(settings[i].value);
   }
}


void exitprogcb(Widget w, XtPointer unused, register XButtonPressedEvent *event, Boolean *continue_to_dispatch) 
{
  if(event->type == DestroyNotify) 
   {
     XFreePixmap(display, canvas);
     XFreePixmap(display, bgpixmap);
     XFreeGC(display, mainwindowgc);
     XFreeGC(display, fontbarlimitgc);
     XFreeGC(display, barlimitgc);
     XFreeGC(display, bartotallimitgc);
     XFreeGC(display, flipgc);
     XFreeGC(display, thingc);
     XFreeGC(display, flipthingc);
     XFreeGC(display, popupgc);
     XDestroyWindow(display, mainwindow);
     XCloseDisplay(display);
     cleanup();
     exit(0);
   }
}


int main (int argc, char *argv[]) 
{
  XEvent 	report;

  defaults1();
  parsecmdline(argc, argv);

  mainwidget=XtAppInitialize(&application, "asfsm", NULL, 0, &argc, argv, NULL, NULL, 0);
  XtResizeWidget(mainwidget, 55, 57, 0);
  XtRealizeWidget(mainwidget);

  display=XtDisplay(mainwidget);

  screen=DefaultScreen(display);
  screenwidth=DisplayWidth(display, screen);
  screenheight=DisplayHeight(display, screen);

  root=RootWindow(display, screen);
  mainwindow=XtWindow(mainwidget);
  XtMapWidget(mainwidget);

  defaults2();
  setupfonts();

  bgpixel=getcolor(settings[bgcolor].value);
  fgpixel=getcolor(settings[fgcolor].value);
  lfgpixel = getcolor(settings[lfgcolor].value);
  tlfgpixel = getcolor(settings[tlfgcolor].value);
  zeropixel=getcolor(settings[zerocolor].value);
  popupbgpixel=getcolor(settings[popupbgcolor].value);
  popupfgpixel=getcolor(settings[popupfgcolor].value);
  popupborderpixel=getcolor(settings[popupbordercolor].value);
  redpixel=getcolor("IndianRed");
  greenpixel=getcolor("Aquamarine3");
  yellowpixel=getcolor("PeachPuff");

  gcm=GCForeground | GCBackground | GCGraphicsExposures | GCFunction;
  gcv.foreground=fgpixel;
  gcv.background=bgpixel;
  gcv.graphics_exposures=True;
  gcv.function = GXcopy;
  mainwindowgc=XCreateGC(display, mainwindow, gcm, &gcv);

  gcm = GCForeground | GCBackground | GCFunction;
  gcv.foreground = lfgpixel;
  gcv.background = bgpixel;
  gcv.function = GXcopy;
  barlimitgc = XCreateGC(display, mainwindow, gcm, &gcv);

  // GC for the total amounts
  gcm = GCForeground | GCFunction;
  gcv.foreground = tlfgpixel;
  gcv.function = GXcopy;
  bartotallimitgc = XCreateGC(display, mainwindow, gcm, &gcv);

  gcm = GCForeground | GCFunction | GCFont;
  gcv.foreground = lfontfgpixel;
  gcv.function = GXcopy;
  gcv.font = percentagefont->fid;
  fontbarlimitgc = XCreateGC(display, mainwindow, gcm, &gcv);
  
  gcm=GCForeground;
  gcv.foreground=zeropixel;
  zerogc=XCreateGC(display, mainwindow, gcm, &gcv);
  
  gcm=GCForeground | GCBackground;
  gcv.background=fgpixel;
  gcv.foreground=bgpixel;
  flipgc=XCreateGC(display, mainwindow, gcm, &gcv);
  gcv.foreground=popupfgpixel;
  gcv.background=popupbgpixel;
  popupgc=XCreateGC(display, mainwindow, gcm, &gcv);
  
  gcm=GCForeground;
  gcv.foreground=getcolor("#535353");
  thingc=XCreateGC(display, mainwindow, gcm, &gcv);
  XSetLineAttributes(display, thingc, 1, LineSolid, CapButt, JoinRound);
  gcv.foreground=getcolor("#dbdbdb");
  flipthingc=XCreateGC(display, mainwindow, gcm, &gcv);
  XSetLineAttributes(display, flipthingc, 1, LineSolid, CapButt, JoinRound);

  setuppixmaps();
  checkusage();

  XtAddEventHandler(mainwidget, ButtonPressMask, False, (XtEventHandler)handleclickcb, NULL);
  XtAddEventHandler(mainwidget, ButtonReleaseMask, False, (XtEventHandler)popdownfilewindowcb, NULL);
  XtAddEventHandler(mainwidget, StructureNotifyMask, False, (XtEventHandler)exitprogcb, NULL);
  XtAddEventHandler(mainwidget, ExposureMask, False, (XtEventHandler)exposurecb, NULL);

  XPending(display);
  while (1) 
   {
    XtAppNextEvent(application, &report);
    XtDispatchEvent(&report);
   }
}
