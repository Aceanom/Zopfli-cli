/*
 *--------------------------------*-C-*---------------------------------
 * File:        command.h
 *
 * Copyright (c) 1992 John Bovey <jdb@ukc.ac.uk>
 * Copyright (c) 1994 R. Nation <nation@rocket.sanders.lockheed.com>
 * Copyright (c) 1997 Mj Olesen <olesen@me.QueensU.CA>
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License version
 *  2 as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *----------------------------------------------------------------------
 */

#ifndef _COMMAND_H
#define _COMMAND_H

#include <X11/Xfuncproto.h>
#include <stdio.h>

#define scrollBar_esc	30

_XFUNCPROTOBEGIN

extern void
 init_command(char * /* argv */ []);

extern void
 tt_resize(void);

extern void
 tt_write(const unsigned char * /* str */ ,
	  unsigned int /* count */ );

extern void
 tt_printf(const unsigned char * /* fmt */ ,...);

extern unsigned int
 cmd_write(const unsigned char * /* str */ ,
	   unsigned int /* count */ );

extern void
 main_loop(void);

extern FILE *
 popen_printer(void);

extern int
 pclose_printer(FILE * /* stream */ );

_XFUNCPROTOEND

#endif				/* whole file */
/*----------------------- end-of-file (C header) -----------------------*/
