/*
 * Copyright (C) 1995 Bo Yang
 * Copyright (C) 1993 Robert Nation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include "../../include/configure.h"

#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xatom.h>
#include <X11/Intrinsic.h>

#ifdef NeXT
#include <fcntl.h>
#endif

#include "Wharf.h"

#ifdef XPM
#include <X11/xpm.h>
#endif /* XPM */
#include "stepgfx.h"


/****************************************************************************
 *
 * Loads an icon file into a pixmap
 *
 ****************************************************************************/
void LoadIconFile(icon_info* icon)
{
#ifndef NO_ICONS
  /* First, check for a monochrome bitmap */
  if((*icon).file != NULL)
    GetBitmapFile(icon);
  /* Next, check for a color pixmap */
  if(((*icon).file != NULL)&&
     ((*icon).w == 0)&&((*icon).h == 0))
    GetXPMFile(icon);
#endif
}

/****************************************************************************
 *
 * Creates an Icon Window
 *
 ****************************************************************************/
void CreateIconWindow(button_info* button, Window *win)
{
#ifndef NO_ICONS
  unsigned long valuemask;		/* mask for create windows */
  XSetWindowAttributes attributes;	/* attributes for create windows */

    /* This used to make buttons without icons explode when pushed
  if(((*button).icon_w == 0)&&((*button).icon_h == 0))
    return;
     */
  attributes.background_pixel = back_pix;
  attributes.event_mask = ExposureMask;
  valuemask =  CWEventMask | CWBackPixel;

  (*button).IconWin =
    XCreateWindow(dpy, *win, 0, 0, BUTTONWIDTH,
                  BUTTONHEIGHT, 0, CopyFromParent,
                  CopyFromParent,CopyFromParent,valuemask,&attributes);

  return;
#endif
}

/****************************************************************************
 *
 * Combines icon shape masks after a resize
 *
 ****************************************************************************/
void ConfigureIconWindow(button_info* button,int row, int column)
{
#ifndef NO_ICONS
  int x,y, w, h;
  int xoff,yoff;
  int i;  

    
    if((*button).num_icons == 0)
      return;
    x = column*BUTTONWIDTH;
    y = row*BUTTONHEIGHT; 

    XMoveResizeWindow(dpy, (*button).IconWin, x,y,BUTTONWIDTH,
		      BUTTONHEIGHT);
    (*button).completeIcon = 
      XCreatePixmap(dpy,Root, BUTTONWIDTH,BUTTONHEIGHT,d_depth);
    XCopyArea(dpy, (*back_button).icons[0].icon,
	      (*button).completeIcon, NormalGC, 0,0,
	      BUTTONWIDTH,BUTTONHEIGHT, 0,0);
	      
    for(i=0;i<(*button).num_icons;i++) {
	w = (*button).icons[i].w;
	h = (*button).icons[i].h;
	if (w<1 || h<1) continue;
	if(w > BUTTONWIDTH) w = BUTTONWIDTH;
	if(h > BUTTONHEIGHT) h = BUTTONHEIGHT;
	if (w < 1) w = 1;
	if (h < 1) h = 1;
#ifdef XPM 
	xoff = (BUTTONWIDTH - w)/2;
	yoff = (BUTTONHEIGHT - h)/2;
	if (xoff<0) xoff=0;
	if (yoff<0) yoff=0;
	if ((*button).icons[i].mask != None) {
	    XSetClipOrigin(dpy, MaskGC, xoff, yoff);	
	    XSetClipMask(dpy, MaskGC, (*button).icons[i].mask);
	} else {
            XRectangle rect[1];
            rect[0].x=0; rect[0].y=0; 
            rect[0].width=w; rect[0].height=h;
           
            XSetClipRectangles(dpy,MaskGC,xoff,yoff, rect, 1, YSorted);
        }   
	XCopyArea(dpy, (*button).icons[i].icon,
		  (*button).completeIcon, MaskGC, 0,0,
		  w, h, xoff,yoff);
	    /* don't need them anymore */
	XFreePixmap(dpy, (*button).icons[i].icon);
	(*button).icons[i].icon = None;
	if ((*button).icons[i].mask != None) {
	    XFreePixmap(dpy, (*button).icons[i].mask);
	    (*button).icons[i].mask = None;
	}
#endif
	if((*button).icons[i].depth == -1) {
	    XCopyPlane(dpy,(*button).icons[i].icon,
		       (*button).completeIcon,NormalGC,
		       0,0,w,h, 0,0,1);
	    XFreePixmap(dpy, (*button).icons[i].icon);
	    (*button).icons[i].icon = None;
	}
    }
    XSetWindowBackgroundPixmap(dpy, (*button).IconWin,
			       (*button).completeIcon);
    XClearWindow(dpy,(*button).IconWin);
#endif 
}

/***************************************************************************
 *
 * Looks for a monochrome icon bitmap file
 *
 **************************************************************************/
void GetBitmapFile(icon_info* icon)
{
#ifndef NO_ICONS
  char *path = NULL;
  int HotX,HotY;

  path = findIconFile((*icon).file, iconPath,R_OK);
  if(path == NULL)return;

  if(XReadBitmapFile (dpy, Root,path,(unsigned int *)&(*icon).w,
		      (unsigned int *)&(*icon).h,
		      &(*icon).icon,
		      (int *)&HotX, 
		      (int *)&HotY) != BitmapSuccess)
    {
      (*icon).w = 0;
      (*icon).h = 0;
    }
  else
    {
      (*icon).depth = -1;
    }
  (*icon).mask = None;
  free(path);
#endif
}


/****************************************************************************
 *
 * Looks for a color XPM icon file
 *
 ****************************************************************************/
int GetXPMFile(icon_info* icon)
{
#ifndef NO_ICONS
#ifdef XPM
  XWindowAttributes root_attr;
  XpmAttributes xpm_attributes;
  char *path = NULL;

    path = findIconFile((*icon).file, pixmapPath,R_OK);
    if(path == NULL) return 0;
    XGetWindowAttributes(dpy,Root,&root_attr);    
    xpm_attributes.colormap = root_attr.colormap;
    xpm_attributes.closeness = 40000;
    xpm_attributes.valuemask = XpmSize | XpmReturnPixels|XpmColormap
      |XpmCloseness;
    if(XpmReadFileToPixmap(dpy, Root, path,
			   &(*icon).icon,
			   &(*icon).mask,
			   &xpm_attributes) == XpmSuccess)
    {
	(*icon).w = xpm_attributes.width;
	(*icon).h = xpm_attributes.height;
	(*icon).depth = d_depth;
	free(path);
    } else {
	free(path);
	(*icon).icon=None;
	return 0;
    }
  if (icon == &(*back_button).icons[0]) {
      BUTTONWIDTH = xpm_attributes.width;
      BUTTONHEIGHT = xpm_attributes.height;
      if (ForceSize && (BUTTONWIDTH > 64 || BUTTONHEIGHT > 64)) {
	  Pixmap resized;
	  
	  BUTTONWIDTH = 64;
	  BUTTONHEIGHT = 64;
	  resized = XCreatePixmap(dpy, Root, 64, 64, d_depth);
	  XCopyArea(dpy, (*icon).icon,
		    resized, NormalGC, 0, 0, 64, 64, 0, 0);
	  XFreePixmap(dpy, (*icon).icon);
	  (*icon).icon = resized;
      }
      DrawOutline((*icon).icon,BUTTONWIDTH,BUTTONHEIGHT);
  }
  return 1;
#endif /* XPM */
#endif
}

/****************************************************************************
 *
 * read background icons from data
 *
 ****************************************************************************/
int GetXPMData(icon_info* icon, char **data)
{
#ifndef NO_ICONS
#ifdef XPM
  XWindowAttributes root_attr;
  XpmAttributes xpm_attributes;

  if(icon != &(*back_button).icons[0])
	return 0;
  XGetWindowAttributes(dpy,Root,&root_attr);
  xpm_attributes.colormap = root_attr.colormap;
  xpm_attributes.valuemask = XpmSize | XpmReturnPixels|XpmColormap;
  if(XpmCreatePixmapFromData(dpy, Root, data,
			 &(*icon).icon,
			 &(*icon).mask,
			 &xpm_attributes) == XpmSuccess) 
    { 
      BUTTONWIDTH = (*icon).w = xpm_attributes.width;
      BUTTONHEIGHT = (*icon).h = xpm_attributes.height;
      (*icon).depth = d_depth;
    } 
   else {
       return 0;
   }
    DrawOutline((*icon).icon,BUTTONWIDTH,BUTTONHEIGHT);

    return 1;
#endif /* XPM */
#endif
}

/*******************************************************************
 * 
 * Make a gradient pixmap
 * 
 *******************************************************************/

int GetXPMGradient(icon_info* icon, int from[3], int to[3], int maxcols,
		   int type)
{
    (*icon).icon=XCreatePixmap(dpy,Root,64,64, d_depth);
    (*icon).mask=None;
    (*icon).w = 64;
    (*icon).h = 64;
    if (icon==&(*back_button).icons[0]) {
	BUTTONWIDTH = 64;
	BUTTONHEIGHT = 64;
    }
    (*icon).depth = d_depth;
    switch (type) {
     case TEXTURE_GRADIENT:
	if (!DrawDegradeRelief(dpy, (*icon).icon, 0,0,64,64,
			 	from, to, 0, maxcols)) {
	    XFreePixmap(dpy, (*icon).icon);
	    (*icon).icon = None;
	    return 0;
	}
	break;
     case TEXTURE_HGRADIENT:
     case TEXTURE_HCGRADIENT:
	if (!DrawHGradient(dpy, (*icon).icon, 0, 0, 64,64,
			 from, to, 0, maxcols, type-TEXTURE_HGRADIENT)) {
	    XFreePixmap(dpy, (*icon).icon);
	    (*icon).icon = None;
	    return 0;	    
	}
	break;
     case TEXTURE_VGRADIENT:
     case TEXTURE_VCGRADIENT:
	if (!DrawVGradient(dpy, (*icon).icon, 0, 0, 64,64,
			 from, to, 0, maxcols, type-TEXTURE_VGRADIENT)) {
	    XFreePixmap(dpy, (*icon).icon);
	    (*icon).icon = None;
	    return 0;	    
	} 
	break;
     default:
	return 0;
    }
    DrawOutline((*icon).icon,64,64);

    return 1;
}

/*******************************************************************
 * 
 * Make a solid color pixmap
 * 
 *******************************************************************/

int GetSolidXPM(icon_info* icon, Pixel pixel)
{
    GC gc;
    XGCValues gcv;

    gcv.foreground=pixel;
    gc=XCreateGC(dpy,Root,GCForeground, &gcv);
    if (icon==&(*back_button).icons[0]) {
	BUTTONWIDTH = 64;
	BUTTONHEIGHT = 64;
    }
    (*icon).icon=XCreatePixmap(dpy,Root,64,64, d_depth);
    (*icon).mask=None;
    XFillRectangle(dpy,(*icon).icon,gc,0,0,64,64);
    (*icon).w = 64;
    (*icon).h = 64;
    (*icon).depth = d_depth;
    XFreeGC(dpy,gc);    
    DrawOutline((*icon).icon,64,64);

    return 1;
}
