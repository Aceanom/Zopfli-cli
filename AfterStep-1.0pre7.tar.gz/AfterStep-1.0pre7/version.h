#define VERSION "1.0pre7"
