#!/bin/sh

program_name="asthemechreate.sh"
program_version="0.5.3"

###############################################################################
# get the theme name
# if --theme option is seen, use it, else name defaults to $USER

opts=""
while test -n "$1"; do
	case "$1" in
		-v|--version)
			echo "$program_name $program_version"
			exit
			;;
		--no_background)
			opts="$opts $1"
			;;
		--no_pager)
			opts="$opts $1"
			;;
		--no_wharf)
			opts="$opts $1"
			;;
		--no_winlist)
			opts="$opts $1"
			;;
		--theme)
			shift
			name="$1"
			;;
		--)
			shift
			break
			;;
		*)
			break
			;;
	esac
	shift
done

if test "x$name" = "x"; then
	if test -n "$1"; then
		name="$1"
	else
		name=$USER
	fi
fi

###############################################################################
# get the AfterDir config item from AS (usually ~/GNUstep/Library/AfterStep)

gla=`afterstep -c | grep AfterDir | sed s/AfterDir//`
gla=`echo $gla | sed s@~/@$HOME/@`

###############################################################################
# ensure theme-related directories exist

for i in $gla/themes $gla/desktop/themes; do
  if ! test -d $i; then
    echo Creating directory $i...
    mkdir -p $i
  fi
done

###############################################################################
# create the theme
# WARNING: this script typically gets its input from a form, and people may 
# provide a theme name with spaces; the havok that could be caused by a 
# careless "rm -rf $gla/desktop/themes/tick / tock" should not be lightly 
# dismissed!

if test -n "$name" && test -d "$gla/desktop/themes/$name"; then
	echo Deleting directory $gla/desktop/themes/$name
	rm -rf "$gla/desktop/themes/$name"
fi
makeastheme.pl $opts --theme "$name"
cd $gla/desktop/themes
tar cf - "$name" | gzip -9 > "$gla/themes/$name.tar.gz"

###############################################################################
# tell AS to update

ascommand.pl 'QuickRestart "" startmenu'
