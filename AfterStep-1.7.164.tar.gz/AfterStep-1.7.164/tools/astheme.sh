#!/bin/sh

program_name="astheme.sh"
program_version="0.5.3"

###############################################################################
# check options

opts=""
while test -n "$1"; do
	case "$1" in
		-v|--version)
			echo "$program_name $program_version"
			exit
			;;
		--)
			shift
			break
			;;
		*)
			break
			;;
	esac
	shift
done

if ! test -r $*; then
	echo "Unable to read theme: $*"
	exit 1
fi

###############################################################################
# get the theme name from the tarfile name

name=`echo $* | sed 's@/.*/@/@' | sed 's@/@@' | cut -d. -f1`

###############################################################################
# get the AfterDir config item from AS (usually ~/GNUstep/Library/AfterStep)

gla=`afterstep -c | grep AfterDir | sed s/AfterDir//`
gla=`echo $gla | sed s@~/@$HOME/@`

###############################################################################
# ensure theme-related directories exist

for i in $gla/desktop/themes; do
  if ! test -d $i; then
    echo Creating directory $i...
    mkdir -p $i
  fi
done

###############################################################################
# install the theme

# all this error checking may seem stupid, but i did remove my home dir
# because it was not there, do not MESS with rm -rf * !

if test -e $gla/desktop/themes; then
	rm -rf $gla/desktop/themes
	cd $gla/desktop
	gzip -dc $* | tar -xf -
	mv $gla/desktop/$name $gla/desktop/themes
	installastheme.pl --theme $name
	rm -f $gla/desktop/themes/afterstep_version
	rm -f $gla/desktop/themes/background.$name
	rm -f $gla/desktop/themes/wharf.$name
	rm -f $gla/desktop/themes/winlist.$name
	rm -f $gla/desktop/themes/pager.$name
	rm -f $gla/desktop/themes/look.$name
fi

# tell AS to update

ascommand.pl 'Restart "" afterstep'
