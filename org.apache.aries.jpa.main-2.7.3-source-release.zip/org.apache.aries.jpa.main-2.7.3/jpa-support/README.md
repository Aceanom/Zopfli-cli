#Aries JPA Helper services

These services are deprecated in favour of the standard OSGi Transaction Control Service, which provides a much fuller set of available functions.