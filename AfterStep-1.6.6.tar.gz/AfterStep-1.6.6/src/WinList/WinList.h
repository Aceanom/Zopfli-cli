/*
 * Copyright (c) 1997 Guylhem Aznar <guylhem@oeil.qc.ca>
 * Copyright (c) 1994 Mike Finger <mfinger@mermaid.micro.umn.edu>
 *                    or <Mike_Finger@atk.com>
 * Copyright (c) 1994 Robert Nation
 * Copyright (c) 1994 Nobutaka Suzuki
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "../../include/aftersteplib.h"

#define STICKY         1 /* Does window stick to glass? */
#define ONTOP          2 /* does window stay on top */
#define BORDER         4 /* Is this decorated with border*/
#define TITLE          8 /* Is this decorated with title */
#define ICONIFIED     32 /* is it an icon now? */
#define TRANSIENT     64 /* is it a transient window? */
#define WINDOWLISTSKIP         262144

/* Motif  window hints */
typedef struct
{
    CARD32      flags;
    CARD32      functions;
    CARD32      decorations;
    INT32       inputMode;
} PropMotifWmHints;

typedef PropMotifWmHints        PropMwmHints;

/* Motif window hints */
#define MWM_HINTS_FUNCTIONS     (1L << 0)
#define MWM_HINTS_DECORATIONS   (1L << 1)
#define MWM_HINTS_INPUT_MODE    (1L << 2)

/* bit definitions for MwmHints.functions */
#define MWM_FUNC_ALL            (1L << 0)
#define MWM_FUNC_RESIZE         (1L << 1)
#define MWM_FUNC_MOVE           (1L << 2)
#define MWM_FUNC_MINIMIZE       (1L << 3)
#define MWM_FUNC_MAXIMIZE       (1L << 4)
#define MWM_FUNC_CLOSE          (1L << 5)       

/* values for MwmHints.input_mode */
#define MWM_INPUT_MODELESS                      0
#define MWM_INPUT_PRIMARY_APPLICATION_MODAL     1
#define MWM_INPUT_SYSTEM_MODAL                  2
#define MWM_INPUT_FULL_APPLICATION_MODAL        3         

/* bit definitions for MwmHints.decorations */
#define MWM_DECOR_ALL                 (1L << 0)
#define MWM_DECOR_BORDER              (1L << 1)
#define MWM_DECOR_RESIZEH             (1L << 2)
#define MWM_DECOR_TITLE               (1L << 3)
#define MWM_DECOR_MENU                (1L << 4)
#define MWM_DECOR_MINIMIZE            (1L << 5)
#define MWM_DECOR_MAXIMIZE            (1L << 6)

#define PROP_MOTIF_WM_HINTS_ELEMENTS  4
#define PROP_MWM_HINTS_ELEMENTS       PROP_MOTIF_WM_HINTS_ELEMENTS

/*************************************************************************
  Subroutine Prototypes
**************************************************************************/
void EndLessLoop(void);
void ReadASPipe(void);
void ProcessMessage(unsigned long type,unsigned long *body);
void SendASPipe(char *message,unsigned long window);
void DeadPipe(int nonsense);
void MakeMeWindow(void);
void WaitForExpose(void);
void RedrawWindow(int force);
void StartMeUp(void);
void ShutMeDown(int exitstat);
void ConsoleMessage(char *fmt,...);
int OpenConsole(void);
void ParseOptions(char *file);
void LoopOnEvents(void);
void AdjustWindow(void);
char *makename(char *string,long flags);
void ChangeWindowName(char *str);
void LinkAction(char *string);
void AddToSkipList(char *string);
int InSkipList(char *string);
void PrintSkipList(void);
void ASNameMessage(long *body);
void SetMwmHints(unsigned int value,unsigned int funcs,unsigned int input);

int matchWildcards(char *pattern, char *string);

#ifdef BROKEN_SUN_HEADERS
#include "../../src/sun_headers.h"
#endif

#ifdef NEEDS_ALPHA_HEADER
#include "../../src/alpha_header.h"
#endif /* NEEDS_ALPHA_HEADER */
