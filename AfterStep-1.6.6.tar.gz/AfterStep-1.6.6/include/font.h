#ifndef FONT_H
#define FONT_H

typedef struct MyFont {
	char *name;				/* name of the font */
	XFontStruct *font;		/* font structure */
#ifdef I18N
    XFontSet fontset;
#endif
	int height;				/* height of the font */
	int y;					/* Y coordinate to draw characters */
} MyFont;

Bool load_font (const char *, MyFont *);
void unload_font (MyFont *);

#endif /* FONT_H */
