package genericreturntype

type R struct{}
