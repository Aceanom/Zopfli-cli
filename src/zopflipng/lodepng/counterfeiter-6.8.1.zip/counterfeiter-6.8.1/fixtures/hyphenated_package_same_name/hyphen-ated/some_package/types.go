package some_package // import "github.com/maxbrunsfeld/counterfeiter/v6/fixtures/hyphenated_package_same_name/hyphen-ated/some_package"

type Thing int
