package externalpkg

//go:generate go run github.com/maxbrunsfeld/counterfeiter/v6 -generate
//counterfeiter:generate github.com/maxbrunsfeld/counterfeiter/v6/fixtures/internalpkg.Context
