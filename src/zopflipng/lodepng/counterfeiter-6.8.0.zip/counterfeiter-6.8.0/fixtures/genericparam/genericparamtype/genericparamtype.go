package genericparamtype

type T string
