/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.aries.rsa.provider.tcp.myservice;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.framework.Version;

public interface PrimitiveService {
    
    byte callByte(byte num);
    
    short callShort(short num);

    int callInt(int num);

    long callLong(long num);
    
    float callFloat(float num);
    
    double callDouble(double num);

    boolean callBoolean(boolean bool);
    
    byte[] callByteAr(byte[] byteAr);

    Version callVersion(Version version);

    Version[] callVersionAr(Version[] version);

    List<Version> callVersionList(List<Version> version);

    Map<Version, Version> callVersionMap(Map<Version, Version> map);

    Set<Version> callVersionSet(Set<Version> set);

    DTOType callDTO(DTOType dto);

    DTOType[] callDTOAr(DTOType[] dtoAr);
}
