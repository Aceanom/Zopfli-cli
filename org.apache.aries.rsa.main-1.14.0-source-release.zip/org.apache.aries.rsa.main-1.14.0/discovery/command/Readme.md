# Discovery Gogo Commands


## endpoints

Lists all discovered endpoints

	endpoints

## endpoint

Shows the properties of an endpoint identified by its id


	endpoint <id>
